final android.app.Activity act = this;
final float dens = act.getResources().getDisplayMetrics().density;
final int scrW = act.getResources().getDisplayMetrics().widthPixels;
final int scrH = act.getResources().getDisplayMetrics().heightPixels;
final String PIN = "1234";
final long DAY = 86400000L;
final int[][] APAL = {
	{0xFFF3F6FD, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFDDE6F8, 0xFFE8EFFC, 0xFF1E2A44, 0xFF7B8AA8, 0xFF2563EB, 0xFFF0F4FC, 0xFFE0E8FA, 0xFFFFFFFF},
	{0xFFF2F9F6, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFD8EDE3, 0xFFE4F3EC, 0xFF1D3329, 0xFF78948A, 0xFF059669, 0xFFEEF7F2, 0xFFDDF0E8, 0xFFFFFFFF},
	{0xFFF6F3FD, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFE4DAF8, 0xFFECE6FA, 0xFF2B2145, 0xFF8A7FAB, 0xFF7C3AED, 0xFFF2EEFB, 0xFFE8DEFA, 0xFFFFFFFF},
	{0xFFFDF3F5, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFF8DAE1, 0xFFFAE6EB, 0xFF45212B, 0xFFAB7F89, 0xFFE11D48, 0xFFFCEFF2, 0xFFFADDE3, 0xFFFFFFFF},
	{0xFFFDF8F0, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFF7E7C8, 0xFFFAEFDC, 0xFF45331D, 0xFFAB9578, 0xFFD97706, 0xFFFBF3E6, 0xFFFAEBD2, 0xFFFFFFFF},
	{0xFFF6F7FA, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFE1E5EC, 0xFFE3E7EE, 0xFF2A2F36, 0xFF8A919B, 0xFF475569, 0xFFF4F6FA, 0xFFE3E7EE, 0xFFFFFFFF},
	{0xFF12151A, 0xFF1C2028, 0xFF1C2028, 0xFF2B313B, 0xFF262C36, 0xFFF1F3F6, 0xFF8F98A5, 0xFF6366F1, 0xFF181C23, 0xFF2B313B, 0xFF1C2028},
	{0xFF0A1020, 0xFF131B30, 0xFF131B30, 0xFF25304D, 0xFF1B2540, 0xFFE8EEFF, 0xFF8090B8, 0xFF3B82F6, 0xFF0F1729, 0xFF25304D, 0xFF131B30},
	{0xFF0C1511, 0xFF14211B, 0xFF14211B, 0xFF22352C, 0xFF1B2C24, 0xFFE6F2EC, 0xFF7F9A8C, 0xFF10B981, 0xFF101B16, 0xFF22352C, 0xFF14211B}
};
final String[] ANAME = {"Ocean", "Emerald", "Violet", "Rose", "Amber", "Slate", "Night", "Midnight", "Forest"};
final int[] TI = {Math.max(0, Math.min(8, act.getSharedPreferences("adm", 0).getInt("theme", 0)))};
final String CTRY = "AF|Afghanistan|AFN|AFN;AL|Albania|ALL|ALL;DZ|Algeria|DZD|DZD;AD|Andorra|EUR|\u20ac;AO|Angola|AOA|AOA;AG|Antigua and Barbuda|XCD|$;AR|Argentina|ARS|AR$;AM|Armenia|AMD|AMD;AU|Australia|AUD|A$;AT|Austria|EUR|\u20ac;AZ|Azerbaijan|AZN|AZN;BS|Bahamas|BSD|$;BH|Bahrain|BHD|BHD;BD|Bangladesh|BDT|\u09f3;BB|Barbados|BBD|$;BY|Belarus|BYN|BYN;BE|Belgium|EUR|\u20ac;BZ|Belize|BZD|$;BJ|Benin|XOF|XOF;BT|Bhutan|BTN|BTN;BO|Bolivia|BOB|Bs;BA|Bosnia and Herzegovina|BAM|BAM;BW|Botswana|BWP|BWP;BR|Brazil|BRL|R$;BN|Brunei|BND|$;BG|Bulgaria|BGN|BGN;BF|Burkina Faso|XOF|XOF;BI|Burundi|BIF|BIF;KH|Cambodia|KHR|KHR;CM|Cameroon|XAF|XAF;CA|Canada|CAD|CA$;CV|Cape Verde|CVE|CVE;CF|Central African Republic|XAF|XAF;TD|Chad|XAF|XAF;CL|Chile|CLP|CL$;CN|China|CNY|\u00a5;CO|Colombia|COP|CO$;KM|Comoros|KMF|KMF;CG|Congo|XAF|XAF;CD|DR Congo|CDF|CDF;CR|Costa Rica|CRC|\u20a1;CI|Cote d'Ivoire|XOF|XOF;HR|Croatia|EUR|\u20ac;CU|Cuba|CUP|CUP;CY|Cyprus|EUR|\u20ac;CZ|Czechia|CZK|K\u010d;DK|Denmark|DKK|kr;DJ|Djibouti|DJF|DJF;DM|Dominica|XCD|$;DO|Dominican Republic|DOP|RD$;EC|Ecuador|USD|$;EG|Egypt|EGP|E\u00a3;SV|El Salvador|USD|$;GQ|Equatorial Guinea|XAF|XAF;ER|Eritrea|ERN|ERN;EE|Estonia|EUR|\u20ac;SZ|Eswatini|SZL|SZL;ET|Ethiopia|ETB|ETB;FJ|Fiji|FJD|$;FI|Finland|EUR|\u20ac;FR|France|EUR|\u20ac;GA|Gabon|XAF|XAF;GM|Gambia|GMD|GMD;GE|Georgia|GEL|\u20be;DE|Germany|EUR|\u20ac;GH|Ghana|GHS|GH\u20b5;GR|Greece|EUR|\u20ac;GD|Grenada|XCD|$;GT|Guatemala|GTQ|Q;GN|Guinea|GNF|GNF;GW|Guinea-Bissau|XOF|XOF;GY|Guyana|GYD|$;HT|Haiti|HTG|HTG;HN|Honduras|HNL|L;HK|Hong Kong|HKD|HK$;HU|Hungary|HUF|Ft;IS|Iceland|ISK|kr;IN|India|INR|\u20b9;ID|Indonesia|IDR|Rp;IR|Iran|IRR|IRR;IQ|Iraq|IQD|IQD;IE|Ireland|EUR|\u20ac;IL|Israel|ILS|\u20aa;IT|Italy|EUR|\u20ac;JM|Jamaica|JMD|$;JP|Japan|JPY|\u00a5;JO|Jordan|JOD|JOD;KZ|Kazakhstan|KZT|\u20b8;KE|Kenya|KES|KSh;KI|Kiribati|AUD|A$;XK|Kosovo|EUR|\u20ac;KW|Kuwait|KWD|KWD;KG|Kyrgyzstan|KGS|KGS;LA|Laos|LAK|\u20ad;LV|Latvia|EUR|\u20ac;LB|Lebanon|LBP|LBP;LS|Lesotho|LSL|LSL;LR|Liberia|LRD|$;LY|Libya|LYD|LYD;LI|Liechtenstein|CHF|CHF;LT|Lithuania|EUR|\u20ac;LU|Luxembourg|EUR|\u20ac;MO|Macao|MOP|MOP;MG|Madagascar|MGA|MGA;MW|Malawi|MWK|MWK;MY|Malaysia|MYR|RM;MV|Maldives|MVR|MVR;ML|Mali|XOF|XOF;MT|Malta|EUR|\u20ac;MH|Marshall Islands|USD|$;MR|Mauritania|MRU|MRU;MU|Mauritius|MUR|Rs;MX|Mexico|MXN|MX$;FM|Micronesia|USD|$;MD|Moldova|MDL|MDL;MC|Monaco|EUR|\u20ac;MN|Mongolia|MNT|\u20ae;ME|Montenegro|EUR|\u20ac;MA|Morocco|MAD|MAD;MZ|Mozambique|MZN|MZN;MM|Myanmar|MMK|MMK;NA|Namibia|NAD|$;NR|Nauru|AUD|A$;NP|Nepal|NPR|Rs;NL|Netherlands|EUR|\u20ac;NZ|New Zealand|NZD|NZ$;NI|Nicaragua|NIO|C$;NE|Niger|XOF|XOF;NG|Nigeria|NGN|\u20a6;KP|North Korea|KPW|KPW;MK|North Macedonia|MKD|MKD;NO|Norway|NOK|kr;OM|Oman|OMR|OMR;PK|Pakistan|PKR|Rs;PW|Palau|USD|$;PS|Palestine|ILS|\u20aa;PA|Panama|PAB|B/.;PG|Papua New Guinea|PGK|PGK;PY|Paraguay|PYG|\u20b2;PE|Peru|PEN|S/;PH|Philippines|PHP|\u20b1;PL|Poland|PLN|z\u0142;PT|Portugal|EUR|\u20ac;PR|Puerto Rico|USD|$;QA|Qatar|QAR|QAR;RO|Romania|RON|lei;RU|Russia|RUB|\u20bd;RW|Rwanda|RWF|RWF;KN|Saint Kitts and Nevis|XCD|$;LC|Saint Lucia|XCD|$;VC|Saint Vincent and the Grenadines|XCD|$;WS|Samoa|WST|WST;SM|San Marino|EUR|\u20ac;ST|Sao Tome and Principe|STN|STN;SA|Saudi Arabia|SAR|SAR;SN|Senegal|XOF|XOF;RS|Serbia|RSD|RSD;SC|Seychelles|SCR|SCR;SL|Sierra Leone|SLE|SLE;SG|Singapore|SGD|S$;SK|Slovakia|EUR|\u20ac;SI|Slovenia|EUR|\u20ac;SB|Solomon Islands|SBD|$;SO|Somalia|SOS|SOS;ZA|South Africa|ZAR|R;KR|South Korea|KRW|\u20a9;SS|South Sudan|SSP|SSP;ES|Spain|EUR|\u20ac;LK|Sri Lanka|LKR|Rs;SD|Sudan|SDG|SDG;SR|Suriname|SRD|$;SE|Sweden|SEK|kr;CH|Switzerland|CHF|CHF;SY|Syria|SYP|SYP;TW|Taiwan|TWD|NT$;TJ|Tajikistan|TJS|TJS;TZ|Tanzania|TZS|TSh;TH|Thailand|THB|\u0e3f;TL|Timor-Leste|USD|$;TG|Togo|XOF|XOF;TO|Tonga|TOP|TOP;TT|Trinidad and Tobago|TTD|$;TN|Tunisia|TND|TND;TR|Turkey|TRY|\u20ba;TM|Turkmenistan|TMT|TMT;TV|Tuvalu|AUD|A$;UG|Uganda|UGX|USh;UA|Ukraine|UAH|\u20b4;AE|United Arab Emirates|AED|AED;GB|United Kingdom|GBP|\u00a3;US|United States|USD|$;UY|Uruguay|UYU|$U;UZ|Uzbekistan|UZS|UZS;VU|Vanuatu|VUV|VUV;VA|Vatican City|EUR|\u20ac;VE|Venezuela|VES|Bs;VN|Vietnam|VND|\u20ab;YE|Yemen|YER|YER;ZM|Zambia|ZMW|ZMW;ZW|Zimbabwe|USD|$";
class Ic extends View {
	int t, col; android.graphics.Paint p = new android.graphics.Paint(1);
	Ic(int t, int col) { super(act); this.t = t; this.col = col; }
	protected void onDraw(android.graphics.Canvas c) {
		float w = getWidth(), h = getHeight(), s = Math.min(w, h); if (s <= 0) return;
		c.save(); c.translate((w - s) / 2f, (h - s) / 2f); c.scale(s / 24f, s / 24f);
		p.setColor(col); p.setStyle(android.graphics.Paint.Style.STROKE); p.setStrokeWidth(1.9f); p.setStrokeCap(android.graphics.Paint.Cap.ROUND); p.setStrokeJoin(android.graphics.Paint.Join.ROUND);
		android.graphics.Path q = new android.graphics.Path();
		switch (t) {
			case 0: q.moveTo(4.5f, 18f); q.lineTo(6f, 16.5f); q.lineTo(6f, 11f); q.cubicTo(6f, 7.7f, 8.7f, 5f, 12f, 5f); q.cubicTo(15.3f, 5f, 18f, 7.7f, 18f, 11f); q.lineTo(18f, 16.5f); q.lineTo(19.5f, 18f); q.close(); c.drawPath(q, p);
			c.drawLine(12, 3, 12, 5, p); q.reset(); q.moveTo(10f, 20.5f); q.cubicTo(10.4f, 22f, 13.6f, 22f, 14f, 20.5f); c.drawPath(q, p); break;
			case 1: q.moveTo(3, 11); q.lineTo(12, 3); q.lineTo(21, 11); c.drawPath(q, p); q.reset(); q.moveTo(5, 10); q.lineTo(5, 20); q.lineTo(19, 20); q.lineTo(19, 10); c.drawPath(q, p); q.reset(); q.moveTo(10, 20); q.lineTo(10, 14); q.lineTo(14, 14); q.lineTo(14, 20); c.drawPath(q, p); break;
			case 2: c.drawRoundRect(new android.graphics.RectF(4, 5, 20, 20), 3, 3, p); c.drawLine(4, 10, 20, 10, p); c.drawLine(8, 3, 8, 7, p); c.drawLine(16, 3, 16, 7, p); p.setStyle(android.graphics.Paint.Style.FILL); c.drawCircle(9, 14, 1.2f, p); c.drawCircle(13, 14, 1.2f, p); c.drawCircle(9, 17.5f, 1.2f, p); break;
			case 3: c.drawCircle(12, 12, 3.2f, p); c.drawCircle(12, 12, 7, p); for (int k = 0; k < 8; k++) { double a = k * Math.PI / 4; c.drawLine((float) (12 + 8.5 * Math.cos(a)), (float) (12 + 8.5 * Math.sin(a)), (float) (12 + 10.5 * Math.cos(a)), (float) (12 + 10.5 * Math.sin(a)), p); } break;
			case 4: c.drawLine(12, 12, 6, 6, p); c.drawLine(12, 12, 18, 6, p); c.drawLine(12, 12, 6, 18, p); c.drawLine(12, 12, 18, 18, p); c.drawCircle(5, 5, 2.6f, p); c.drawCircle(19, 5, 2.6f, p); c.drawCircle(5, 19, 2.6f, p); c.drawCircle(19, 19, 2.6f, p); p.setStyle(android.graphics.Paint.Style.FILL); c.drawCircle(12, 12, 2.6f, p); break;
			case 5: c.drawCircle(12, 12, 7, p); c.drawLine(12, 2, 12, 6, p); c.drawLine(12, 18, 12, 22, p); c.drawLine(2, 12, 6, 12, p); c.drawLine(18, 12, 22, 12, p); p.setStyle(android.graphics.Paint.Style.FILL); c.drawCircle(12, 12, 2, p); break;
			case 6: c.drawRoundRect(new android.graphics.RectF(3, 5, 21, 19), 3, 3, p); q.moveTo(4, 18); q.lineTo(10, 12); q.lineTo(14, 16); q.lineTo(17, 13); q.lineTo(20, 16); c.drawPath(q, p); p.setStyle(android.graphics.Paint.Style.FILL); c.drawCircle(9, 9.5f, 1.6f, p); break;
			case 7: q.moveTo(3, 6); q.lineTo(9, 4); q.lineTo(15, 6); q.lineTo(21, 4); q.lineTo(21, 18); q.lineTo(15, 20); q.lineTo(9, 18); q.lineTo(3, 20); q.close(); c.drawPath(q, p); c.drawLine(9, 4, 9, 18, p); c.drawLine(15, 6, 15, 20, p); break;
			case 8: c.drawLine(4, 7, 20, 7, p); c.drawLine(4, 12, 20, 12, p); c.drawLine(4, 17, 20, 17, p); p.setStyle(android.graphics.Paint.Style.FILL); c.drawCircle(9, 7, 2.3f, p); c.drawCircle(15, 12, 2.3f, p); c.drawCircle(8, 17, 2.3f, p); break;
			case 9: c.drawRoundRect(new android.graphics.RectF(3, 7, 19, 17), 2.5f, 2.5f, p); c.drawLine(21, 10, 21, 14, p); p.setStyle(android.graphics.Paint.Style.FILL); q.moveTo(11, 9); q.lineTo(8, 12.5f); q.lineTo(11, 12.5f); q.lineTo(10, 15); q.lineTo(14, 11); q.lineTo(11, 11); q.close(); c.drawPath(q, p); break;
			case 10: c.drawRoundRect(new android.graphics.RectF(6, 6, 18, 18), 2, 2, p); c.drawLine(9, 3, 9, 6, p); c.drawLine(15, 3, 15, 6, p); c.drawLine(9, 18, 9, 21, p); c.drawLine(15, 18, 15, 21, p); c.drawLine(3, 9, 6, 9, p); c.drawLine(3, 15, 6, 15, p); c.drawLine(18, 9, 21, 9, p); c.drawLine(18, 15, 21, 15, p); break;
			case 11: c.drawArc(new android.graphics.RectF(3, 9, 21, 27), 225, 90, false, p); c.drawArc(new android.graphics.RectF(6, 12, 18, 24), 225, 90, false, p); c.drawArc(new android.graphics.RectF(9, 15, 15, 21), 225, 90, false, p); p.setStyle(android.graphics.Paint.Style.FILL); c.drawCircle(12, 19, 1.3f, p); break;
			case 12: q.moveTo(12, 3); q.lineTo(20, 6); q.lineTo(20, 12); q.cubicTo(20, 17, 16, 20, 12, 21); q.cubicTo(8, 20, 4, 17, 4, 12); q.lineTo(4, 6); q.close(); c.drawPath(q, p); break;
			case 13: c.drawRoundRect(new android.graphics.RectF(3, 4, 21, 20), 3, 3, p); q.moveTo(7, 9); q.lineTo(11, 12); q.lineTo(7, 15); c.drawPath(q, p); c.drawLine(13, 15, 17, 15, p); break;
			case 14: c.drawRoundRect(new android.graphics.RectF(4, 4, 20, 10.5f), 2, 2, p); c.drawRoundRect(new android.graphics.RectF(4, 13.5f, 20, 20), 2, 2, p); p.setStyle(android.graphics.Paint.Style.FILL); c.drawCircle(8, 7.2f, 1.1f, p); c.drawCircle(8, 16.8f, 1.1f, p); break;
			case 15: c.drawRoundRect(new android.graphics.RectF(9, 9, 20, 20), 2.5f, 2.5f, p); q.moveTo(15, 5.5f); q.lineTo(15, 4.5f); q.lineTo(5.5f, 4.5f); q.lineTo(4.5f, 5.5f); q.lineTo(4.5f, 15); q.lineTo(5.5f, 15); c.drawPath(q, p); break;
			case 16: q.moveTo(3, 11); q.lineTo(21, 3); q.lineTo(14, 21); q.lineTo(11, 13); q.close(); c.drawPath(q, p); c.drawLine(11, 13, 21, 3, p); break;
			case 17: c.drawRoundRect(new android.graphics.RectF(3.5f, 4, 20.5f, 16), 3.5f, 3.5f, p); q.moveTo(9, 16); q.lineTo(9, 20.5f); q.lineTo(13.5f, 16); c.drawPath(q, p); break;
			case 18: c.drawLine(19, 12, 5, 12, p); q.moveTo(11, 6); q.lineTo(5, 12); q.lineTo(11, 18); c.drawPath(q, p); break;
			case 19: q.moveTo(9, 6); q.lineTo(15, 12); q.lineTo(9, 18); c.drawPath(q, p); break;
			case 20: case 21: if (t == 21) p.setStyle(android.graphics.Paint.Style.FILL); q.moveTo(12, 20.5f); q.cubicTo(5.5f, 15, 2.5f, 12, 2.5f, 8.3f); q.cubicTo(2.5f, 5.5f, 4.6f, 3.5f, 7.2f, 3.5f); q.cubicTo(9.2f, 3.5f, 11, 4.6f, 12, 6.3f); q.cubicTo(13, 4.6f, 14.8f, 3.5f, 16.8f, 3.5f); q.cubicTo(19.4f, 3.5f, 21.5f, 5.5f, 21.5f, 8.3f); q.cubicTo(21.5f, 12, 18.5f, 15, 12, 20.5f); q.close(); c.drawPath(q, p); break;
			case 22: c.drawRoundRect(new android.graphics.RectF(3.5f, 4, 20.5f, 16), 3.5f, 3.5f, p); q.moveTo(9, 16); q.lineTo(9, 20.5f); q.lineTo(13.5f, 16); c.drawPath(q, p); c.drawLine(8, 8.5f, 16, 8.5f, p); c.drawLine(8, 11.5f, 13, 11.5f, p); break;
			case 23: q.moveTo(2, 12); q.cubicTo(5, 6, 19, 6, 22, 12); q.cubicTo(19, 18, 5, 18, 2, 12); c.drawPath(q, p); c.drawCircle(12, 12, 3, p); break;
			case 24: c.drawLine(4, 7, 20, 7, p); q.moveTo(9, 7); q.lineTo(9, 4); q.lineTo(15, 4); q.lineTo(15, 7); c.drawPath(q, p); q.reset(); q.moveTo(6, 7); q.lineTo(7, 20); q.lineTo(17, 20); q.lineTo(18, 7); c.drawPath(q, p); break;
			case 25: q.moveTo(5, 19); q.lineTo(5.8f, 15); q.lineTo(16, 4.8f); q.lineTo(19.2f, 8); q.lineTo(9, 18.2f); q.close(); c.drawPath(q, p); break;
			case 26: c.drawRoundRect(new android.graphics.RectF(3, 7, 21, 17), 2.5f, 2.5f, p); c.drawLine(14, 8, 14, 10, p); c.drawLine(14, 11.5f, 14, 12.5f, p); c.drawLine(14, 14, 14, 16, p); break;
			case 27: q.moveTo(3, 8); q.lineTo(8, 13); q.lineTo(12, 5); q.lineTo(16, 13); q.lineTo(21, 8); q.lineTo(19, 19); q.lineTo(5, 19); q.close(); c.drawPath(q, p); break;
			case 28: c.drawRoundRect(new android.graphics.RectF(5, 11, 19, 21), 3, 3, p); q.moveTo(8, 11); q.lineTo(8, 8); q.cubicTo(8, 4.5f, 16, 4.5f, 16, 8); q.lineTo(16, 11); c.drawPath(q, p); break;
			case 29: c.drawCircle(12, 12, 9, p); q.moveTo(8, 12.5f); q.lineTo(11, 15.5f); q.lineTo(16.5f, 9); c.drawPath(q, p); break;
			case 30: c.drawCircle(12, 12, 9, p); c.drawLine(12, 7, 12, 12, p); c.drawLine(12, 12, 16, 14, p); break;
			case 31: c.drawCircle(12, 8, 4, p); q.moveTo(4, 20); q.cubicTo(4, 15, 8, 14, 12, 14); q.cubicTo(16, 14, 20, 15, 20, 20); c.drawPath(q, p); break;
			case 32: c.drawRoundRect(new android.graphics.RectF(4, 4, 10, 10), 1.5f, 1.5f, p); c.drawRoundRect(new android.graphics.RectF(14, 4, 20, 10), 1.5f, 1.5f, p); c.drawRoundRect(new android.graphics.RectF(4, 14, 10, 20), 1.5f, 1.5f, p); c.drawRoundRect(new android.graphics.RectF(14, 14, 20, 20), 1.5f, 1.5f, p); break;
			case 33: q.moveTo(4, 10); q.lineTo(4, 14); q.lineTo(8, 14); q.lineTo(18, 19); q.lineTo(18, 5); q.lineTo(8, 10); q.close(); c.drawPath(q, p); c.drawLine(8, 14, 9.5f, 20, p); break;
			case 34: c.drawLine(12, 5, 12, 19, p); c.drawLine(5, 12, 19, 12, p); break;
			case 35: c.drawCircle(12, 12, 9, p); c.drawLine(5.6f, 5.6f, 18.4f, 18.4f, p); break;
			case 36: p.setStyle(android.graphics.Paint.Style.FILL); q.moveTo(12, 2); q.lineTo(14.9f, 8.9f); q.lineTo(22, 9.3f); q.lineTo(16.5f, 14); q.lineTo(18.2f, 21); q.lineTo(12, 17.2f); q.lineTo(5.8f, 21); q.lineTo(7.5f, 14); q.lineTo(2, 9.3f); q.lineTo(9.1f, 8.9f); q.close(); c.drawPath(q, p); break;
			case 37: p.setStyle(android.graphics.Paint.Style.FILL); q.moveTo(13, 2); q.lineTo(5, 13.5f); q.lineTo(11, 13.5f); q.lineTo(10, 22); q.lineTo(19, 10); q.lineTo(13, 10); q.close(); c.drawPath(q, p); break;
			case 38: c.drawCircle(8, 15, 4, p); c.drawLine(11, 12, 20, 3, p); c.drawLine(17, 6, 19.5f, 8.5f, p); c.drawLine(14, 9, 16, 11, p); break;
			case 60: q.moveTo(6, 11); q.lineTo(12, 5); q.lineTo(18, 11); c.drawPath(q, p); q.reset(); q.moveTo(6, 19); q.lineTo(12, 13); q.lineTo(18, 19); c.drawPath(q, p); break;
			case 61: c.drawCircle(12, 12, 9, p); c.drawOval(new android.graphics.RectF(8, 3, 16, 21), p); c.drawLine(3, 12, 21, 12, p); break;
			case 62: c.drawRoundRect(new android.graphics.RectF(3, 5, 21, 19), 3, 3, p); c.drawLine(3, 10, 21, 10, p); c.drawLine(6.5f, 15, 10.5f, 15, p); break;
			case 63: c.drawRoundRect(new android.graphics.RectF(5, 3, 19, 21), 2.5f, 2.5f, p); c.drawLine(8.5f, 8, 15.5f, 8, p); c.drawLine(8.5f, 12, 15.5f, 12, p); c.drawLine(8.5f, 16, 12.5f, 16, p); break;
			case 64: c.drawCircle(12, 12, 9, p); q.moveTo(10, 8.5f); q.lineTo(16, 12); q.lineTo(10, 15.5f); q.close(); p.setStyle(android.graphics.Paint.Style.FILL); c.drawPath(q, p); break;
			case 65: q.moveTo(12, 20); q.cubicTo(4, 14.5f, 3, 9, 6.5f, 6.5f); q.cubicTo(9, 4.7f, 11.4f, 6, 12, 8); q.cubicTo(12.6f, 6, 15, 4.7f, 17.5f, 6.5f); q.cubicTo(21, 9, 20, 14.5f, 12, 20); q.close(); c.drawPath(q, p); break;
			case 66: c.drawRoundRect(new android.graphics.RectF(4, 10, 20, 21), 2, 2, p); c.drawRoundRect(new android.graphics.RectF(3, 7, 21, 10), 1.5f, 1.5f, p); c.drawLine(12, 7, 12, 21, p); c.drawLine(12, 7, 8.5f, 4, p); c.drawLine(12, 7, 15.5f, 4, p); break;
			case 67: q.moveTo(12, 3); q.cubicTo(13, 8, 18, 10, 18, 15); q.cubicTo(18, 18.5f, 15.3f, 21, 12, 21); q.cubicTo(8.7f, 21, 6, 18.5f, 6, 15); q.cubicTo(6, 12.5f, 7.5f, 11, 8.5f, 9.5f); q.cubicTo(9.5f, 11, 10.5f, 11.5f, 11, 12); q.cubicTo(11.5f, 9, 11, 6, 12, 3); q.close(); c.drawPath(q, p); break;
			case 68: c.drawCircle(8, 17, 3, p); c.drawCircle(16, 15, 3, p); c.drawLine(11, 17, 11, 5, p); c.drawLine(19, 15, 19, 3, p); c.drawLine(11, 5, 19, 3, p); break;
			case 69: c.drawRoundRect(new android.graphics.RectF(3, 7, 21, 19), 3, 3, p); c.drawCircle(12, 13, 3.5f, p); q.moveTo(8, 7); q.lineTo(9.5f, 4); q.lineTo(14.5f, 4); q.lineTo(16, 7); c.drawPath(q, p); break;
			case 70: c.drawRoundRect(new android.graphics.RectF(2, 8, 22, 18), 5, 5, p); c.drawLine(7, 11, 7, 15, p); c.drawLine(5, 13, 9, 13, p); c.drawCircle(15.5f, 11.5f, 1, p); c.drawCircle(18, 14, 1, p); break;
			case 71: q.moveTo(6, 16); q.lineTo(6, 11); q.cubicTo(6, 7, 9, 5, 12, 5); q.cubicTo(15, 5, 18, 7, 18, 11); q.lineTo(18, 16); q.lineTo(20, 18); q.lineTo(4, 18); q.close(); c.drawPath(q, p); c.drawLine(10, 21, 14, 21, p); break;
			case 72: q.moveTo(7, 18); q.cubicTo(2.5f, 18, 2.5f, 11.5f, 8, 11.5f); q.cubicTo(9, 6.5f, 16.5f, 6.5f, 17, 11.5f); q.cubicTo(21.5f, 11.5f, 21.5f, 18, 17, 18); q.close(); c.drawPath(q, p); break;
			case 73: c.drawLine(12, 4, 12, 15, p); q.moveTo(7, 11); q.lineTo(12, 16); q.lineTo(17, 11); c.drawPath(q, p); c.drawLine(5, 20, 19, 20, p); break;
			case 74: q.moveTo(3, 11); q.lineTo(12, 3); q.lineTo(21, 11); c.drawPath(q, p); q.reset(); q.moveTo(5, 10); q.lineTo(5, 20); q.lineTo(19, 20); q.lineTo(19, 10); c.drawPath(q, p); break;
			case 75: q.moveTo(6, 4); q.lineTo(18, 4); q.lineTo(22, 10); q.lineTo(12, 21); q.lineTo(2, 10); q.close(); c.drawPath(q, p); c.drawLine(2, 10, 22, 10, p); break;
			case 76: q.moveTo(12, 3); q.lineTo(20, 7.5f); q.lineTo(20, 16.5f); q.lineTo(12, 21); q.lineTo(4, 16.5f); q.lineTo(4, 7.5f); q.close(); c.drawPath(q, p); c.drawLine(4, 7.5f, 12, 12, p); c.drawLine(20, 7.5f, 12, 12, p); c.drawLine(12, 12, 12, 21, p); break;
			case 77: q.moveTo(12, 3); q.lineTo(21, 8); q.lineTo(12, 13); q.lineTo(3, 8); q.close(); c.drawPath(q, p); q.reset(); q.moveTo(3, 12); q.lineTo(12, 17); q.lineTo(21, 12); c.drawPath(q, p); q.reset(); q.moveTo(3, 16); q.lineTo(12, 21); q.lineTo(21, 16); c.drawPath(q, p); break;
			case 78: c.drawLine(5, 3, 5, 21, p); q.moveTo(5, 4); q.lineTo(19, 4); q.lineTo(16, 8.5f); q.lineTo(19, 13); q.lineTo(5, 13); q.close(); c.drawPath(q, p); break;
		}
		c.restore();
	}
}
class Tg extends View {
	boolean on; float pos; android.graphics.Paint p = new android.graphics.Paint(1);
	Tg(boolean v) { super(act); on = v; pos = v ? 1f : 0f; setOnClickListener(new View.OnClickListener() { public void onClick(View x) { setChecked(!on); } }); }
	boolean isChecked() { return on; }
	void setChecked(boolean v) { on = v; android.animation.ValueAnimator a = android.animation.ValueAnimator.ofFloat(pos, v ? 1f : 0f); a.setDuration(180); a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() { public void onAnimationUpdate(android.animation.ValueAnimator x) { pos = ((Float) x.getAnimatedValue()).floatValue(); invalidate(); } }); a.start(); }
	protected void onMeasure(int w, int h) { setMeasuredDimension((int) (50 * dens), (int) (30 * dens)); }
	protected void onDraw(android.graphics.Canvas c) {
		float w = getWidth(), h = getHeight(), r = h / 2f; p.setStyle(android.graphics.Paint.Style.FILL);
		p.setColor(((Integer) new android.animation.ArgbEvaluator().evaluate(pos, APAL[TI[0]][3], APAL[TI[0]][7])).intValue()); c.drawRoundRect(new android.graphics.RectF(0, 0, w, h), r, r, p);
		float tr = r - 3.5f * dens, cx = r + (w - 2 * r) * pos; p.setColor(0xFFFFFFFF); c.drawCircle(cx, r, tr, p);
	}
}
class Flow extends android.view.ViewGroup {
	int gap;
	Flow(int g) { super(act); gap = g; }
	protected void onMeasure(int wms, int hms) {
		int maxW = View.MeasureSpec.getSize(wms), x = 0, y = 0, rh = 0;
		for (int i = 0; i < getChildCount(); i++) { View c = getChildAt(i); if (c.getVisibility() == 8) continue;
			c.measure(View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
			int cw = c.getMeasuredWidth(), ch = c.getMeasuredHeight(); if (x > 0 && x + cw > maxW) { x = 0; y += rh + gap; rh = 0; } x += cw + gap; rh = Math.max(rh, ch); }
		setMeasuredDimension(maxW, y + rh);
	}
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		int maxW = r - l, x = 0, y = 0, rh = 0;
		for (int i = 0; i < getChildCount(); i++) { View c = getChildAt(i); if (c.getVisibility() == 8) continue;
			int cw = c.getMeasuredWidth(), ch = c.getMeasuredHeight(); if (x > 0 && x + cw > maxW) { x = 0; y += rh + gap; rh = 0; } c.layout(x, y, x + cw, y + ch); x += cw + gap; rh = Math.max(rh, ch); }
	}
}
class AD {
	final com.google.firebase.database.DatabaseReference db = com.google.firebase.database.FirebaseDatabase.getInstance().getReference("dv");
	final android.widget.FrameLayout root = new android.widget.FrameLayout(act);
	int cBg, cCard, cWhite, cStroke, cSoft, cText, cSub, cInk, cField, cLine, cNav;
	final int cGreen = 0xFF1FA85A, cRed = 0xFFE5484D, cAmber = 0xFFF59E0B, cBlue = 0xFF3B82F6, cPurple = 0xFF8B5CF6;
	void pal() { int[] a = APAL[TI[0]]; cBg = a[0]; cCard = a[1]; cWhite = a[2]; cStroke = a[3]; cSoft = a[4]; cText = a[5]; cSub = a[6]; cInk = a[7]; cField = a[8]; cLine = a[9]; cNav = a[10]; }
	{ pal(); }
	int dk(int c) { int r = (c >> 16 & 255) * 3 / 5, g = (c >> 8 & 255) * 3 / 5, b = (c & 255) * 3 / 5; return 0xFF000000 | r << 16 | g << 8 | b; }
	void bars() { try { act.getWindow().setStatusBarColor(cBg); act.getWindow().setNavigationBarColor(cNav); if (android.os.Build.VERSION.SDK_INT >= 23) { int f = 0; if (TI[0] < 6) { f = 0x2000; if (android.os.Build.VERSION.SDK_INT >= 26) f |= 0x10; } act.getWindow().getDecorView().setSystemUiVisibility(f); } } catch (Exception e) {} }
	void navBg() { navBg(); }
	void applyTheme(int i) { TI[0] = i; act.getSharedPreferences("adm", 0).edit().putInt("theme", i).apply(); pal(); root.setBackgroundColor(cBg); bars(); chatBox.setBackgroundColor(cNav); chatEt.setBackground(bg(cField, 14, cStroke, 1)); chatEt.setTextColor(cText); navBg(); lastNav = -2; all(); }
	void themeDlg() {
		Flow f = new Flow(dp(8)); final android.app.Dialog[] dd = new android.app.Dialog[1];
		for (int i = 0; i < ANAME.length; i++) { final int ix = i; boolean on = i == TI[0]; android.widget.LinearLayout c = lin(false); c.setGravity(16); c.setPadding(dp(12), dp(10), dp(14), dp(10)); c.setBackground(bg(on ? al(APAL[i][7], 0x22) : cSoft, 14, on ? APAL[i][7] : 0, 2)); View dot = new View(act); dot.setBackground(bg(APAL[i][7], 8, APAL[i][0], 2)); c.addView(dot, lp(dp(16), dp(16), 0, 0, 8, 0)); c.addView(tv(ANAME[i], 13, cText, true)); c.setOnClickListener(ck(new Runnable() { public void run() { if (dd[0] != null) dd[0].dismiss(); applyTheme(ix); } })); f.addView(c); }
		dd[0] = dlg("Admin theme", "changes only this admin app", f, null, null);
	}
	void themeCard() {
		android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(8, cPurple, 42), lp(dp(42), dp(42), 0, 0, 12, 0));
		android.widget.LinearLayout m = lin(true); m.addView(tv("Admin theme", 16, cText, true)); m.addView(tv(ANAME[TI[0]] + "  |  only this admin app", 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); top.addView(m, lw(1f, 0, 0, 0, 0)); c1.addView(top);
		c1.addView(dark("CHANGE THEME", new Runnable() { public void run() { themeDlg(); } }), lp(-2, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 10));
	}
	String[][] LGA;
	String[][] langs() {
		if (LGA == null) { java.util.ArrayList<String[]> l = new java.util.ArrayList<String[]>();
			for (String c : java.util.Locale.getISOLanguages()) { java.util.Locale lc = new java.util.Locale(c); String en = lc.getDisplayLanguage(java.util.Locale.ENGLISH); if (en.length() == 0 || en.equals(c)) continue; l.add(new String[]{c, en, lc.getDisplayLanguage(lc)}); }
			java.util.Collections.sort(l, new java.util.Comparator<String[]>() { public int compare(String[] x, String[] y) { return x[1].compareTo(y[1]); } }); LGA = l.toArray(new String[l.size()][]); }
		return LGA;
	}
	String langName(String code) { if (code.length() == 0) code = "en"; for (String[] c : langs()) if (c[0].equals(code)) return c[1]; return code; }
	void fillLang(final android.widget.LinearLayout list, String q, final android.app.Dialog[] dd) {
		list.removeAllViews(); String f = q.trim().toLowerCase(); String cur = s(D[6], "lang"); if (cur.length() == 0) cur = "en";
		for (final String[] c : langs()) {
			if (f.length() > 0 && !(c[1].toLowerCase().contains(f) || c[2].toLowerCase().contains(f) || c[0].equals(f))) continue;
			android.widget.LinearLayout r = lin(false); r.setGravity(16); r.setPadding(dp(4), dp(11), dp(4), dp(11)); android.widget.LinearLayout m = lin(true); m.addView(tv(c[1], 14, cText, true)); if (c[2].length() > 0 && !c[2].equals(c[1])) m.addView(tv(c[2], 12, cSub, false), lp(-2, -2, 0, 2, 0, 0)); r.addView(m, lw(1f, 0, 0, 8, 0));
			if (c[0].equals(cur)) r.addView(pill("ACTIVE", cGreen), lp(-2, -2, 0, 0, 8, 0)); r.addView(tv(c[0].toUpperCase(), 11, cSub, true));
			r.setOnClickListener(ck(new Runnable() { public void run() { if (dd[0] != null) dd[0].dismiss(); db.child("config").child("lang").setValue(c[0]); toast("User app language: " + c[1]); } })); list.addView(r);
			View dv = new View(act); dv.setBackgroundColor(cLine); list.addView(dv, lp(-1, dp(1)));
		}
		pressAll(list);
	}
	void langDlg() {
		final android.widget.LinearLayout body = lin(true); body.setLayoutParams(lp(-1, (int) (scrH * 0.55f))); final EditText q = edit(""); q.setHint("Search language"); body.addView(q, lp(-1, -2));
		final android.widget.LinearLayout list = lin(true); android.widget.ScrollView sv2 = new android.widget.ScrollView(act); sv2.setVerticalScrollBarEnabled(false); sv2.addView(list); body.addView(sv2, new android.widget.LinearLayout.LayoutParams(-1, 0, 1f));
		final android.app.Dialog[] dd = new android.app.Dialog[1]; fillLang(list, "", dd);
		q.addTextChangedListener(new android.text.TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int c, int d) {} public void onTextChanged(CharSequence a, int b, int c, int d) {} public void afterTextChanged(android.text.Editable e) { fillLang(list, e.toString(), dd); } });
		dd[0] = dlg("User app language", "all texts in the user app change. users cannot change it", body, null, null);
	}
	void langCard() {
		android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(61, cBlue, 42), lp(dp(42), dp(42), 0, 0, 12, 0));
		android.widget.LinearLayout m = lin(true); m.addView(tv("User app language", 16, cText, true)); m.addView(tv(langName(s(D[6], "lang")) + "  |  users cannot change it", 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); top.addView(m, lw(1f, 0, 0, 0, 0)); c1.addView(top);
		c1.addView(dark("CHOOSE LANGUAGE", new Runnable() { public void run() { langDlg(); } }), lp(-2, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 10));
	}
	final int[] AVC = {0xFF3B82F6, 0xFF8B5CF6, 0xFF1FA85A, 0xFFF59E0B, 0xFFE5484D, 0xFF0EA5E9};
	final String[] TITLES = {"Dashboard", "Users", "Premium", "Notify", "More", "Codes", "Slider", "Menus", "Events", "Support", "Chat", "Settings", "Orders", "Countries", "Plans", "Premium page", "Catalog", "FAQ"};
	final String[] PATHS = {"users", "slides", "menus", "codes", "events", "notifs", "config", "support", "orders", "prem", "cat", "catcfg", "faq"};
	final String[] MENU_T = {"DRONE VIEW", "DAMAGE DRONE", "CUSTOM BACKGROUND", "MAP VERSION", "CUSTOM CONFIG", "1 HERO"};
	final String[] MENU_D = {"Raise the camera height and get a wide drone style view", "Drone view with damage info and extra visual details", "Change the boring background to your own custom background", "Mini map version, shows extra map information", "Load custom config files and apply your own settings", "1 Hero Feature Boost Up"};
	final String[] MENU_A = {"DroneViewActivity", "DamageDroneActivity", "CustomBackgroundActivity", "MapVersionActivity", "CustomConfigActivity", "OneHeroActivity"};
	final int[] MENU_IC = {4, 5, 6, 7, 8, 60};
	String[][] CL; int lastNav = -1, lastPage = -1; android.animation.ObjectAnimator livePulse;
	String[][] cl() { if (CL == null) { String[] a = CTRY.split(";"); CL = new String[a.length][]; for (int i = 0; i < a.length; i++) CL[i] = a[i].split("\\|"); } return CL; }
	String[] cInfo(String code) { for (String[] c : cl()) if (c[0].equals(code)) return c; return null; }
	final String[] PN = {"7 Days", "30 Days", "90 Days", "1 Year"}; final long[] PD = {7, 30, 90, 365};
	String money(double v) { return v == Math.floor(v) ? nf((long) v) : String.format(java.util.Locale.US, "%.2f", v); }
	final com.google.firebase.database.DataSnapshot[] D = new com.google.firebase.database.DataSnapshot[13];
	final java.util.HashMap<String, android.graphics.Bitmap> imgs = new java.util.HashMap<String, android.graphics.Bitmap>();
	int page; long off; String uq = "", chatUid = ""; boolean unlocked, kb; android.widget.ScrollView svB; android.widget.LinearLayout hdr, bodyBox, navBox, chatBox; EditText chatEt;
	class VL implements com.google.firebase.database.ValueEventListener {
		final int k; VL(int k) { this.k = k; }
		public void onDataChange(com.google.firebase.database.DataSnapshot d) { if (k == 99) { Object o = d.getValue(); if (o instanceof Number) off = ((Number) o).longValue(); return; } D[k] = d; sched(k); }
		public void onCancelled(com.google.firebase.database.DatabaseError e) { toast("DB: " + e.getMessage()); }
	}
	String s(com.google.firebase.database.DataSnapshot d, String k) { if (d == null) return ""; Object o = d.child(k).getValue(); return o == null ? "" : String.valueOf(o); }
	double n(com.google.firebase.database.DataSnapshot d, String k) { try { return Double.parseDouble(s(d, k)); } catch (Exception e) { return 0; } }
	long ln(com.google.firebase.database.DataSnapshot d, String k) { return (long) n(d, k); }
	long lv(com.google.firebase.database.MutableData d) { Object o = d.getValue(); return (o instanceof Number) ? ((Number) o).longValue() : 0L; }
	long now() { return System.currentTimeMillis() + off; }
	String nf(long v) { return java.text.NumberFormat.getInstance(java.util.Locale.US).format(v); }
	String fmt(long t) { return t <= 0 ? "-" : new java.text.SimpleDateFormat("dd MMM yy, HH:mm", java.util.Locale.getDefault()).format(new java.util.Date(t)); }
	String ago(long t) { long d = now() - t; if (t <= 0) return ""; if (d < 60000) return "just now"; if (d < 3600000L) return (d / 60000L) + "m ago"; if (d < DAY) return (d / 3600000L) + "h ago"; return fmt(t); }
	int al(int c, int a) { return (a << 24) | (c & 0xFFFFFF); }
	int avc(String k) { return AVC[Math.abs(k.hashCode()) % AVC.length]; }
	String ini(String nm) { return nm.length() > 0 ? nm.substring(0, 1).toUpperCase() : "?"; }
	long pl(com.google.firebase.database.DataSnapshot x) { long l = ln(x, "premiumUntil") - now(); return l > 0 ? l : 0; }
	String leftTxt(long ms) { long d = ms / DAY, h = (ms % DAY) / 3600000L, m = (ms % 3600000L) / 60000L; return d > 0 ? d + "d " + h + "h" : h + "h " + m + "m"; }
	java.util.ArrayList<com.google.firebase.database.DataSnapshot> sorted(com.google.firebase.database.DataSnapshot d, final String key, final boolean desc) {
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>();
		if (d != null) for (com.google.firebase.database.DataSnapshot x : d.getChildren()) l.add(x);
		java.util.Collections.sort(l, new java.util.Comparator<com.google.firebase.database.DataSnapshot>() { public int compare(com.google.firebase.database.DataSnapshot p1, com.google.firebase.database.DataSnapshot p2) { return desc ? Double.compare(n(p2, key), n(p1, key)) : Double.compare(n(p1, key), n(p2, key)); } });
		return l;
	}
	long supCount() { long c = 0; if (D[7] != null) for (com.google.firebase.database.DataSnapshot x : D[7].getChildren()) if (n(x.child("meta"), "unreadAdmin") > 0) c++; return c; }
	long activeCodes() { long c = 0; if (D[3] != null) for (com.google.firebase.database.DataSnapshot x : D[3].getChildren()) { long e = ln(x, "expireAt"); if (e == 0 || e > now()) c++; } return c; }
	final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper()); final Runnable allR = new Runnable() { public void run() { all(); } };
	void sched(int k) { if (k == 0 && !(page == 0 || page == 1 || page == 2 || page == 12)) return; hd.removeCallbacks(allR); hd.postDelayed(allR, k == 0 ? 700 : 150); }
	int dp(int v) { return (int) (v * dens + 0.5f); }
	void toast(String t) { android.widget.Toast.makeText(act.getApplicationContext(), t, 0).show(); }
	View.OnClickListener ck(final Runnable r) { return new View.OnClickListener() { public void onClick(View v) { pop(v); r.run(); } }; }
	void pop(final View v) { try { v.animate().cancel(); v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(60).withEndAction(new Runnable() { public void run() { v.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(new android.view.animation.OvershootInterpolator(3f)).start(); } }).start(); } catch (Exception e) {} }
	void pressAll(View v) {
		if (v == null) return;
		if (v.hasOnClickListeners() && v.getTag() == null) { v.setTag("p"); v.setOnTouchListener(new View.OnTouchListener() { public boolean onTouch(View x, android.view.MotionEvent e) { int a = e.getAction(); if (a == 0) x.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start(); else if (a == 1 || a == 3) x.animate().scaleX(1f).scaleY(1f).setDuration(160).start(); return false; } }); }
		if (v instanceof android.view.ViewGroup) { android.view.ViewGroup g = (android.view.ViewGroup) v; for (int i = 0; i < g.getChildCount(); i++) pressAll(g.getChildAt(i)); }
	}
	void hideBar() {
		try { Object ab = act.getClass().getMethod("getSupportActionBar").invoke(act);
			if (ab != null) { java.lang.reflect.Method m = ab.getClass().getMethod("hide"); m.setAccessible(true); m.invoke(ab); } } catch (Exception e) {}
		try { if (act.getActionBar() != null) act.getActionBar().hide(); } catch (Exception e) {}
	}
	android.graphics.drawable.GradientDrawable bg(int c, int r, int stroke, int sw) {
		android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
		g.setColor(c); g.setCornerRadius(r * dens); if (stroke != 0) g.setStroke(Math.max(1, (int) (sw * dens)), stroke); return g;
	}
	TextView tv(String t, int sz, int col, boolean bold) { TextView x = new TextView(act); x.setText(t); x.setTextSize(sz); x.setTextColor(col); x.setIncludeFontPadding(false); if (bold) x.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); return x; }
	TextView label(String t) { TextView x = tv(t, 11, cSub, true); if (android.os.Build.VERSION.SDK_INT >= 21) x.setLetterSpacing(0.1f); return x; }
	android.widget.LinearLayout lin(boolean v) { android.widget.LinearLayout l = new android.widget.LinearLayout(act); l.setOrientation(v ? 1 : 0); return l; }
	android.widget.LinearLayout.LayoutParams lp(int w, int h) { return new android.widget.LinearLayout.LayoutParams(w, h); }
	android.widget.LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) { android.widget.LinearLayout.LayoutParams p = new android.widget.LinearLayout.LayoutParams(w, h); p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p; }
	android.widget.LinearLayout.LayoutParams lw(float w, int l, int t, int r, int b) { android.widget.LinearLayout.LayoutParams p = new android.widget.LinearLayout.LayoutParams(0, -2, w); p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p; }
	View ic(int t, int sz, int col) { Ic i = new Ic(t, col); i.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dp(sz), dp(sz))); return i; }
	android.widget.FrameLayout ib(int t, int col, int box) { android.widget.FrameLayout f = new android.widget.FrameLayout(act); f.setBackground(bg(al(col, 0x24), 14, 0, 0)); int in = box / 2 + 2; f.addView(ic(t, in, col), new android.widget.FrameLayout.LayoutParams(dp(in), dp(in), 17)); f.setLayoutParams(lp(dp(box), dp(box))); return f; }
	android.widget.LinearLayout card() { android.widget.LinearLayout x = lin(true); x.setBackground(bg(cCard, 22, cStroke, 1)); x.setPadding(dp(16), dp(14), dp(16), dp(14)); return x; }
	TextView btn(String t, int fg, int bgc, Runnable r) { TextView b = tv(t, 12, fg, true); b.setGravity(17); b.setSingleLine(true); b.setPadding(dp(16), dp(10), dp(16), dp(10)); b.setBackground(bg(bgc, 12, 0, 0)); if (r != null) b.setOnClickListener(ck(r)); return b; }
	TextView dark(String t, Runnable r) { return btn(t, 0xFFFFFFFF, cInk, r); }
	TextView soft(String t, Runnable r) { return btn(t, cText, cSoft, r); }
	TextView red(String t, Runnable r) { return btn(t, 0xFFFFFFFF, cRed, r); }
	TextView pill(String t, int color) { boolean mute = color == cSub; TextView x = tv(t, 10, color, true); if (android.os.Build.VERSION.SDK_INT >= 21) x.setLetterSpacing(0.06f); x.setPadding(dp(10), dp(4), dp(10), dp(4)); x.setBackground(bg(mute ? cSoft : al(color, 0x26), 10, 0, 0)); return x; }
	EditText edit(String val) { EditText e = new EditText(act); e.setText(val); e.setTextSize(15); e.setTextColor(cText); e.setSingleLine(true); e.setHintTextColor(0xFF9AA3AD); e.setBackground(bg(cField, 14, cStroke, 1)); e.setPadding(dp(14), dp(12), dp(14), dp(12)); return e; }
	android.widget.LinearLayout kv(String l, String v) { android.widget.LinearLayout r = lin(false); r.addView(tv(l, 12, cSub, false), lw(0.8f, 0, 0, 8, 0)); TextView t = tv(v, 13, cText, true); t.setGravity(android.view.Gravity.END); r.addView(t, lw(1.4f, 0, 0, 0, 0)); r.setPadding(0, dp(5), 0, dp(5)); return r; }
	void copy(String t) { try { android.content.ClipboardManager cm = (android.content.ClipboardManager) act.getSystemService("clipboard"); cm.setPrimaryClip(android.content.ClipData.newPlainText("dv", t)); toast("Copied"); } catch (Exception e) {} }
	void loadImg(final ImageView iv, final String url) {
		android.graphics.Bitmap c = imgs.get(url); if (c != null) { iv.setImageBitmap(c); return; }
		new Thread(new Runnable() { public void run() { try {
					java.net.HttpURLConnection cn = (java.net.HttpURLConnection) new java.net.URL(url).openConnection(); cn.setConnectTimeout(10000); cn.setReadTimeout(15000);
					java.io.InputStream in = cn.getInputStream(); java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[8192]; int r; while ((r = in.read(buf)) > 0) bo.write(buf, 0, r); in.close();
					byte[] data = bo.toByteArray(); android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options(); o.inJustDecodeBounds = true; android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length, o);
					int sm = 1; while (o.outWidth / (sm * 2) >= 500) sm *= 2; o = new android.graphics.BitmapFactory.Options(); o.inSampleSize = sm;
					final android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length, o); if (bm != null) { imgs.put(url, bm); act.runOnUiThread(new Runnable() { public void run() { iv.setImageBitmap(bm); } }); }
				} catch (Exception e) {} } }).start();
	}
	android.app.Dialog dlgC(String title, String sub, View body, String ok, int okCol, final Runnable onOk) {
		if (act.isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && act.isDestroyed())) return null;
		final android.app.Dialog d = new android.app.Dialog(act); d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
		final android.widget.LinearLayout x = lin(true); x.setPadding(dp(22), dp(22), dp(22), dp(18)); x.setBackground(bg(cWhite, 28, 0, 0));
		int icn = okCol == cRed ? 24 : (okCol == cGreen ? 29 : 25); int icc = cInk;
		android.widget.LinearLayout head = lin(false); head.setGravity(16); head.addView(ib(icn, icc, 46), lp(dp(46), dp(46), 0, 0, 14, 0));
		android.widget.LinearLayout hm = lin(true); hm.addView(tv(title, 19, cText, true)); if (sub.length() > 0) hm.addView(tv(sub, 12, cSub, false), lp(-2, -2, 0, 3, 0, 0)); head.addView(hm, lw(1f, 0, 0, 0, 0)); x.addView(head);
		View dv = new View(act); dv.setBackgroundColor(cStroke); x.addView(dv, lp(-1, dp(1), 0, 16, 0, 0));
		if (body != null) { int bh = (body.getLayoutParams() != null && body.getLayoutParams().height > 0) ? body.getLayoutParams().height : -2; x.addView(body, lp(-1, bh, 0, 14, 0, 0)); }
		android.widget.LinearLayout row = lin(false);
		TextView cn = btn(ok == null ? "CLOSE" : "CANCEL", cText, cSoft, new Runnable() { public void run() { d.dismiss(); } }); cn.setPadding(dp(14), dp(14), dp(14), dp(14)); cn.setTextSize(13); row.addView(cn, lw(1f, 0, 0, ok == null ? 0 : 6, 0));
		if (ok != null) { TextView ob = btn(ok, 0xFFFFFFFF, okCol, new Runnable() { public void run() { d.dismiss(); if (onOk != null) onOk.run(); } }); ob.setPadding(dp(14), dp(14), dp(14), dp(14)); ob.setTextSize(13); row.addView(ob, lw(1f, 6, 0, 0, 0)); }
		x.addView(row, lp(-1, -2, 0, 18, 0, 0));
		d.setContentView(x); d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0)); d.getWindow().setDimAmount(0.6f); d.show(); d.getWindow().setLayout((int) (scrW * 0.92f), -2);
		x.setAlpha(0f); x.setScaleX(0.9f); x.setScaleY(0.9f); x.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(new android.view.animation.OvershootInterpolator(1.1f)).start(); pressAll(x); return d;
	}
	android.app.Dialog dlg(String title, String sub, View body, String ok, Runnable onOk) { return dlgC(title, sub, body, ok, cInk, onOk); }
	void confirm(String text, Runnable ok) { dlgC("Are you sure?", "", tv(text, 14, cSub, false), "YES, DO IT", cRed, ok); }
	android.widget.ScrollView scroll(View v, int hPx) { android.widget.ScrollView sv = new android.widget.ScrollView(act); sv.setVerticalScrollBarEnabled(false); sv.addView(v); sv.setLayoutParams(lp(-1, hPx)); return sv; }
	void paintSel(TextView[] cs, String[] vals, String cur) { for (int i = 0; i < cs.length; i++) { boolean on = vals[i].equals(cur); cs[i].setTextColor(on ? 0xFFFFFFFF : cSub); cs[i].setBackground(bg(on ? cInk : cSoft, 12, 0, 0)); } }
	class Fcb { void ok(java.util.HashMap<String, Object> m) {} }
	void form(String title, String sub, final String[] spec, com.google.firebase.database.DataSnapshot init, final Fcb cb) {
		final int N = spec.length; final String[] keys = new String[N], types = new String[N], val = new String[N]; final View[] vs = new View[N]; final String[][] ov = new String[N][]; final TextView[][] chips = new TextView[N][]; android.widget.LinearLayout col = lin(true);
		for (int i = 0; i < N; i++) {
			final int ix = i; String[] p = spec[i].split(":", 5); keys[i] = p[0]; types[i] = p[2]; String def = p.length > 3 ? p[3] : ""; val[i] = (init != null && init.hasChild(p[0])) ? s(init, p[0]) : def; android.widget.LinearLayout row = lin(true);
			if (types[i].equals("b")) { android.widget.LinearLayout h = lin(false); h.setGravity(16); h.addView(tv(p[1], 14, cText, true), lw(1f, 0, 0, 8, 0)); Tg sw = new Tg("true".equals(val[i])); vs[i] = sw; h.addView(sw); row.addView(h); }
			else { row.addView(label(p[1].toUpperCase()), lp(-2, -2, 0, 0, 0, 6));
				if (types[i].equals("s")) { String[] parts = p[4].split("\\|"); ov[i] = new String[parts.length]; Flow fl = new Flow(dp(8)); chips[i] = new TextView[parts.length];
					for (int j = 0; j < parts.length; j++) { final int jx = j; String[] kv2 = parts[j].split("="); ov[i][j] = kv2[0]; TextView c = tv(kv2.length > 1 ? kv2[1] : kv2[0], 13, cSub, true); c.setPadding(dp(14), dp(10), dp(14), dp(10)); chips[i][j] = c; c.setOnClickListener(ck(new Runnable() { public void run() { val[ix] = ov[ix][jx]; paintSel(chips[ix], ov[ix], val[ix]); } })); fl.addView(c); }
					paintSel(chips[i], ov[i], val[i]); row.addView(fl); }
				else { EditText et = edit(val[i]); if (types[i].equals("n")) et.setInputType(8194); vs[i] = et; row.addView(et, lp(-1, -2)); } }
			col.addView(row, lp(-1, -2, 0, i == 0 ? 0 : 16, 0, 0));
		}
		dlg(title, sub, scroll(col, N > 4 ? (int) (scrH * 0.58f) : -2), "SAVE", new Runnable() { public void run() {
				java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>();
				for (int i = 0; i < N; i++) { if (types[i].equals("b")) m.put(keys[i], ((Tg) vs[i]).isChecked()); else if (types[i].equals("s")) m.put(keys[i], val[i]);
					else { String v = ((EditText) vs[i]).getText().toString().trim(); if (types[i].equals("n")) { double dv = 0; try { dv = Double.parseDouble(v); } catch (Exception e) {} if (dv == Math.floor(dv)) m.put(keys[i], (long) dv); else m.put(keys[i], dv); } else m.put(keys[i], v); } }
				cb.ok(m); } });
	}
	Fcb save(final com.google.firebase.database.DatabaseReference r) { return new Fcb() { void ok(java.util.HashMap<String, Object> m) { if (m.containsKey("title") && String.valueOf(m.get("title")).length() == 0) { toast("Title is required"); return; } r.updateChildren(m); toast("Saved"); } }; }
	Fcb push(final String path, final boolean stamp) { return new Fcb() { void ok(java.util.HashMap<String, Object> m) { if (m.containsKey("title") && String.valueOf(m.get("title")).length() == 0) { toast("Title is required"); return; } if (stamp) m.put("time", com.google.firebase.database.ServerValue.TIMESTAMP); db.child(path).push().updateChildren(m); toast("Added"); } }; }
	void summary(android.widget.LinearLayout c, String[] spec, com.google.firebase.database.DataSnapshot d) {
		for (String sp : spec) { String[] p = sp.split(":", 5); String v = d != null && d.hasChild(p[0]) ? s(d, p[0]) : (p.length > 3 ? p[3] : "-"); if (p[2].equals("b")) v = "true".equals(v) ? "ON" : "OFF"; if (v.length() == 0) v = "-"; if (v.length() > 30) v = v.substring(0, 30) + "..."; c.addView(kv(p[1], v)); }
	}
	void cfgCard(String title, String note, final String[] spec, final com.google.firebase.database.DataSnapshot d, final String path, int icn, int color) {
		android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(icn, color, 42), lp(dp(42), dp(42), 0, 0, 12, 0));
		android.widget.LinearLayout m = lin(true); m.addView(tv(title, 16, cText, true)); if (note.length() > 0) m.addView(tv(note, 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); top.addView(m, lw(1f, 0, 0, 0, 0)); c1.addView(top);
		View dv = new View(act); dv.setBackgroundColor(cLine); c1.addView(dv, lp(-1, dp(1), 0, 12, 0, 6)); summary(c1, spec, d);
		c1.addView(dark("EDIT", new Runnable() { public void run() { form("Edit", "saved instantly, user app updates live", spec, d, save(db.child(path))); } }), lp(-2, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 10));
	}
	final String[] SPEC_APP = {"appName:App name:t:Drone Tools", "aboutTitle:About title:t:About this app", "aboutText:About text (shown in Events):t:Everything about this app, new tools and updates will be shown here.", "helpUrl:Help / community link:t:", "gamePkg:Game package name (opened after install):t:com.mobile.legends", "openAsk:Ask to open game after install:b:true"};
	final String[] SPEC_THEME = {"theme:Home color theme:s:0:0=Slate|1=Ocean|2=Emerald|3=Violet|4=Rose|5=Amber|7=Sunset|8=Teal|9=Indigo|10=Mocha"};
	final String[] SPEC_CTRL = {"maintenance:Maintenance mode:b:false", "maintMsg:Maintenance message:t:App is under maintenance, please try later", "banMsg:Ban message:t:Your device is banned"};
	final String[] SPEC_UPD = {"updOn:Show update dialog:b:false", "updVer:Latest Version code (higher than the app Version code):n:2", "updForce:Force update (cannot skip):b:false", "updTitle:Title:t:New update available", "updMsg:What is new:t:A new version is ready with improvements and fixes.", "updUrl:Download link:t:"};
	final String[] SPEC_SUP = {"supTopics:Chat topics (comma):t:Premium problem,Redeem code issue,Payment / Purchase,App problem,Feature request,Other", "supWelcome:Welcome text:t:Pick a topic, then tell us your problem. We will reply as soon as possible."};
	final String[] SPEC_SLIDE = {"title:Title:t:", "sub:Sub text:t:", "image:Image or video URL (.mp4):t:", "url:Click link (optional):t:", "order:Order:n:1", "active:Visible:b:true"};
	final String[] SPEC_EVENT = {"tag:Tag (NEW, UPDATE):t:NEW", "title:Title:t:", "text:Details:t:", "image:Image or video URL (.mp4, optional):t:", "url:Link (optional):t:", "active:Visible:b:true"};
	final String[] SPEC_PHEAD = {"headTitle:Header title:t:Go Premium", "headSub:Header text:t:Unlock every tool on your device", "videoUrl:Video link (plays when the header is tapped):t:"};
	final String[] SPEC_PDLG = {"dlgTitle:Dialog title:t:Complete your payment", "dlgText:Dialog text:t:Scan the QR code, pay the exact amount, then tap I HAVE PAID. Premium starts after admin approval."};
	final String[] SPEC_PDISC = {"discOn:Show discount banner:b:false", "disc:Discount text:t:"};
	void tile(android.widget.LinearLayout row, String t, String sub, int icn, int color, boolean first, Runnable r) {
		android.widget.LinearLayout c = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(icn, color, 42)); View gap = new View(act); top.addView(gap, new android.widget.LinearLayout.LayoutParams(0, 1, 1f)); top.addView(ic(19, 16, cSub)); c.addView(top);
		c.addView(tv(t, 15, cText, true), lp(-2, -2, 0, 14, 0, 0)); c.addView(tv(sub, 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); c.setOnClickListener(ck(r)); row.addView(c, lw(1f, first ? 0 : 5, 0, first ? 5 : 0, 0));
	}
	void stat(android.widget.LinearLayout row, String l, String v, int icn, int color, boolean first) {
		android.widget.LinearLayout c = card(); c.setPadding(dp(14), dp(14), dp(12), dp(14)); android.widget.LinearLayout h = lin(false); h.setGravity(16);
		android.widget.LinearLayout m = lin(true); m.addView(label(l)); TextView t = tv(v, 22, cText, true); t.setSingleLine(true); m.addView(t, lp(-2, -2, 0, 6, 0, 0)); h.addView(m, lw(1f, 0, 0, 8, 0)); h.addView(ib(icn, color, 38), lp(dp(38), dp(38))); c.addView(h); row.addView(c, lw(1f, first ? 0 : 5, 0, first ? 5 : 0, 0));
	}
	android.widget.LinearLayout row2() { android.widget.LinearLayout r = lin(false); bodyBox.addView(r, lp(-1, -2, 0, 0, 0, 10)); return r; }
	void alert(String text, int icn, int color, final int target) {
		android.widget.LinearLayout a = lin(false); a.setGravity(16); a.setPadding(dp(14), dp(12), dp(16), dp(12)); a.setBackground(bg(cInk, 18, 0, 0));
		android.widget.FrameLayout bx = new android.widget.FrameLayout(act); bx.setBackground(bg(0x26FFFFFF, 14, 0, 0)); bx.addView(ic(icn, 20, 0xFFFFFFFF), new android.widget.FrameLayout.LayoutParams(dp(20), dp(20), 17)); a.addView(bx, lp(dp(38), dp(38), 0, 0, 12, 0));
		a.addView(tv(text, 14, 0xFFFFFFFF, true), lw(1f, 0, 0, 8, 0)); a.addView(ic(19, 16, 0xCCFFFFFF));
		a.setOnClickListener(ck(new Runnable() { public void run() { page = target; all(); } })); bodyBox.addView(a, lp(-1, -2, 0, 0, 0, 12));
	}
	void pgDash() {
		long users = 0, a24 = 0, ban = 0, prem = 0, t24 = now() - DAY; if (D[0] != null) for (com.google.firebase.database.DataSnapshot x : D[0].getChildren()) { users++; if (ln(x, "lastSeen") > t24) a24++; if ("true".equals(s(x, "banned"))) ban++; if (pl(x) > 0) prem++; }
		android.widget.LinearLayout h = lin(true); h.setPadding(dp(22), dp(20), dp(22), dp(20)); android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{cInk, dk(cInk)}); g.setCornerRadius(28 * dens); h.setBackground(g);
		h.addView(label("TOTAL DEVICES")); ((TextView) h.getChildAt(0)).setTextColor(0xCCFFFFFF); h.addView(tv(nf(users), 38, 0xFFFFFFFF, true), lp(-2, -2, 0, 6, 0, 0)); h.addView(tv("Active 24h: " + nf(a24) + "     Premium: " + nf(prem), 13, 0xCCFFFFFF, false), lp(-2, -2, 0, 6, 0, 0)); bodyBox.addView(h, lp(-1, -2, 0, 4, 0, 12));
		long sc = supCount(); if (sc > 0) alert(sc + " support chat" + (sc > 1 ? "s" : "") + " waiting for reply", 17, cBlue, 9);
		long po0 = pendingOrders(); if (po0 > 0) alert(po0 + " payment order" + (po0 > 1 ? "s" : "") + " waiting for approval", 63, cInk, 12);
		android.widget.LinearLayout r = row2(); stat(r, "PREMIUM ACTIVE", nf(prem), 27, cAmber, true); stat(r, "FREE DEVICES", nf(users - prem), 31, cBlue, false);
		r = row2(); stat(r, "BANNED", nf(ban), 35, cRed, true); stat(r, "ACTIVE CODES", nf(activeCodes()), 26, cPurple, false);
		long ns = D[5] == null ? 0 : D[5].getChildrenCount(), vw = 0, lk = 0; if (D[5] != null) for (com.google.firebase.database.DataSnapshot x : D[5].getChildren()) { vw += ln(x, "viewCount"); lk += ln(x, "likeCount"); }
		r = row2(); stat(r, "NOTIFICATIONS", nf(ns), 0, cGreen, true); stat(r, "TOTAL VIEWS", nf(vw), 23, cBlue, false); r = row2(); stat(r, "TOTAL LIKES", nf(lk), 21, cRed, true); stat(r, "SLIDES", nf(D[1] == null ? 0 : D[1].getChildrenCount()), 6, cPurple, false);
	}
	void pgUsers() {
		android.widget.LinearLayout bar = lin(false); bar.setGravity(16); android.widget.LinearLayout sb = lin(false); sb.setGravity(16); sb.setPadding(dp(14), dp(12), dp(14), dp(12)); sb.setBackground(bg(cCard, 16, cStroke, 1));
		sb.addView(ic(31, 18, cSub), lp(dp(18), dp(18), 0, 0, 10, 0)); sb.addView(tv(uq.length() > 0 ? uq : "Search device id / model", 13, uq.length() > 0 ? cText : cSub, false), lw(1f, 0, 0, 0, 0));
		sb.setOnClickListener(ck(new Runnable() { public void run() { final EditText et = edit(uq); dlg("Search device", "device id or phone model", et, "FIND", new Runnable() { public void run() { uq = et.getText().toString().trim().toLowerCase(); all(); } }); } }));
		bar.addView(sb, lw(1f, 0, 0, 0, 0)); if (uq.length() > 0) bar.addView(soft("CLEAR", new Runnable() { public void run() { uq = ""; all(); } }), lp(-2, -2, 8, 0, 0, 0)); bodyBox.addView(bar, lp(-1, -2, 0, 0, 0, 12)); int shown = 0;
		for (final com.google.firebase.database.DataSnapshot x : sorted(D[0], "lastSeen", true)) {
			String hay = (x.getKey() + " " + s(x, "model")).toLowerCase(); if (uq.length() > 0 && !hay.contains(uq)) continue; if (++shown > 150) break; boolean bn = "true".equals(s(x, "banned")); long pr = pl(x); String nm = s(x, "model").length() > 0 ? s(x, "model") : "Device";
			android.widget.LinearLayout c1 = card(); c1.setPadding(dp(14), dp(12), dp(14), dp(12)); android.widget.LinearLayout r = lin(false); r.setGravity(16);
			android.widget.FrameLayout av = new android.widget.FrameLayout(act); av.setBackground(bg(bn ? 0xFF9AA3AD : avc(x.getKey()), 22, 0, 0)); TextView it = tv(ini(nm), 17, 0xFFFFFFFF, true); it.setGravity(17); av.addView(it, new android.widget.FrameLayout.LayoutParams(-1, -1)); r.addView(av, lp(dp(44), dp(44), 0, 0, 12, 0));
			android.widget.LinearLayout m = lin(true); android.widget.LinearLayout nr = lin(false); nr.setGravity(16); TextView nt = tv(nm, 14, cText, true); nt.setSingleLine(true); nr.addView(nt, lw(1f, 0, 0, 6, 0)); if (bn) nr.addView(pill("BANNED", cRed)); m.addView(nr);
			TextView idt = tv(x.getKey(), 11, cSub, false); idt.setSingleLine(true); idt.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); m.addView(idt, lp(-2, -2, 0, 3, 0, 0)); m.addView(tv("seen " + ago(ln(x, "lastSeen")) + (s(x, "countryName").length() > 0 ? "  |  " + s(x, "countryName") : ""), 11, cSub, false), lp(-2, -2, 0, 2, 0, 0)); r.addView(m, lw(1f, 0, 0, 8, 0));
			r.addView(pill(pr > 0 ? "PRO " + leftTxt(pr) : "FREE", pr > 0 ? cAmber : cSub)); c1.addView(r); c1.setOnClickListener(ck(new Runnable() { public void run() { userDlg(x); } })); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
		}
		if (shown == 0) bodyBox.addView(tv("No devices found", 13, cSub, false), lp(-2, -2, 4, 8, 0, 0));
	}
	void grantPremium(final String id, final long days, final String src) {
		db.child("users").child(id).runTransaction(new com.google.firebase.database.Transaction.Handler() {
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m) {
				long tm = now(), u = lv(m.child("premiumUntil")); boolean act2 = u > tm; long base = act2 ? u : tm; m.child("premiumUntil").setValue(base + days * DAY); if (!act2) m.child("premiumFrom").setValue(tm); m.child("premiumKey").setValue(src); m.child("premiumSrc").setValue("admin"); return com.google.firebase.database.Transaction.success(m);
			}
			public void onComplete(com.google.firebase.database.DatabaseError e, boolean ok, com.google.firebase.database.DataSnapshot d) { toast(ok ? "Premium +" + days + " days" : "Failed"); if (ok) notifyUser(id, "Premium activated", days + " day" + (days > 1 ? "s" : "") + " of premium were added to your device.", "success"); }
		});
	}
	void revoke(String id, boolean wipe) {
		java.util.HashMap<String, Object> u = new java.util.HashMap<String, Object>(); u.put("premiumUntil", null); u.put("premiumFrom", null); u.put("premiumKey", null); u.put("premiumSrc", null); u.put("revokedAt", wipe ? null : (Object) now());
		db.child("users").child(id).updateChildren(u); if (!wipe) notifyUser(id, "Premium removed", "Your premium access was removed by admin.", "warning"); toast(wipe ? "Premium record deleted" : "Premium revoked");
	}
	void notifyUser(String to, String title, String body, String type) { java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>(); m.put("to", to); m.put("title", title); m.put("body", body); m.put("type", type); m.put("time", com.google.firebase.database.ServerValue.TIMESTAMP); db.child("notifs").push().setValue(m); }
	void daysDlg(final String id, String title) {
		final EditText et = edit("30"); et.setInputType(2); et.setHint("days"); dlg(title, "device " + id, et, "CONFIRM", new Runnable() { public void run() { try { long d = Long.parseLong(et.getText().toString().trim()); if (d < 1 || d > 3650) { toast("Days must be 1 to 3650"); return; } grantPremium(id, d, "ADMIN"); } catch (Exception e) { toast("Enter days"); } } });
	}
	void verifyDlg() {
		final EditText et = edit(""); et.setHint("paste the user's device id");
		dlg("Unlock premium", "step 1: verify the device id", et, "VERIFY", new Runnable() { public void run() {
				String id = et.getText().toString().trim(); if (id.length() == 0) { toast("Enter a device id"); return; }
				if (D[0] == null || !D[0].hasChild(id)) { dlgC("Device not found", "", tv("No device with this id has opened the app yet. Ask the user to copy the id from Settings > Device information.", 14, cSub, false), null, cInk, null); return; }
				final com.google.firebase.database.DataSnapshot x = D[0].child(id); android.widget.LinearLayout b = lin(true); b.addView(kv("Device ID", id)); b.addView(kv("Model", s(x, "model"))); b.addView(kv("Android", s(x, "androidVer"))); b.addView(kv("Last seen", fmt(ln(x, "lastSeen")))); b.addView(kv("Premium", pl(x) > 0 ? leftTxt(pl(x)) + " left" : "none"));
				dlg("Device verified", "step 2: choose premium days", b, "NEXT", new Runnable() { public void run() { daysDlg(x.getKey(), "Premium days"); } }); } });
	}
	void userDlg(com.google.firebase.database.DataSnapshot x) {
		final String id = x.getKey(); final boolean bn = "true".equals(s(x, "banned")); final long pr = pl(x); final android.app.Dialog[] dd = new android.app.Dialog[1]; android.widget.LinearLayout b = lin(true);
		b.addView(kv("Device ID", id)); b.addView(kv("Model", s(x, "model"))); b.addView(kv("Android", s(x, "androidVer") + "   app v" + s(x, "appVer"))); b.addView(kv("RAM", s(x, "ram"))); b.addView(kv("Root", "true".equals(s(x, "root")) ? "Rooted" : "Not rooted")); b.addView(kv("Shizuku", "true".equals(s(x, "shizuku")) ? "Installed" : "Not available"));
		b.addView(kv("Premium", pr > 0 ? leftTxt(pr) + " left" : "none")); if (pr > 0) { b.addView(kv("Premium key", s(x, "premiumKey"))); b.addView(kv("Expires", fmt(ln(x, "premiumUntil")))); } b.addView(kv("Country", s(x, "countryName").length() > 0 ? s(x, "countryName") + " (" + s(x, "country") + ")" : "not selected")); b.addView(kv("Registered", fmt(ln(x, "createdAt")))); b.addView(kv("Last seen", fmt(ln(x, "lastSeen"))));
		Flow f = new Flow(dp(8)); f.addView(soft("COPY ID", new Runnable() { public void run() { copy(id); } })); f.addView(dark("GIVE PREMIUM", new Runnable() { public void run() { dd[0].dismiss(); daysDlg(id, "Give premium"); } }));
		if (pr > 0) f.addView(red("REVOKE", new Runnable() { public void run() { dd[0].dismiss(); confirm("Remove premium from this device?", new Runnable() { public void run() { revoke(id, false); } }); } }));
		f.addView(btn(bn ? "UNBAN" : "BAN", 0xFFFFFFFF, bn ? cGreen : cRed, new Runnable() { public void run() { db.child("users").child(id).child("banned").setValue(!bn); dd[0].dismiss(); toast(bn ? "Unbanned" : "Banned"); } }));
		f.addView(soft("NOTIFY", new Runnable() { public void run() { dd[0].dismiss(); sendForm(id); } })); f.addView(soft("SUPPORT CHAT", new Runnable() { public void run() { dd[0].dismiss(); chatUid = id; page = 10; all(); } }));
		f.addView(red("DELETE", new Runnable() { public void run() { dd[0].dismiss(); confirm("Delete this device and its data?", new Runnable() { public void run() { db.child("users").child(id).removeValue(); db.child("support").child(id).removeValue(); toast("Deleted"); } }); } }));
		b.addView(f, lp(-1, -2, 0, 14, 0, 0)); dd[0] = dlg(s(x, "model").length() > 0 ? s(x, "model") : "Device", bn ? "banned" : "device", scroll(b, (int) (scrH * 0.58f)), null, null);
	}
	void pgPremium() {
		android.widget.LinearLayout c = card(); android.widget.LinearLayout t = lin(false); t.setGravity(16); t.addView(ib(38, cAmber, 44), lp(dp(44), dp(44), 0, 0, 12, 0)); android.widget.LinearLayout m = lin(true); m.addView(tv("Unlock by device ID", 16, cText, true)); m.addView(tv("verify the id, then choose days", 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); t.addView(m, lw(1f, 0, 0, 0, 0)); c.addView(t);
		c.addView(dark("UNLOCK PREMIUM", new Runnable() { public void run() { verifyDlg(); } }), lp(-2, -2, 0, 12, 0, 0)); bodyBox.addView(c, lp(-1, -2, 0, 0, 0, 12));
		long po1 = pendingOrders(); android.widget.LinearLayout tr1 = row2(); tile(tr1, "Orders", po1 > 0 ? po1 + " waiting" : "approve / reject", 63, cInk, true, new Runnable() { public void run() { page = 12; all(); } }); tile(tr1, "Countries", (D[9] == null ? 0 : D[9].child("countries").getChildrenCount()) + " added", 61, cInk, false, new Runnable() { public void run() { page = 13; all(); } });
		android.widget.LinearLayout tr2 = row2(); tile(tr2, "Plans", "4 plans, days", 62, cInk, true, new Runnable() { public void run() { page = 14; all(); } }); tile(tr2, "Premium page", "video, text, discount", 60, cInk, false, new Runnable() { public void run() { page = 15; all(); } });
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> act1 = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>(), old = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>();
		for (com.google.firebase.database.DataSnapshot x : sorted(D[0], "premiumUntil", false)) { if (pl(x) > 0) act1.add(x); else if (ln(x, "premiumUntil") > 0 || ln(x, "revokedAt") > 0) old.add(x); }
		bodyBox.addView(label("ACTIVE PREMIUM (" + act1.size() + ")"), lp(-2, -2, 4, 0, 0, 10)); for (com.google.firebase.database.DataSnapshot x : act1) premRow(x, true); if (act1.size() == 0) bodyBox.addView(tv("No premium devices", 13, cSub, false), lp(-2, -2, 4, 0, 0, 10));
		if (old.size() > 0) { bodyBox.addView(label("EXPIRED / REVOKED (" + old.size() + ")"), lp(-2, -2, 4, 14, 0, 10)); for (com.google.firebase.database.DataSnapshot x : old) premRow(x, false); }
	}
	void premRow(final com.google.firebase.database.DataSnapshot x, boolean live) {
		final String id = x.getKey(); long pr = pl(x); android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(27, live ? cAmber : cSub, 42), lp(dp(42), dp(42), 0, 0, 12, 0));
		android.widget.LinearLayout m = lin(true); m.addView(tv(s(x, "model").length() > 0 ? s(x, "model") : "Device", 14, cText, true)); TextView idt = tv(id, 11, cSub, false); idt.setSingleLine(true); idt.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); m.addView(idt, lp(-2, -2, 0, 3, 0, 0));
		m.addView(tv(live ? "ends " + fmt(ln(x, "premiumUntil")) + "   |   key " + s(x, "premiumKey") : (ln(x, "revokedAt") > 0 ? "revoked " + fmt(ln(x, "revokedAt")) : "expired " + fmt(ln(x, "premiumUntil"))), 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); top.addView(m, lw(1f, 0, 0, 8, 0)); top.addView(pill(live ? leftTxt(pr) + " left" : "ENDED", live ? cGreen : cSub)); c1.addView(top);
		Flow br = new Flow(dp(8)); br.addView(soft("COPY ID", new Runnable() { public void run() { copy(id); } })); br.addView(dark("+ DAYS", new Runnable() { public void run() { daysDlg(id, "Add premium days"); } }));
		if (live) br.addView(red("REVOKE", new Runnable() { public void run() { confirm("Remove premium from this device?", new Runnable() { public void run() { revoke(id, false); } }); } })); br.addView(red("DELETE", new Runnable() { public void run() { confirm("Delete the premium record of this device?", new Runnable() { public void run() { revoke(id, true); } }); } }));
		c1.addView(br, lp(-1, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
	}
	com.google.firebase.database.DataSnapshot ps(String k) { return D[9] == null ? null : D[9].child(k); }
	com.google.firebase.database.DataSnapshot pp(int i) { com.google.firebase.database.DataSnapshot a = ps("plans"); return a == null ? null : a.child("p" + i); }
	String pName(int i) { String v = s(pp(i), "name"); return v.length() > 0 ? v : PN[i]; }
	long pDays(int i) { long v = ln(pp(i), "days"); return v > 0 ? v : PD[i]; }
	String priceTxt(com.google.firebase.database.DataSnapshot x) { return s(x, "sym") + " " + money(n(x, "price")) + " " + s(x, "cur"); }
	java.util.ArrayList<com.google.firebase.database.DataSnapshot> allOrders() {
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>();
		if (D[8] != null) for (com.google.firebase.database.DataSnapshot u : D[8].getChildren()) for (com.google.firebase.database.DataSnapshot o : u.getChildren()) l.add(o);
		for (int i = 1; i < l.size(); i++) { com.google.firebase.database.DataSnapshot x = l.get(i); int j = i - 1; while (j >= 0 && n(l.get(j), "time") < n(x, "time")) { l.set(j + 1, l.get(j)); j--; } l.set(j + 1, x); }
		return l;
	}
	long pendingOrders() { long c = 0; if (D[8] != null) for (com.google.firebase.database.DataSnapshot u : D[8].getChildren()) for (com.google.firebase.database.DataSnapshot o : u.getChildren()) if ("pending".equals(s(o, "status"))) c++; return c; }
	void approveDlg(final com.google.firebase.database.DataSnapshot x, final String id) {
		final long days = ln(x, "days");
		dlgC("Approve payment?", "device " + id, tv("Give " + days + " day(s) of premium for " + priceTxt(x) + ". The order will then run a " + days + " day cooldown in this list.", 14, cSub, false), "APPROVE", cGreen, new Runnable() { public void run() {
				java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>(); m.put("status", "approved"); m.put("apprAt", now()); m.put("until", now() + days * DAY); x.getRef().updateChildren(m); grantPremium(id, days, "PAID"); } });
	}
	void orderRow(final com.google.firebase.database.DataSnapshot x, final int mode) {
		final String id = s(x, "dev").length() > 0 ? s(x, "dev") : x.getRef().getParent().getKey();
		com.google.firebase.database.DataSnapshot u = D[0] != null && D[0].hasChild(id) ? D[0].child(id) : null; String mdl = s(u, "model").length() > 0 ? s(u, "model") : "Device"; long until = ln(x, "until");
		android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(63, mode == 1 ? cGreen : cInk, 42), lp(dp(42), dp(42), 0, 0, 12, 0));
		android.widget.LinearLayout m = lin(true); m.addView(tv(mdl, 14, cText, true)); TextView idt = tv(id, 11, cSub, false); idt.setSingleLine(true); idt.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); m.addView(idt, lp(-2, -2, 0, 3, 0, 0)); top.addView(m, lw(1f, 0, 0, 8, 0));
		top.addView(pill(mode == 0 ? "PENDING" : (mode == 1 ? leftTxt(Math.max(0, until - now())) + " left" : "EXPIRED"), mode == 1 ? cGreen : (mode == 0 ? cInk : cSub))); c1.addView(top);
		android.widget.LinearLayout b = lin(true); b.addView(kv("Plan", s(x, "plan") + "  |  " + ln(x, "days") + " days")); b.addView(kv("Price", priceTxt(x))); b.addView(kv("Country", s(x, "cname"))); b.addView(kv("Ordered", fmt(ln(x, "time"))));
		if (mode > 0) { b.addView(kv("Approved", fmt(ln(x, "apprAt")))); b.addView(kv("Cooldown ends", fmt(until))); } c1.addView(b, lp(-1, -2, 0, 10, 0, 0));
		Flow br = new Flow(dp(8)); br.addView(soft("COPY ID", new Runnable() { public void run() { copy(id); } }));
		if (mode == 0) { br.addView(btn("APPROVE", 0xFFFFFFFF, cGreen, new Runnable() { public void run() { approveDlg(x, id); } })); br.addView(red("REJECT", new Runnable() { public void run() { confirm("Reject and delete this order?", new Runnable() { public void run() { x.getRef().removeValue(); notifyUser(id, "Payment rejected", "Your payment request could not be verified.", "warning"); toast("Order rejected"); } }); } })); }
		else if (mode == 2) br.addView(red("DELETE", new Runnable() { public void run() { x.getRef().removeValue(); } }));
		c1.addView(br, lp(-1, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
	}
	void pgOrders() {
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> pend = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>(), live = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>(), old = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>();
		for (com.google.firebase.database.DataSnapshot x : allOrders()) { if ("pending".equals(s(x, "status"))) pend.add(x); else if (ln(x, "until") > now()) live.add(x); else old.add(x); }
		bodyBox.addView(label("PENDING (" + pend.size() + ")"), lp(-2, -2, 4, 0, 0, 10)); for (com.google.firebase.database.DataSnapshot x : pend) orderRow(x, 0); if (pend.size() == 0) bodyBox.addView(tv("No orders waiting", 13, cSub, false), lp(-2, -2, 4, 0, 0, 10));
		bodyBox.addView(label("APPROVED, COOLDOWN RUNNING (" + live.size() + ")"), lp(-2, -2, 4, 14, 0, 10)); for (com.google.firebase.database.DataSnapshot x : live) orderRow(x, 1); if (live.size() == 0) bodyBox.addView(tv("None", 13, cSub, false), lp(-2, -2, 4, 0, 0, 10));
		if (old.size() > 0) { bodyBox.addView(label("EXPIRED (" + old.size() + ")"), lp(-2, -2, 4, 14, 0, 10)); for (com.google.firebase.database.DataSnapshot x : old) orderRow(x, 2); }
	}
	void fillCountries(final android.widget.LinearLayout list, String q, final android.app.Dialog[] dd) {
		list.removeAllViews(); String f = q.trim().toLowerCase();
		for (final String[] c : cl()) {
			if (f.length() > 0 && !(c[1].toLowerCase().contains(f) || c[2].toLowerCase().contains(f))) continue;
			boolean added = D[9] != null && D[9].child("countries").hasChild(c[0]);
			android.widget.LinearLayout r = lin(false); r.setGravity(16); r.setPadding(dp(4), dp(11), dp(4), dp(11)); r.addView(tv(c[1], 14, cText, true), lw(1f, 0, 0, 8, 0)); if (added) r.addView(pill("ADDED", cGreen), lp(-2, -2, 0, 0, 8, 0)); r.addView(tv(c[2] + "  " + c[3], 12, cSub, false));
			r.setOnClickListener(ck(new Runnable() { public void run() { if (dd[0] != null) dd[0].dismiss(); countryForm(c[0]); } })); list.addView(r);
			View dv = new View(act); dv.setBackgroundColor(cLine); list.addView(dv, lp(-1, dp(1)));
		}
		pressAll(list);
	}
	void countryPicker() {
		final android.widget.LinearLayout body = lin(true); body.setLayoutParams(lp(-1, (int) (scrH * 0.55f))); final EditText q = edit(""); q.setHint("Search country"); body.addView(q, lp(-1, -2));
		final android.widget.LinearLayout list = lin(true); android.widget.ScrollView sv2 = new android.widget.ScrollView(act); sv2.setVerticalScrollBarEnabled(false); sv2.addView(list); body.addView(sv2, new android.widget.LinearLayout.LayoutParams(-1, 0, 1f));
		final android.app.Dialog[] dd = new android.app.Dialog[1]; fillCountries(list, "", dd);
		q.addTextChangedListener(new android.text.TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int c, int d) {} public void onTextChanged(CharSequence a, int b, int c, int d) {} public void afterTextChanged(android.text.Editable e) { fillCountries(list, e.toString(), dd); } });
		dd[0] = dlg("Add country", "currency and symbol fill automatically", body, null, null);
	}
	void countryForm(final String code) {
		final String[] ci = cInfo(code); if (ci == null) return; final com.google.firebase.database.DataSnapshot ex = D[9] == null ? null : D[9].child("countries").child(code); final boolean isNew = ex == null || !ex.exists();
		String[] spec = {"payName:Payment method name:t:", "payId:Payment ID (the QR code is made from this):t:", "p0:" + pName(0) + " price (" + ci[3] + "):n:0", "p1:" + pName(1) + " price (" + ci[3] + "):n:0", "p2:" + pName(2) + " price (" + ci[3] + "):n:0", "p3:" + pName(3) + " price (" + ci[3] + "):n:0", "active:Visible to users:b:true"};
		form(ci[1] + "  |  " + ci[2] + " " + ci[3], "currency and symbol are set automatically", spec, isNew ? null : ex, new Fcb() { void ok(java.util.HashMap<String, Object> m) {
				if (String.valueOf(m.get("payId")).length() == 0) { toast("Payment ID is required"); return; }
				m.put("name", ci[1]); m.put("cur", ci[2]); m.put("sym", ci[3]); m.put("code", code); if (isNew) m.put("createdAt", now());
				db.child("prem").child("countries").child(code).updateChildren(m); toast("Saved"); } });
	}
	void pgCountries() {
		bodyBox.addView(dark("+ ADD COUNTRY", new Runnable() { public void run() { countryPicker(); } }), lp(-2, -2, 0, 0, 0, 10));
		bodyBox.addView(tv("Pick a country from the list. Currency and symbol fill automatically; you only set the payment ID and the 4 plan prices. Users from a country that is not added here see the first country in this list.", 11, cSub, false), lp(-1, -2, 4, 0, 4, 12)); int cnt = 0;
		for (final com.google.firebase.database.DataSnapshot x : sorted(ps("countries"), "createdAt", false)) { cnt++; final boolean live = !"false".equals(s(x, "active")); String sy = s(x, "sym");
			android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(61, live ? cInk : cSub, 44), lp(dp(44), dp(44), 0, 0, 12, 0));
			android.widget.LinearLayout m = lin(true); m.addView(tv(s(x, "name"), 15, live ? cText : cSub, true)); TextView l2 = tv(s(x, "cur") + " " + sy + "  |  " + s(x, "payName") + "  " + s(x, "payId"), 11, cSub, false); l2.setSingleLine(true); l2.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); m.addView(l2, lp(-2, -2, 0, 3, 0, 0));
			m.addView(tv(sy + money(n(x, "p0")) + "  /  " + sy + money(n(x, "p1")) + "  /  " + sy + money(n(x, "p2")) + "  /  " + sy + money(n(x, "p3")), 11, cBlue, true), lp(-2, -2, 0, 3, 0, 0)); top.addView(m, lw(1f, 0, 0, 8, 0)); top.addView(pill(live ? "LIVE" : "HIDDEN", live ? cGreen : cSub)); c1.addView(top);
			Flow br = new Flow(dp(8)); br.addView(soft("EDIT", new Runnable() { public void run() { countryForm(x.getKey()); } })); br.addView(soft(live ? "HIDE" : "SHOW", new Runnable() { public void run() { x.getRef().child("active").setValue(!live); } }));
			br.addView(red("DELETE", new Runnable() { public void run() { confirm("Delete " + s(x, "name") + " and its payment method?", new Runnable() { public void run() { x.getRef().removeValue(); } }); } })); c1.addView(br, lp(-1, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8)); }
		if (cnt == 0) bodyBox.addView(tv("No countries added yet. Tap ADD COUNTRY.", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void pgPlans() {
		bodyBox.addView(tv("The 4 plans on the user Premium page. Prices are set per country in Countries.", 11, cSub, false), lp(-1, -2, 4, 0, 4, 12));
		for (int i = 0; i < 4; i++) { String[] spec = {"name:Plan name:t:" + PN[i], "days:Days of premium:n:" + PD[i], "tag:Tag (BEST VALUE, optional):t:", "active:Visible:b:true"}; cfgCard(pName(i), pDays(i) + " days", spec, pp(i), "prem/plans/p" + i, 62, cInk); }
	}
	void pgPremText() {
		cfgCard("Go Premium header", "title, text and video link", SPEC_PHEAD, ps("cfg"), "prem/cfg", 60, cInk);
		cfgCard("Payment dialog", "title and text above the QR code", SPEC_PDLG, ps("cfg"), "prem/cfg", 62, cInk);
		cfgCard("Discount banner", "offer text on the premium page", SPEC_PDISC, ps("cfg"), "prem/cfg", 36, cInk);
	}
	String rnd(int len) { String a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; java.util.Random r = new java.util.Random(); StringBuilder b = new StringBuilder(); for (int i = 0; i < len; i++) b.append(a.charAt(r.nextInt(a.length()))); return b.toString(); }
	void codeForm() {
		String[] spec = {"code:Code (blank = auto generate):t:", "days:Premium days:n:30", "max:How many devices (0 = unlimited):n:1", "target:For (all, or one device id):t:all", "hours:Code valid for hours (0 = never expires):n:0"};
		form("Generate code", "premium redeem code", spec, null, new Fcb() { void ok(java.util.HashMap<String, Object> m) {
				String code = String.valueOf(m.get("code")).toUpperCase().replaceAll("[^A-Z0-9_-]", ""); if (code.length() == 0) code = rnd(10); if (D[3] != null && D[3].hasChild(code)) { toast("Code already exists"); return; }
				long days = ((Number) m.get("days")).longValue(); if (days < 1) { toast("Days must be at least 1"); return; } String tg = String.valueOf(m.get("target")).trim(); if (tg.length() == 0 || tg.equalsIgnoreCase("all")) tg = "all"; long hrs = ((Number) m.get("hours")).longValue();
				java.util.HashMap<String, Object> c = new java.util.HashMap<String, Object>(); c.put("days", days); c.put("max", m.get("max")); c.put("used", 0L); c.put("target", tg); c.put("createdAt", now()); c.put("expireAt", hrs > 0 ? now() + hrs * 3600000L : 0L); db.child("codes").child(code).setValue(c); copy(code); } });
	}
	void deleteCode(final String code) {
		if (D[0] != null) for (com.google.firebase.database.DataSnapshot u : D[0].getChildren()) if (code.equals(s(u, "premiumKey")) && "code".equals(s(u, "premiumSrc"))) { java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>(); m.put("premiumUntil", null); m.put("premiumFrom", null); m.put("premiumKey", null); m.put("premiumSrc", null); m.put("revokedAt", now()); u.getRef().updateChildren(m); }
		db.child("codes").child(code).removeValue(); toast("Code deleted, premium removed from its devices");
	}
	void pgCodes() {
		Flow bar = new Flow(dp(8)); bar.addView(dark("+ GENERATE CODE", new Runnable() { public void run() { codeForm(); } })); bodyBox.addView(bar, lp(-1, -2, 0, 0, 0, 12));
		bodyBox.addView(tv("Deleting a code also removes the premium it gave from every device that used it.", 11, cSub, false), lp(-1, -2, 4, 0, 4, 12));
		for (final com.google.firebase.database.DataSnapshot x : sorted(D[3], "createdAt", true)) {
			long ex = ln(x, "expireAt"), mx = ln(x, "max"); boolean expired = ex > 0 && ex <= now(), full = mx > 0 && ln(x, "used") >= mx; int sc = expired || full ? cRed : cGreen;
			android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(26, sc, 44), lp(dp(44), dp(44), 0, 0, 12, 0)); android.widget.LinearLayout m = lin(true); TextView ct = tv(x.getKey(), 17, expired ? cSub : cText, true); ct.setTypeface(android.graphics.Typeface.MONOSPACE, 1); m.addView(ct);
			m.addView(tv(ln(x, "days") + " days   |   devices " + ln(x, "used") + " / " + (mx > 0 ? String.valueOf(mx) : "unlimited") + "   |   " + (s(x, "target").equals("all") ? "for all" : "one device"), 11, cSub, false), lp(-2, -2, 0, 3, 0, 0));
			top.addView(m, lw(1f, 0, 0, 8, 0)); top.addView(pill(expired ? "EXPIRED" : (full ? "FULL" : (ex > 0 ? leftTxt(ex - now()) + " left" : "ACTIVE")), sc)); c1.addView(top);
			Flow br = new Flow(dp(8)); br.addView(soft("COPY", new Runnable() { public void run() { copy(x.getKey()); } })); br.addView(soft("USED BY", new Runnable() { public void run() { android.widget.LinearLayout b = lin(true); int c = 0; for (com.google.firebase.database.DataSnapshot u : x.child("usedBy").getChildren()) { c++; String mdl = D[0] != null && D[0].hasChild(u.getKey()) ? s(D[0].child(u.getKey()), "model") : ""; b.addView(kv(u.getKey(), mdl + " " + ago(Long.parseLong(String.valueOf(u.getValue()))))); } if (c == 0) b.addView(tv("Nobody used this code yet", 13, cSub, false)); dlg("Used by", c + " device(s)", scroll(b, c > 6 ? (int) (scrH * 0.45f) : -2), null, null); } }));
			br.addView(red("DELETE", new Runnable() { public void run() { confirm("Delete code " + x.getKey() + "? Premium from this code will be removed.", new Runnable() { public void run() { deleteCode(x.getKey()); } }); } })); c1.addView(br, lp(-1, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
		}
		if (D[3] == null || !D[3].hasChildren()) bodyBox.addView(tv("No codes yet", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void itemCard(final com.google.firebase.database.DataSnapshot x, String t1, String t2, String img, final String[] spec, final String what) {
		final boolean live = !"false".equals(s(x, "active")); android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16);
		if (img != null && img.length() > 0) { ImageView iv = new ImageView(act); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setBackground(bg(cSoft, 12, 0, 0)); if (android.os.Build.VERSION.SDK_INT >= 21) iv.setClipToOutline(true); top.addView(iv, lp(dp(64), dp(48), 0, 0, 12, 0)); loadImg(iv, img); } else top.addView(ib(6, cSub, 48), lp(dp(48), dp(48), 0, 0, 12, 0));
		android.widget.LinearLayout m = lin(true); m.addView(tv(t1, 15, live ? cText : cSub, true)); m.addView(tv(t2, 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); top.addView(m, lw(1f, 0, 0, 8, 0)); top.addView(pill(live ? "LIVE" : "HIDDEN", live ? cGreen : cSub)); c1.addView(top);
		Flow br = new Flow(dp(8)); br.addView(soft("EDIT", new Runnable() { public void run() { form("Edit " + what, "", spec, x, save(x.getRef())); } })); br.addView(soft(live ? "HIDE" : "SHOW", new Runnable() { public void run() { x.getRef().child("active").setValue(!live); } }));
		br.addView(red("DELETE", new Runnable() { public void run() { confirm("Delete this " + what + "?", new Runnable() { public void run() { x.getRef().removeValue(); } }); } })); c1.addView(br, lp(-1, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
	}
	void topDl() {
		java.util.ArrayList<Object[]> rows = new java.util.ArrayList<Object[]>(); long tot = 0;
		if (D[10] != null) for (String[] ck0 : cats()) for (com.google.firebase.database.DataSnapshot x : D[10].child(ck0[0]).getChildren()) { long c = ln(x, "dlCount"); tot += c; if (c > 0) rows.add(new Object[]{Long.valueOf(c), Long.valueOf(ln(x, "dlUsers")), s(x, "title"), ck0[1]}); }
		java.util.Collections.sort(rows, new java.util.Comparator<Object[]>() { public int compare(Object[] a, Object[] b) { return Long.compare(((Long) b[0]).longValue(), ((Long) a[0]).longValue()); } });
		android.widget.LinearLayout b = lin(true); b.addView(kv("Total downloads", nf(tot))); int cx = 0;
		for (Object[] r : rows) { if (++cx > 15) break; android.widget.LinearLayout row = lin(true); row.addView(tv(cx + ".  " + r[2], 13, cText, true)); row.addView(tv(r[3] + "  |  " + nf(((Long) r[0]).longValue()) + " downloads  |  " + nf(((Long) r[1]).longValue()) + " users", 11, cSub, false), lp(-2, -2, 0, 2, 0, 0)); b.addView(row, lp(-1, -2, 0, 10, 0, 0)); }
		if (rows.size() == 0) b.addView(tv("No downloads yet", 13, cSub, false), lp(-2, -2, 0, 10, 0, 0));
		dlg("Top downloads", "most installed items", scroll(b, (int) (scrH * 0.55f)), "CLOSE", new Runnable() { public void run() {} });
	}
	int catSel = 0;
	final String[] CAT_K0 = {"drone", "damage", "bg", "map", "cfg", "hero"};
	final String[] CAT_N0 = {"Drone View", "Damage Drone", "Custom Background", "Map Version", "Custom Config", "1 Hero"};
	java.util.ArrayList<String[]> cats() {
		java.util.ArrayList<String[]> l = new java.util.ArrayList<String[]>(); for (int i = 0; i < CAT_K0.length; i++) l.add(new String[]{CAT_K0[i], CAT_N0[i]});
		if (D[2] != null) for (com.google.firebase.database.DataSnapshot x : sorted(D[2], "order", false)) { String k = x.getKey(); if (k != null && k.startsWith("c_")) l.add(new String[]{k, s(x, "title").length() > 0 ? s(x, "title") : "Menu"}); }
		return l;
	}
	final String[] SPEC_MENU = {"title:Title:t:", "desc:Information text:t:", "icon:Built-in icon (used when no image URL):s:4:4=Drone|5=Target|6=Image|7=Map|8=Config|12=Shield|16=Send|23=Eye|27=Crown|31=User|36=Star|37=Bolt|38=Key|60=Hero|61=Globe|63=Phone|64=Play|65=Heart|66=Gift|67=Fire|68=Music|69=Camera|70=Game|71=Bell|72=Cloud|73=Download|74=Home|75=Diamond|76=Cube|77=Layers|78=Flag", "image:Icon image URL (direct .png/.jpg link):t:", "premium:Premium only:b:false", "active:Visible:b:true", "order:Order:n:10"};
	void menuCard(final com.google.firebase.database.DataSnapshot x) {
		final boolean live = !"false".equals(s(x, "active")); android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); String im = s(x, "image").trim();
		if (im.length() > 0) { ImageView iv = new ImageView(act); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setBackground(bg(cSoft, 14, 0, 0)); if (android.os.Build.VERSION.SDK_INT >= 21) iv.setClipToOutline(true); top.addView(iv, lp(dp(46), dp(46), 0, 0, 12, 0)); loadImg(iv, im); } else top.addView(ib(x.hasChild("icon") ? (int) n(x, "icon") : 4, live ? cInk : cSub, 46), lp(dp(46), dp(46), 0, 0, 12, 0));
		android.widget.LinearLayout mm = lin(true); mm.addView(tv(s(x, "title").length() > 0 ? s(x, "title") : "(no title)", 15, live ? cText : cSub, true)); mm.addView(tv(s(x, "desc"), 11, cSub, false), lp(-1, -2, 0, 3, 0, 0)); mm.addView(tv("CUSTOM MENU  |  " + x.getKey() + "  |  " + (D[10] == null ? 0 : D[10].child(x.getKey()).getChildrenCount()) + " items", 10, cBlue, true), lp(-2, -2, 0, 3, 0, 0));
		top.addView(mm, lw(1f, 0, 0, 8, 0)); android.widget.LinearLayout pc = lin(true); pc.setGravity(android.view.Gravity.END); pc.addView(pill(live ? "LIVE" : "HIDDEN", live ? cGreen : cSub)); if ("true".equals(s(x, "premium"))) pc.addView(pill("PREMIUM", cAmber), lp(-2, -2, 0, 4, 0, 0)); top.addView(pc); c1.addView(top);
		Flow br = new Flow(dp(8));
		br.addView(dark("OPEN ITEMS", new Runnable() { public void run() { java.util.ArrayList<String[]> cs = cats(); for (int i = 0; i < cs.size(); i++) if (cs.get(i)[0].equals(x.getKey())) catSel = i; page = 16; all(); } }));
		br.addView(soft("EDIT", new Runnable() { public void run() { form("Edit menu", "changes go live instantly", SPEC_MENU, x, save(x.getRef())); } }));
		br.addView(soft(live ? "HIDE" : "SHOW", new Runnable() { public void run() { x.getRef().child("active").setValue(!live); } }));
		br.addView(red("DELETE", new Runnable() { public void run() { confirm("Delete this menu and all its items?", new Runnable() { public void run() { String k = x.getKey(); db.child("cat").child(k).removeValue(); db.child("catcfg").child(k).removeValue(); x.getRef().removeValue(); catSel = 0; } }); } }));
		c1.addView(br, lp(-1, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
	}
	final String[] PAL_N = {"Slate", "Ocean", "Emerald", "Violet", "Rose", "Amber", "Night", "Sunset", "Teal", "Indigo", "Mocha", "Midnight", "Forest"};
	final String[] SPEC_CAT = {"title:Title:t:", "desc:Description:t:", "link:Zip link:t:", "image:Image or video URL:t:", "ver:Version tag (change it to show UPDATE):t:", "btn:Button text:t:DOWNLOAD", "premium:Premium only:b:false", "order:Order:n:1", "active:Visible:b:true"};
	final String[] SPEC_REWARD = {"trialOn:Free trial for new users:b:false", "trialDays:Trial days:n:1", "dailyOn:Daily reward:b:false", "dailyHours:Daily reward (hours of premium):n:2", "dailyBonusHours:Day 7 bonus (hours of premium):n:12", "dailyMaxDev:Daily reward device limit (0 = unlimited):n:0"};
	final String[] SPEC_FAQ = {"q:Question:t:", "a:Answer:t:", "order:Order:n:1", "active:Visible:b:true"};
	void pgCatalog() {
		final java.util.ArrayList<String[]> cs = cats(); if (catSel >= cs.size()) catSel = 0; final String k = cs.get(catSel)[0], nm = cs.get(catSel)[1];
		Flow fl = new Flow(dp(8));
		for (int i = 0; i < cs.size(); i++) { final int ix = i; Runnable go = new Runnable() { public void run() { catSel = ix; all(); } }; fl.addView(i == catSel ? dark(cs.get(i)[1], go) : soft(cs.get(i)[1], go)); }
		bodyBox.addView(fl, lp(-1, -2, 0, 0, 0, 12));
		final com.google.firebase.database.DataSnapshot cf = D[11] == null ? null : D[11].child(k);
		int pi = (int) n(cf, "pal"); if (pi < 0 || pi >= PAL_N.length) pi = 0;
		android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16);
		android.widget.LinearLayout tm = lin(true); tm.addView(tv("Screen look", 15, cText, true));
		tm.addView(tv((s(cf, "head").length() > 0 ? s(cf, "head") : nm.toUpperCase()) + "  |  theme " + PAL_N[pi], 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); top.addView(tm, lw(1f, 0, 0, 8, 0));
		top.addView(soft("EDIT LOOK", new Runnable() { public void run() { form("Look of " + nm, "screen title, search hint and color theme", new String[]{"head:Screen title:t:" + nm.toUpperCase(), "hint:Search hint:t:Search by title", "pal:Color theme:s:0:0=Slate|1=Ocean|2=Emerald|3=Violet|4=Rose|5=Amber|6=Night|7=Sunset|8=Teal|9=Indigo|10=Mocha|11=Midnight|12=Forest", "tutVideo:Tutorial video link (optional):t:", "tutSteps:Tutorial steps (separate with |):t:", "showDl:Show download count to users:b:false"}, cf, save(db.child("catcfg").child(k))); } }));
		c1.addView(top); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 12));
		bodyBox.addView(dark("+ ADD ITEM", new Runnable() { public void run() { form("New item", "shows in the " + nm + " screen", SPEC_CAT, null, push("cat/" + k, true)); } }), lp(-2, -2, 0, 0, 0, 12));
		bodyBox.addView(soft("TOP DOWNLOADS", new Runnable() { public void run() { topDl(); } }), lp(-2, -2, 0, 0, 0, 12));
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l = sorted(D[10] == null ? null : D[10].child(k), "order", false);
		for (com.google.firebase.database.DataSnapshot x : l) itemCard(x, s(x, "title").length() > 0 ? s(x, "title") : "(no title)", ("true".equals(s(x, "premium")) ? "PREMIUM" : "FREE") + "  |  order " + s(x, "order") + (s(x, "link").length() > 0 ? "" : "  |  NO LINK") + "  |  " + nf(ln(x, "dlCount")) + " dl, " + nf(ln(x, "dlUsers")) + " users", s(x, "image"), SPEC_CAT, "item");
		if (l.size() == 0) bodyBox.addView(tv("No items yet", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void pgFaq() {
		bodyBox.addView(dark("+ ADD QUESTION", new Runnable() { public void run() { form("New question", "shows in the Support tab of the user app", SPEC_FAQ, null, push("faq", false)); } }), lp(-2, -2, 0, 0, 0, 12));
		for (com.google.firebase.database.DataSnapshot x : sorted(D[12], "order", false)) { String a = s(x, "a"); if (a.length() > 60) a = a.substring(0, 60) + "..."; itemCard(x, s(x, "q").length() > 0 ? s(x, "q") : "(no question)", "order " + s(x, "order") + "  |  " + a, "", SPEC_FAQ, "question"); }
		if (D[12] == null || !D[12].hasChildren()) bodyBox.addView(tv("No questions yet", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void pgSlider() {
		android.widget.LinearLayout tc = card(); android.widget.LinearLayout tt = lin(false); tt.setGravity(16); tt.addView(ib(30, cBlue, 42), lp(dp(42), dp(42), 0, 0, 12, 0)); android.widget.LinearLayout tm = lin(true); tm.addView(tv("Slide timing", 15, cText, true)); tm.addView(tv("auto slide every " + (D[6] != null && D[6].hasChild("slideSec") ? s(D[6], "slideSec") : "4") + " seconds", 11, cSub, false), lp(-2, -2, 0, 3, 0, 0)); tt.addView(tm, lw(1f, 0, 0, 8, 0));
		tt.addView(soft("SET SECONDS", new Runnable() { public void run() { form("Slide timing", "how long each image stays", new String[]{"slideSec:Seconds per slide:n:4"}, D[6], save(db.child("config"))); } })); tc.addView(tt); bodyBox.addView(tc, lp(-1, -2, 0, 0, 0, 12));
		bodyBox.addView(dark("+ ADD SLIDE", new Runnable() { public void run() { form("New slide", "image loads from the link in the user app", SPEC_SLIDE, null, push("slides", false)); } }), lp(-2, -2, 0, 0, 0, 12));
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l = sorted(D[1], "order", false); for (com.google.firebase.database.DataSnapshot x : l) itemCard(x, s(x, "title").length() > 0 ? s(x, "title") : "(no title)", (s(x, "url").length() > 0 ? "has link  |  " : "") + "order " + s(x, "order"), s(x, "image"), SPEC_SLIDE, "slide");
		if (l.size() == 0) bodyBox.addView(tv("No slides yet", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void pgMenus() {
		bodyBox.addView(tv("The 6 tool cards on the home screen. Type the Activity class name each card should open (create the activity later in Sketchware).", 11, cSub, false), lp(-1, -2, 4, 0, 4, 12));
		for (int i = 0; i < 6; i++) {
			final int ix = i; final com.google.firebase.database.DataSnapshot m = D[2] == null ? null : D[2].child("m" + i); boolean live = !"false".equals(s(m, "active")); android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); top.addView(ib(MENU_IC[i], live ? cInk : cSub, 46), lp(dp(46), dp(46), 0, 0, 12, 0));
			android.widget.LinearLayout mm = lin(true); mm.addView(tv(s(m, "title").length() > 0 ? s(m, "title") : MENU_T[i], 15, live ? cText : cSub, true)); mm.addView(tv(s(m, "desc").length() > 0 ? s(m, "desc") : MENU_D[i], 11, cSub, false), lp(-1, -2, 0, 3, 0, 0));
			mm.addView(tv("opens " + (s(m, "act").length() > 0 ? s(m, "act") : MENU_A[i]), 11, cBlue, true), lp(-2, -2, 0, 3, 0, 0)); top.addView(mm, lw(1f, 0, 0, 8, 0)); android.widget.LinearLayout pc = lin(true); pc.setGravity(android.view.Gravity.END); pc.addView(pill(live ? "LIVE" : "HIDDEN", live ? cGreen : cSub)); if ("true".equals(s(m, "premium"))) pc.addView(pill("PREMIUM", cAmber), lp(-2, -2, 0, 4, 0, 0)); top.addView(pc); c1.addView(top);
			c1.addView(dark("EDIT", new Runnable() { public void run() { String[] spec = {"title:Title:t:" + MENU_T[ix], "desc:Information text:t:" + MENU_D[ix], "act:Activity class name:t:" + MENU_A[ix], "premium:Premium only:b:false", "active:Visible:b:true", "order:Order:n:" + ix}; form("Edit tool " + (ix + 1), "changes go live instantly", spec, m, save(db.child("menus").child("m" + ix))); } }), lp(-2, -2, 0, 12, 0, 0)); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
		}
		bodyBox.addView(tv("YOUR OWN MENUS. They show on the user home screen with their own page, items and downloads. Needs one Sketchware activity named CustomMenu (use CustomMenu_onCreate.java).", 11, cSub, false), lp(-1, -2, 4, 8, 4, 10));
		bodyBox.addView(dark("+ NEW MENU", new Runnable() { public void run() { form("New menu", "appears on the user home screen", SPEC_MENU, null, save(db.child("menus").child("c_" + System.currentTimeMillis()))); } }), lp(-2, -2, 0, 0, 0, 12));
		int cn = 0; if (D[2] != null) for (com.google.firebase.database.DataSnapshot x : sorted(D[2], "order", false)) { String kk = x.getKey(); if (kk != null && kk.startsWith("c_")) { menuCard(x); cn++; } }
		if (cn == 0) bodyBox.addView(tv("No custom menus yet", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void pgEvents() {
		bodyBox.addView(dark("+ ADD EVENT", new Runnable() { public void run() { form("New event", "shows in the Events tab", SPEC_EVENT, null, push("events", true)); } }), lp(-2, -2, 0, 0, 0, 12));
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l = sorted(D[4], "time", true); for (com.google.firebase.database.DataSnapshot x : l) itemCard(x, s(x, "title"), (s(x, "tag").length() > 0 ? s(x, "tag") + "  |  " : "") + fmt(ln(x, "time")), s(x, "image"), SPEC_EVENT, "event");
		if (l.size() == 0) bodyBox.addView(tv("No events yet", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void sendForm(String to) {
		String[] spec = {"to:Send to (all or a device id):t:" + to, "type:Style:s:info:info=Info|offer=Offer|success=Success|warning=Warning", "title:Title:t:", "body:Message:t:", "image:Image URL (optional):t:", "url:Button link (optional):t:"};
		form("Send notification", "users can like and comment on it", spec, null, new Fcb() { void ok(java.util.HashMap<String, Object> m) {
				if (String.valueOf(m.get("title")).length() == 0) { toast("Title is empty"); return; } String tg = String.valueOf(m.get("to")).trim(); if (tg.length() == 0) tg = "all"; m.put("to", tg.equalsIgnoreCase("all") ? "all" : tg);
				m.put("time", com.google.firebase.database.ServerValue.TIMESTAMP); m.put("viewCount", 0L); m.put("likeCount", 0L); m.put("commentCount", 0L); db.child("notifs").push().setValue(m); toast("Sent"); } });
	}
	void notifDlg(final com.google.firebase.database.DataSnapshot x) {
		final String nid = x.getKey(); final android.widget.LinearLayout b = lin(true); final TextView vT = tv(nf(ln(x, "viewCount")), 13, cText, true), lT = tv(nf(ln(x, "likeCount")), 13, cText, true), cT = tv(nf(ln(x, "commentCount")), 13, cText, true);
		b.addView(kv("Sent", fmt(ln(x, "time")))); b.addView(kv("To", s(x, "to").equals("all") ? "everyone" : s(x, "to")));
		android.widget.LinearLayout r1 = lin(false); r1.addView(tv("Users who saw it", 12, cSub, false), lw(1f, 0, 0, 0, 0)); r1.addView(vT); b.addView(r1, lp(-1, -2, 0, 4, 0, 4)); android.widget.LinearLayout r2 = lin(false); r2.addView(tv("Likes", 12, cSub, false), lw(1f, 0, 0, 0, 0)); r2.addView(lT); b.addView(r2, lp(-1, -2, 0, 4, 0, 4));
		android.widget.LinearLayout r3 = lin(false); r3.addView(tv("Comments", 12, cSub, false), lw(1f, 0, 0, 0, 0)); r3.addView(cT); b.addView(r3, lp(-1, -2, 0, 4, 0, 10)); final android.widget.LinearLayout list = lin(true); b.addView(list);
		db.child("views").child(nid).addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() { public void onDataChange(com.google.firebase.database.DataSnapshot d) { vT.setText(nf(d.getChildrenCount())); } public void onCancelled(com.google.firebase.database.DatabaseError e) {} });
		db.child("likes").child(nid).addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() { public void onDataChange(com.google.firebase.database.DataSnapshot d) { lT.setText(nf(d.getChildrenCount())); } public void onCancelled(com.google.firebase.database.DatabaseError e) {} });
		db.child("comments").child(nid).addValueEventListener(new com.google.firebase.database.ValueEventListener() { public void onDataChange(com.google.firebase.database.DataSnapshot d) {
				list.removeAllViews(); cT.setText(nf(d.getChildrenCount())); for (final com.google.firebase.database.DataSnapshot c : sorted(d, "time", false)) { android.widget.LinearLayout r = lin(true); r.setPadding(dp(12), dp(10), dp(12), dp(10)); r.setBackground(bg(cWhite, 14, 0, 0)); android.widget.LinearLayout h = lin(false); h.setGravity(16);
					h.addView(tv(s(c, "name") + "  (" + s(c, "dev") + ")", 11, cText, true), lw(1f, 0, 0, 8, 0)); View del = ic(24, 16, cSub); del.setOnClickListener(ck(new Runnable() { public void run() { c.getRef().removeValue(); db.child("notifs").child(nid).child("commentCount").runTransaction(new com.google.firebase.database.Transaction.Handler() { public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m) { m.setValue(Math.max(0L, lv(m) - 1L)); return com.google.firebase.database.Transaction.success(m); } public void onComplete(com.google.firebase.database.DatabaseError e, boolean ok, com.google.firebase.database.DataSnapshot dd) {} }); } })); h.addView(del, lp(dp(16), dp(16)));
					r.addView(h); r.addView(tv(s(c, "text") + "   " + ago(ln(c, "time")), 12, cSub, false), lp(-1, -2, 0, 4, 0, 0)); list.addView(r, lp(-1, -2, 0, 0, 0, 6)); } if (!d.hasChildren()) list.addView(tv("No comments", 12, cSub, false)); pressAll(list); } public void onCancelled(com.google.firebase.database.DatabaseError e) {} });
		b.addView(red("DELETE NOTIFICATION", new Runnable() { public void run() { confirm("Delete this notification with all its likes and comments?", new Runnable() { public void run() { db.child("notifs").child(nid).removeValue(); db.child("views").child(nid).removeValue(); db.child("likes").child(nid).removeValue(); db.child("comments").child(nid).removeValue(); toast("Deleted"); } }); } }), lp(-2, -2, 0, 12, 0, 0));
		dlg(s(x, "title"), "notification details", scroll(b, (int) (scrH * 0.58f)), null, null);
	}
	void pgNotify() {
		Flow bar = new Flow(dp(8)); bar.addView(dark("+ SEND NOTIFICATION", new Runnable() { public void run() { sendForm("all"); } })); bodyBox.addView(bar, lp(-1, -2, 0, 0, 0, 12));
		for (final com.google.firebase.database.DataSnapshot x : sorted(D[5], "time", true)) {
			android.widget.LinearLayout c1 = card(); android.widget.LinearLayout top = lin(false); top.setGravity(16); String im = s(x, "image");
			if (im.length() > 0) { ImageView iv = new ImageView(act); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setBackground(bg(cSoft, 12, 0, 0)); if (android.os.Build.VERSION.SDK_INT >= 21) iv.setClipToOutline(true); top.addView(iv, lp(dp(56), dp(56), 0, 0, 12, 0)); loadImg(iv, im); } else top.addView(ib(0, cBlue, 46), lp(dp(46), dp(46), 0, 0, 12, 0));
			android.widget.LinearLayout m = lin(true); m.addView(tv(s(x, "title"), 14, cText, true)); if (s(x, "body").length() > 0) { TextView bt = tv(s(x, "body"), 12, cSub, false); bt.setMaxLines(2); m.addView(bt, lp(-2, -2, 0, 3, 0, 0)); } m.addView(tv("to " + (s(x, "to").equals("all") ? "everyone" : s(x, "to")) + "  |  " + ago(ln(x, "time")), 10, cSub, false), lp(-2, -2, 0, 4, 0, 0)); top.addView(m, lw(1f, 0, 0, 0, 0)); c1.addView(top);
			android.widget.LinearLayout st = lin(false); st.setGravity(16); String[] sv2 = {nf(ln(x, "viewCount")), nf(ln(x, "likeCount")), nf(ln(x, "commentCount"))}; int[] ii = {23, 21, 22}; int[] cc = {cBlue, cRed, cPurple}; for (int k = 0; k < 3; k++) { android.widget.LinearLayout p = lin(false); p.setGravity(16); p.setPadding(dp(10), dp(6), dp(12), dp(6)); p.setBackground(bg(al(cc[k], 0x1A), 12, 0, 0)); p.addView(ic(ii[k], 15, cc[k]), lp(dp(15), dp(15), 0, 0, 6, 0)); p.addView(tv(sv2[k], 12, cc[k], true)); st.addView(p, lp(-2, -2, 0, 0, 8, 0)); }
			c1.addView(st, lp(-1, -2, 0, 12, 0, 0)); c1.setOnClickListener(ck(new Runnable() { public void run() { notifDlg(x); } })); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
		}
		if (D[5] == null || !D[5].hasChildren()) bodyBox.addView(tv("No notifications yet", 13, cSub, false), lp(-2, -2, 4, 4, 0, 0));
	}
	void pgSupport() {
		int shown = 0;
		for (final com.google.firebase.database.DataSnapshot x : sorted(D[7], "meta/lastTime", true)) {
			com.google.firebase.database.DataSnapshot m = x.child("meta"); if (!m.exists()) continue; shown++; String nm = s(m, "name").length() > 0 ? s(m, "name") : "Device"; long un = ln(m, "unreadAdmin");
			android.widget.LinearLayout c1 = card(); c1.setPadding(dp(14), dp(12), dp(14), dp(12)); if (un > 0) c1.setBackground(bg(cCard, 22, al(cBlue, 0x99), 1)); android.widget.LinearLayout r = lin(false); r.setGravity(16);
			android.widget.FrameLayout av = new android.widget.FrameLayout(act); av.setBackground(bg(avc(x.getKey()), 22, 0, 0)); TextView it = tv(ini(nm), 17, 0xFFFFFFFF, true); it.setGravity(17); av.addView(it, new android.widget.FrameLayout.LayoutParams(-1, -1)); r.addView(av, lp(dp(44), dp(44), 0, 0, 12, 0));
			android.widget.LinearLayout mm = lin(true); android.widget.LinearLayout nr = lin(false); nr.setGravity(16); nr.addView(tv(nm, 14, cText, true)); if (s(m, "topic").length() > 0) nr.addView(pill(s(m, "topic"), cPurple), lp(-2, -2, 8, 0, 0, 0)); mm.addView(nr);
			TextView lm = tv(("admin".equals(s(m, "lastFrom")) ? "You: " : "") + s(m, "lastMsg"), 12, un > 0 ? cText : cSub, un > 0); lm.setSingleLine(true); lm.setEllipsize(android.text.TextUtils.TruncateAt.END); mm.addView(lm, lp(-2, -2, 0, 4, 0, 0)); r.addView(mm, lw(1f, 0, 0, 8, 0));
			android.widget.LinearLayout rt = lin(true); rt.setGravity(android.view.Gravity.END); rt.addView(tv(ago(ln(m, "lastTime")), 10, cSub, false)); if (un > 0) { TextView bd = tv(String.valueOf(un), 10, 0xFFFFFFFF, true); bd.setGravity(17); bd.setPadding(dp(7), dp(3), dp(7), dp(3)); bd.setBackground(bg(cBlue, 10, 0, 0)); rt.addView(bd, lp(-2, -2, 0, 6, 0, 0)); } r.addView(rt);
			c1.addView(r); c1.setOnClickListener(ck(new Runnable() { public void run() { chatUid = x.getKey(); page = 10; all(); } })); bodyBox.addView(c1, lp(-1, -2, 0, 0, 0, 8));
		}
		if (shown == 0) { android.widget.LinearLayout em = lin(true); em.setGravity(17); em.addView(ib(17, cSub, 64), lp(dp(64), dp(64))); em.addView(tv("No support chats yet", 15, cSub, true), lp(-2, -2, 0, 14, 0, 0)); bodyBox.addView(em, lp(-1, -2, 0, 50, 0, 0)); }
	}
	String chatName() { com.google.firebase.database.DataSnapshot m = D[7] == null ? null : D[7].child(chatUid).child("meta"); String nm = s(m, "name"); return nm.length() > 0 ? nm : "Chat"; }
	android.widget.LinearLayout bubbleA(final com.google.firebase.database.DataSnapshot x) {
		boolean mine = "admin".equals(s(x, "from")); android.widget.LinearLayout row = lin(false); row.setGravity(mine ? android.view.Gravity.END : android.view.Gravity.START); android.widget.LinearLayout b = lin(true); b.setPadding(dp(14), dp(10), dp(14), dp(8)); b.setBackground(bg(mine ? cInk : cCard, 18, mine ? 0 : cStroke, 1));
		TextView t = tv(s(x, "text"), 14, mine ? 0xFFFFFFFF : cText, false); t.setMaxWidth((int) (scrW * 0.68f)); b.addView(t, lp(-2, -2)); long tm = ln(x, "time"); android.widget.LinearLayout mr = lin(false); mr.setGravity(android.view.Gravity.END | 16);
		mr.addView(tv(tm > 0 ? new java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()).format(new java.util.Date(tm)) : "...", 10, mine ? 0xFFB4BEC8 : cSub, false)); if (mine) { boolean sn = "true".equals(s(x, "seen")); mr.addView(tv(sn ? "  \u2713\u2713 Seen" : "  \u2713 Sent", 10, sn ? 0xFF6CB6FF : 0xFFB4BEC8, true)); } b.addView(mr, lp(-1, -2, 0, 4, 0, 0));
		b.setOnLongClickListener(new View.OnLongClickListener() { public boolean onLongClick(View v) { confirm("Delete this message?", new Runnable() { public void run() { x.getRef().removeValue(); } }); return true; } }); row.addView(b, lp(-2, -2)); return row;
	}
	void pgChat() {
		final com.google.firebase.database.DataSnapshot c = D[7] == null ? null : D[7].child(chatUid); com.google.firebase.database.DataSnapshot ms = c == null ? null : c.child("msgs");
		Flow af = new Flow(dp(8)); af.addView(soft("DEVICE INFO", new Runnable() { public void run() { if (D[0] != null && D[0].hasChild(chatUid)) userDlg(D[0].child(chatUid)); else toast("Device not found"); } })); af.addView(red("DELETE CHAT", new Runnable() { public void run() { confirm("Delete this whole conversation?", new Runnable() { public void run() { db.child("support").child(chatUid).removeValue(); page = 9; all(); } }); } }));
		bodyBox.addView(af, lp(-1, -2, 0, 0, 0, 8)); bodyBox.addView(tv("Long press a message to delete it", 11, cSub, false), lp(-2, -2, 4, 0, 0, 10)); String lastD = "";
		for (com.google.firebase.database.DataSnapshot x : sorted(ms, "time", false)) { long tm = ln(x, "time"); if (tm > 0) { String dl = new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(new java.util.Date(tm)); if (!dl.equals(lastD)) { lastD = dl; TextView sp1 = tv(dl, 11, cSub, true); sp1.setPadding(dp(12), dp(5), dp(12), dp(5)); sp1.setBackground(bg(cSoft, 10, 0, 0)); android.widget.LinearLayout w = lin(false); w.setGravity(17); w.addView(sp1); bodyBox.addView(w, lp(-1, -2, 0, 8, 0, 10)); } }
			bodyBox.addView(bubbleA(x), lp(-1, -2, 0, 0, 0, 8)); if ("user".equals(s(x, "from")) && !"true".equals(s(x, "seen"))) x.getRef().child("seen").setValue(true); }
		if (c != null && n(c.child("meta"), "unreadAdmin") > 0) db.child("support").child(chatUid).child("meta").child("unreadAdmin").setValue(0); if (svB != null) svB.post(new Runnable() { public void run() { svB.fullScroll(View.FOCUS_DOWN); } });
	}
	void sendAdmin() {
		final String txt = chatEt.getText().toString().trim(); if (txt.length() == 0 || chatUid.length() == 0) return; com.google.firebase.database.DatabaseReference r = db.child("support").child(chatUid);
		java.util.HashMap<String, Object> m = new java.util.HashMap<String, Object>(); m.put("from", "admin"); m.put("text", txt); m.put("time", com.google.firebase.database.ServerValue.TIMESTAMP); m.put("seen", false); r.child("msgs").push().setValue(m);
		java.util.HashMap<String, Object> mt = new java.util.HashMap<String, Object>(); mt.put("lastMsg", txt.length() > 80 ? txt.substring(0, 80) : txt); mt.put("lastTime", com.google.firebase.database.ServerValue.TIMESTAMP); mt.put("lastFrom", "admin"); r.child("meta").updateChildren(mt);
		r.child("meta").child("unreadUser").runTransaction(new com.google.firebase.database.Transaction.Handler() { public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData d) { d.setValue(lv(d) + 1L); return com.google.firebase.database.Transaction.success(d); } public void onComplete(com.google.firebase.database.DatabaseError e, boolean ok, com.google.firebase.database.DataSnapshot d) {} }); chatEt.setText("");
	}
	void pgMore() {
		long sc = supCount(); android.widget.LinearLayout r = row2(); tile(r, "Codes", activeCodes() + " active", 26, cPurple, true, new Runnable() { public void run() { page = 5; all(); } }); tile(r, "Slider", (D[1] == null ? 0 : D[1].getChildrenCount()) + " slides", 6, cBlue, false, new Runnable() { public void run() { page = 6; all(); } });
		r = row2(); tile(r, "Menus", "6 tool cards", 32, cInk, true, new Runnable() { public void run() { page = 7; all(); } }); tile(r, "Events", (D[4] == null ? 0 : D[4].getChildrenCount()) + " posts", 2, cGreen, false, new Runnable() { public void run() { page = 8; all(); } });
		r = row2(); tile(r, "Support", sc > 0 ? sc + " waiting" : "customer chat", 17, cBlue, true, new Runnable() { public void run() { page = 9; all(); } }); tile(r, "Settings", "app, update, control", 3, cAmber, false, new Runnable() { public void run() { page = 11; all(); } });
		r = row2(); tile(r, "Catalog", cats().size() + " menu download lists", 8, cPurple, true, new Runnable() { public void run() { page = 16; all(); } }); tile(r, "FAQ", (D[12] == null ? 0 : D[12].getChildrenCount()) + " questions", 17, cBlue, false, new Runnable() { public void run() { page = 17; all(); } });
	}
	void render() {
		if (!unlocked || bodyBox == null) return; bodyBox.removeAllViews();
		switch (page) { case 0: pgDash(); break; case 1: pgUsers(); break; case 2: pgPremium(); break; case 3: pgNotify(); break; case 4: pgMore(); break; case 5: pgCodes(); break; case 6: pgSlider(); break; case 7: pgMenus(); break; case 8: pgEvents(); break; case 9: pgSupport(); break; case 10: pgChat(); break; case 12: pgOrders(); break; case 13: pgCountries(); break; case 14: pgPlans(); break; case 15: pgPremText(); break; case 16: pgCatalog(); break; case 17: pgFaq(); break;
			default: langCard(); themeCard(); cfgCard("App info", "name and about text", SPEC_APP, D[6], "config", 33, cBlue); cfgCard("Home theme", "color theme of the home screen", SPEC_THEME, D[6], "config", 8, cPurple); cfgCard("App control", "maintenance and ban message", SPEC_CTRL, D[6], "config", 3, cRed); cfgCard("App update", "shows an update dialog in the user app", SPEC_UPD, D[6], "config", 37, cPurple); cfgCard("Customer support", "chat topics and welcome text", SPEC_SUP, D[6], "config", 17, cBlue); cfgCard("Rewards", "free trial and daily reward", SPEC_REWARD, D[6], "config", 27, cAmber); }
		pressAll(bodyBox);
	}
	String subTitle() { switch (page) { case 0: return "live overview"; case 1: return (D[0] == null ? 0 : D[0].getChildrenCount()) + " devices"; case 2: return "unlock, extend and revoke"; case 3: return "send and track messages"; case 4: return "all other tools"; case 5: return "premium redeem codes"; case 6: return "home image slider"; case 7: return "home tool cards"; case 8: return "news in the Events tab"; case 9: return supCount() + " waiting"; case 10: return "reply to this device"; case 12: return pendingOrders() + " waiting"; case 13: return "payment method and prices"; case 14: return "the 4 premium plans"; case 15: return "video, text and discount"; case 16: return "downloads for the 6 tools"; case 17: return "answers shown in the Support tab"; default: return "controls the user app"; } }
	void header() {
		hdr.removeAllViews(); hdr.setGravity(16); boolean sub = page >= 5;
		if (sub) { android.widget.FrameLayout bk = new android.widget.FrameLayout(act); bk.setBackground(bg(cCard, 14, cStroke, 1)); bk.addView(ic(18, 20, cText), new android.widget.FrameLayout.LayoutParams(dp(20), dp(20), 17)); bk.setOnClickListener(ck(new Runnable() { public void run() { page = page == 10 ? 9 : (page == 16 || page == 17 ? 4 : (page >= 12 ? 2 : 4)); all(); } })); hdr.addView(bk, lp(dp(42), dp(42), 0, 0, 12, 0)); }
		android.widget.LinearLayout t = lin(true); t.addView(tv(page == 10 ? chatName() : TITLES[page], 22, cText, true)); t.addView(tv(subTitle(), 12, cSub, false), lp(-2, -2, 0, 3, 0, 0)); hdr.addView(t, lw(1f, 0, 0, 8, 0));
		android.widget.FrameLayout tb = ib(8, cInk, 38); tb.setOnClickListener(ck(new Runnable() { public void run() { themeDlg(); } })); hdr.addView(tb, lp(dp(38), dp(38), 0, 0, 8, 0));
		android.widget.LinearLayout live = lin(false); live.setGravity(16); live.setPadding(dp(12), dp(7), dp(12), dp(7)); live.setBackground(bg(cSoft, 14, 0, 0)); View dot = new View(act); dot.setBackground(bg(cInk, 4, 0, 0)); live.addView(dot, lp(dp(8), dp(8), 0, 0, 6, 0)); live.addView(tv("LIVE", 11, cText, true)); hdr.addView(live);
		if (livePulse != null) livePulse.cancel(); livePulse = android.animation.ObjectAnimator.ofFloat(dot, "alpha", 1f, 0.2f); livePulse.setDuration(900); livePulse.setRepeatMode(2); livePulse.setRepeatCount(-1); livePulse.start();
	}
	void nav() {
		navBox.removeAllViews(); int[] ics = {1, 31, 27, 0, 32}; String[] nm = {"DASH", "USERS", "PREMIUM", "NOTIFY", "MORE"}; int sel = page < 4 ? page : (page >= 12 && page != 16 && page != 17 ? 2 : 4); long sc = supCount(); boolean changed = sel != lastNav; lastNav = sel;
		for (int i = 0; i < 5; i++) {
			final int idx = i; boolean on = sel == i; android.widget.LinearLayout it = lin(true); it.setGravity(17); it.setPadding(0, dp(9), 0, dp(9));
			android.widget.FrameLayout w = new android.widget.FrameLayout(act); w.setBackground(bg(on ? cInk : 0x00000000, 16, 0, 0)); w.addView(ic(ics[i], 22, on ? 0xFFFFFFFF : cSub), new android.widget.FrameLayout.LayoutParams(dp(22), dp(22), 17));
			if ((i == 4 && sc > 0) || (i == 2 && pendingOrders() > 0)) { View bd = new View(act); bd.setBackground(bg(cRed, 5, 0xFFFFFFFF, 2)); android.widget.FrameLayout.LayoutParams bp = new android.widget.FrameLayout.LayoutParams(dp(11), dp(11), 53); bp.setMargins(0, dp(2), dp(10), 0); w.addView(bd, bp); }
			it.addView(w, lp(dp(58), dp(32))); it.addView(tv(nm[i], 10, on ? cText : cSub, on), lp(-2, -2, 0, 5, 0, 0));
			if (on && changed) { w.setScaleX(0.55f); w.setAlpha(0.4f); w.animate().scaleX(1f).alpha(1f).setDuration(240).setInterpolator(new android.view.animation.DecelerateInterpolator()).start(); }
			it.setOnClickListener(ck(new Runnable() { public void run() { page = idx; all(); } })); navBox.addView(it, lw(1f, 0, 0, 0, 0));
		}
	}
	void all() { if (!unlocked || hdr == null) return; header(); nav(); chatBox.setVisibility(page == 10 ? 0 : 8); navBox.setVisibility(kb || page == 10 ? 8 : 0); render(); if (page != lastPage) { lastPage = page; bodyBox.setAlpha(0f); bodyBox.setTranslationY(dp(10)); bodyBox.animate().alpha(1f).translationY(0f).setDuration(220).start(); } }
	void showCrash(Throwable e) {
		java.io.StringWriter sw = new java.io.StringWriter(); e.printStackTrace(new java.io.PrintWriter(sw)); final String msg = sw.toString();
		android.widget.ScrollView sv = new android.widget.ScrollView(act); TextView t = new TextView(act); t.setText(msg); t.setTextIsSelectable(true); t.setTextSize(11); t.setPadding(dp(16), dp(40), dp(16), dp(40)); t.setTextColor(0xFF000000); sv.setBackgroundColor(0xFFFFFFFF); sv.addView(t); act.setContentView(sv);
	}
	void listen() { for (int i = 0; i < PATHS.length; i++) db.child(PATHS[i]).addValueEventListener(new VL(i)); com.google.firebase.database.FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset").addValueEventListener(new VL(99)); }
	void start() {
		hideBar(); bars(); act.getWindow().setSoftInputMode(16);
		root.setBackgroundColor(cBg); root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() { public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets i) { v.setPadding(i.getSystemWindowInsetLeft(), i.getSystemWindowInsetTop(), i.getSystemWindowInsetRight(), i.getSystemWindowInsetBottom()); return i; } });
		android.widget.LinearLayout r = lin(true); hdr = lin(false); hdr.setPadding(dp(18), dp(16), dp(18), dp(12)); r.addView(hdr, lp(-1, -2));
		android.widget.ScrollView sv = new android.widget.ScrollView(act); svB = sv; sv.setVerticalScrollBarEnabled(false); bodyBox = lin(true); bodyBox.setPadding(dp(16), dp(4), dp(16), dp(20)); sv.addView(bodyBox); r.addView(sv, new android.widget.LinearLayout.LayoutParams(-1, 0, 1f));
		chatBox = lin(false); chatBox.setGravity(16); chatBox.setPadding(dp(12), dp(8), dp(12), dp(10)); chatBox.setBackgroundColor(cNav); chatBox.setVisibility(8); chatEt = edit(""); chatEt.setHint("Type a reply..."); chatEt.setSingleLine(false); chatEt.setMaxLines(4); chatBox.addView(chatEt, lw(1f, 0, 0, 10, 0));
		android.widget.FrameLayout sb2 = new android.widget.FrameLayout(act); sb2.setBackground(bg(cInk, 24, 0, 0)); sb2.addView(ic(16, 22, 0xFFFFFFFF), new android.widget.FrameLayout.LayoutParams(dp(22), dp(22), 17)); sb2.setOnClickListener(ck(new Runnable() { public void run() { sendAdmin(); } })); chatBox.addView(sb2, lp(dp(48), dp(48))); r.addView(chatBox, lp(-1, -2));
		navBox = lin(false); android.graphics.drawable.LayerDrawable nbg = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{new android.graphics.drawable.ColorDrawable(0xFFE1E5EC), new android.graphics.drawable.ColorDrawable(0xFFFFFFFF)}); nbg.setLayerInset(1, 0, dp(1), 0, 0); navBox.setBackground(nbg); r.addView(navBox, lp(-1, -2)); root.addView(r, new android.widget.FrameLayout.LayoutParams(-1, -1));
		root.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() { public void onGlobalLayout() { android.graphics.Rect fr = new android.graphics.Rect(); root.getWindowVisibleDisplayFrame(fr); int diff = root.getRootView().getHeight() - fr.bottom; kb = diff > dp(160); navBox.setVisibility(kb || page == 10 ? 8 : 0); } });
		act.setContentView(root); root.requestApplyInsets(); final EditText pw = edit(""); pw.setHint("enter PIN"); pw.setInputType(18);
		android.app.Dialog d = dlg("Admin access", "enter your PIN to continue", pw, "OPEN", new Runnable() { public void run() { if (pw.getText().toString().equals(PIN)) {
			try { unlocked = true; listen(); all(); }
			catch (Throwable e) { showCrash(e); }
		} else { toast("Wrong PIN"); act.finish(); } } });
		if (d != null) { d.setCancelable(false); d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() { public void onDismiss(android.content.DialogInterface x) { new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() { public void run() { if (!unlocked) act.finish(); } }, 400); } }); }
	}
}
try { new AD().start(); } catch (Throwable e) {
	java.io.StringWriter sw = new java.io.StringWriter(); e.printStackTrace(new java.io.PrintWriter(sw));
	android.widget.ScrollView sv = new android.widget.ScrollView(this); TextView t = new TextView(this); t.setText(sw.toString()); t.setTextIsSelectable(true); t.setTextSize(11); t.setPadding(40, 100, 40, 100); setContentView(sv); sv.addView(t);
}
