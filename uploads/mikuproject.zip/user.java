final android.app.Activity act=this;
final float dens=act.getResources().getDisplayMetrics().density;
final int scrW=act.getResources().getDisplayMetrics().widthPixels;
final int scrH=act.getResources().getDisplayMetrics().heightPixels;
final long DAY=86400000L;
final String SAF_PATH="/storage/emulated/0/Android/data/com.mobile.legends/";
final String[]DEL_PATHS={"/storage/emulated/0/Android/data/com.mobile.legends/files/mini_patch"};
final String PAY_TO="MIKU MODX";
int vtmp=1;try{vtmp=act.getPackageManager().getPackageInfo(act.getPackageName(),0).versionCode;}catch(Exception e){}
final int APP_VER=vtmp;
final String[]MENU_ACT={"DroneViewActivity","DamageDroneActivity","CustomBackgroundActivity","MapVersionActivity","CustomConfigActivity","OneHeroActivity"};
final String[]MENU_T={"DRONE VIEW","DAMAGE DRONE","CUSTOM BACKGROUND","MAP VERSION","CUSTOM CONFIG","1 HERO"};
final String[]MENU_D={"Raise the camera height and get a wide drone style view","Drone view with damage info and extra visual details","Change the boring background to your own custom background","Mini map version, shows extra map information","Load custom config files and apply your own settings","1 Hero Feature Boost Up"};
final int[]MENU_I={4,5,6,7,8,60};
final String CTRY="AF|Afghanistan|AFN|AFN;AL|Albania|ALL|ALL;DZ|Algeria|DZD|DZD;AD|Andorra|EUR|\u20ac;AO|Angola|AOA|AOA;AG|Antigua and Barbuda|XCD|$;AR|Argentina|ARS|AR$;AM|Armenia|AMD|AMD;AU|Australia|AUD|A$;AT|Austria|EUR|\u20ac;AZ|Azerbaijan|AZN|AZN;BS|Bahamas|BSD|$;BH|Bahrain|BHD|BHD;BD|Bangladesh|BDT|\u09f3;BB|Barbados|BBD|$;BY|Belarus|BYN|BYN;BE|Belgium|EUR|\u20ac;BZ|Belize|BZD|$;BJ|Benin|XOF|XOF;BT|Bhutan|BTN|BTN;BO|Bolivia|BOB|Bs;BA|Bosnia and Herzegovina|BAM|BAM;BW|Botswana|BWP|BWP;BR|Brazil|BRL|R$;BN|Brunei|BND|$;BG|Bulgaria|BGN|BGN;BF|Burkina Faso|XOF|XOF;BI|Burundi|BIF|BIF;KH|Cambodia|KHR|KHR;CM|Cameroon|XAF|XAF;CA|Canada|CAD|CA$;CV|Cape Verde|CVE|CVE;CF|Central African Republic|XAF|XAF;TD|Chad|XAF|XAF;CL|Chile|CLP|CL$;CN|China|CNY|\u00a5;CO|Colombia|COP|CO$;KM|Comoros|KMF|KMF;CG|Congo|XAF|XAF;CD|DR Congo|CDF|CDF;CR|Costa Rica|CRC|\u20a1;CI|Cote d'Ivoire|XOF|XOF;HR|Croatia|EUR|\u20ac;CU|Cuba|CUP|CUP;CY|Cyprus|EUR|\u20ac;CZ|Czechia|CZK|K\u010d;DK|Denmark|DKK|kr;DJ|Djibouti|DJF|DJF;DM|Dominica|XCD|$;DO|Dominican Republic|DOP|RD$;EC|Ecuador|USD|$;EG|Egypt|EGP|E\u00a3;SV|El Salvador|USD|$;GQ|Equatorial Guinea|XAF|XAF;ER|Eritrea|ERN|ERN;EE|Estonia|EUR|\u20ac;SZ|Eswatini|SZL|SZL;ET|Ethiopia|ETB|ETB;FJ|Fiji|FJD|$;FI|Finland|EUR|\u20ac;FR|France|EUR|\u20ac;GA|Gabon|XAF|XAF;GM|Gambia|GMD|GMD;GE|Georgia|GEL|\u20be;DE|Germany|EUR|\u20ac;GH|Ghana|GHS|GH\u20b5;GR|Greece|EUR|\u20ac;GD|Grenada|XCD|$;GT|Guatemala|GTQ|Q;GN|Guinea|GNF|GNF;GW|Guinea-Bissau|XOF|XOF;GY|Guyana|GYD|$;HT|Haiti|HTG|HTG;HN|Honduras|HNL|L;HK|Hong Kong|HKD|HK$;HU|Hungary|HUF|Ft;IS|Iceland|ISK|kr;IN|India|INR|\u20b9;ID|Indonesia|IDR|Rp;IR|Iran|IRR|IRR;IQ|Iraq|IQD|IQD;IE|Ireland|EUR|\u20ac;IL|Israel|ILS|\u20aa;IT|Italy|EUR|\u20ac;JM|Jamaica|JMD|$;JP|Japan|JPY|\u00a5;JO|Jordan|JOD|JOD;KZ|Kazakhstan|KZT|\u20b8;KE|Kenya|KES|KSh;KI|Kiribati|AUD|A$;XK|Kosovo|EUR|\u20ac;KW|Kuwait|KWD|KWD;KG|Kyrgyzstan|KGS|KGS;LA|Laos|LAK|\u20ad;LV|Latvia|EUR|\u20ac;LB|Lebanon|LBP|LBP;LS|Lesotho|LSL|LSL;LR|Liberia|LRD|$;LY|Libya|LYD|LYD;LI|Liechtenstein|CHF|CHF;LT|Lithuania|EUR|\u20ac;LU|Luxembourg|EUR|\u20ac;MO|Macao|MOP|MOP;MG|Madagascar|MGA|MGA;MW|Malawi|MWK|MWK;MY|Malaysia|MYR|RM;MV|Maldives|MVR|MVR;ML|Mali|XOF|XOF;MT|Malta|EUR|\u20ac;MH|Marshall Islands|USD|$;MR|Mauritania|MRU|MRU;MU|Mauritius|MUR|Rs;MX|Mexico|MXN|MX$;FM|Micronesia|USD|$;MD|Moldova|MDL|MDL;MC|Monaco|EUR|\u20ac;MN|Mongolia|MNT|\u20ae;ME|Montenegro|EUR|\u20ac;MA|Morocco|MAD|MAD;MZ|Mozambique|MZN|MZN;MM|Myanmar|MMK|MMK;NA|Namibia|NAD|$;NR|Nauru|AUD|A$;NP|Nepal|NPR|Rs;NL|Netherlands|EUR|\u20ac;NZ|New Zealand|NZD|NZ$;NI|Nicaragua|NIO|C$;NE|Niger|XOF|XOF;NG|Nigeria|NGN|\u20a6;KP|North Korea|KPW|KPW;MK|North Macedonia|MKD|MKD;NO|Norway|NOK|kr;OM|Oman|OMR|OMR;PK|Pakistan|PKR|Rs;PW|Palau|USD|$;PS|Palestine|ILS|\u20aa;PA|Panama|PAB|B/.;PG|Papua New Guinea|PGK|PGK;PY|Paraguay|PYG|\u20b2;PE|Peru|PEN|S/;PH|Philippines|PHP|\u20b1;PL|Poland|PLN|z\u0142;PT|Portugal|EUR|\u20ac;PR|Puerto Rico|USD|$;QA|Qatar|QAR|QAR;RO|Romania|RON|lei;RU|Russia|RUB|\u20bd;RW|Rwanda|RWF|RWF;KN|Saint Kitts and Nevis|XCD|$;LC|Saint Lucia|XCD|$;VC|Saint Vincent and the Grenadines|XCD|$;WS|Samoa|WST|WST;SM|San Marino|EUR|\u20ac;ST|Sao Tome and Principe|STN|STN;SA|Saudi Arabia|SAR|SAR;SN|Senegal|XOF|XOF;RS|Serbia|RSD|RSD;SC|Seychelles|SCR|SCR;SL|Sierra Leone|SLE|SLE;SG|Singapore|SGD|S$;SK|Slovakia|EUR|\u20ac;SI|Slovenia|EUR|\u20ac;SB|Solomon Islands|SBD|$;SO|Somalia|SOS|SOS;ZA|South Africa|ZAR|R;KR|South Korea|KRW|\u20a9;SS|South Sudan|SSP|SSP;ES|Spain|EUR|\u20ac;LK|Sri Lanka|LKR|Rs;SD|Sudan|SDG|SDG;SR|Suriname|SRD|$;SE|Sweden|SEK|kr;CH|Switzerland|CHF|CHF;SY|Syria|SYP|SYP;TW|Taiwan|TWD|NT$;TJ|Tajikistan|TJS|TJS;TZ|Tanzania|TZS|TSh;TH|Thailand|THB|\u0e3f;TL|Timor-Leste|USD|$;TG|Togo|XOF|XOF;TO|Tonga|TOP|TOP;TT|Trinidad and Tobago|TTD|$;TN|Tunisia|TND|TND;TR|Turkey|TRY|\u20ba;TM|Turkmenistan|TMT|TMT;TV|Tuvalu|AUD|A$;UG|Uganda|UGX|USh;UA|Ukraine|UAH|\u20b4;AE|United Arab Emirates|AED|AED;GB|United Kingdom|GBP|\u00a3;US|United States|USD|$;UY|Uruguay|UYU|$U;UZ|Uzbekistan|UZS|UZS;VU|Vanuatu|VUV|VUV;VA|Vatican City|EUR|\u20ac;VE|Venezuela|VES|Bs;VN|Vietnam|VND|\u20ab;YE|Yemen|YER|YER;ZM|Zambia|ZMW|ZMW;ZW|Zimbabwe|USD|$";
class Ic extends View{
	int t,col;android.graphics.Paint p=new android.graphics.Paint(1);
	Ic(int t,int col){super(act);this.t=t;this.col=col;}
	protected void onDraw(android.graphics.Canvas c){
		float w=getWidth(),h=getHeight(),s=Math.min(w,h);if(s <=0)return;
		c.save();c.translate((w - s)/ 2f,(h - s)/ 2f);c.scale(s / 24f,s / 24f);
		p.setColor(col);p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(1.9f);p.setStrokeCap(android.graphics.Paint.Cap.ROUND);p.setStrokeJoin(android.graphics.Paint.Join.ROUND);
		android.graphics.Path q=new android.graphics.Path();
		switch(t){
			case 0:q.moveTo(4.5f,18f);q.lineTo(6f,16.5f);q.lineTo(6f,11f);q.cubicTo(6f,7.7f,8.7f,5f,12f,5f);q.cubicTo(15.3f,5f,18f,7.7f,18f,11f);q.lineTo(18f,16.5f);q.lineTo(19.5f,18f);q.close();c.drawPath(q,p);
			c.drawLine(12,3,12,5,p);q.reset();q.moveTo(10f,20.5f);q.cubicTo(10.4f,22f,13.6f,22f,14f,20.5f);c.drawPath(q,p);break;
			case 1:q.moveTo(3,11);q.lineTo(12,3);q.lineTo(21,11);c.drawPath(q,p);q.reset();q.moveTo(5,10);q.lineTo(5,20);q.lineTo(19,20);q.lineTo(19,10);c.drawPath(q,p);q.reset();q.moveTo(10,20);q.lineTo(10,14);q.lineTo(14,14);q.lineTo(14,20);c.drawPath(q,p);break;
			case 2:c.drawRoundRect(new android.graphics.RectF(4,5,20,20),3,3,p);c.drawLine(4,10,20,10,p);c.drawLine(8,3,8,7,p);c.drawLine(16,3,16,7,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(9,14,1.2f,p);c.drawCircle(13,14,1.2f,p);c.drawCircle(9,17.5f,1.2f,p);break;
			case 3:c.drawCircle(12,12,3.2f,p);c.drawCircle(12,12,7,p);for(int k=0;k < 8;k++){double a=k * Math.PI / 4;c.drawLine((float)(12 + 8.5 * Math.cos(a)),(float)(12 + 8.5 * Math.sin(a)),(float)(12 + 10.5 * Math.cos(a)),(float)(12 + 10.5 * Math.sin(a)),p);}break;
			case 4:c.drawLine(12,12,6,6,p);c.drawLine(12,12,18,6,p);c.drawLine(12,12,6,18,p);c.drawLine(12,12,18,18,p);c.drawCircle(5,5,2.6f,p);c.drawCircle(19,5,2.6f,p);c.drawCircle(5,19,2.6f,p);c.drawCircle(19,19,2.6f,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(12,12,2.6f,p);break;
			case 5:c.drawCircle(12,12,7,p);c.drawLine(12,2,12,6,p);c.drawLine(12,18,12,22,p);c.drawLine(2,12,6,12,p);c.drawLine(18,12,22,12,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(12,12,2,p);break;
			case 6:c.drawRoundRect(new android.graphics.RectF(3,5,21,19),3,3,p);q.moveTo(4,18);q.lineTo(10,12);q.lineTo(14,16);q.lineTo(17,13);q.lineTo(20,16);c.drawPath(q,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(9,9.5f,1.6f,p);break;
			case 7:q.moveTo(3,6);q.lineTo(9,4);q.lineTo(15,6);q.lineTo(21,4);q.lineTo(21,18);q.lineTo(15,20);q.lineTo(9,18);q.lineTo(3,20);q.close();c.drawPath(q,p);c.drawLine(9,4,9,18,p);c.drawLine(15,6,15,20,p);break;
			case 8:c.drawLine(4,7,20,7,p);c.drawLine(4,12,20,12,p);c.drawLine(4,17,20,17,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(9,7,2.3f,p);c.drawCircle(15,12,2.3f,p);c.drawCircle(8,17,2.3f,p);break;
			case 9:c.drawRoundRect(new android.graphics.RectF(3,7,19,17),2.5f,2.5f,p);c.drawLine(21,10,21,14,p);p.setStyle(android.graphics.Paint.Style.FILL);q.moveTo(11,9);q.lineTo(8,12.5f);q.lineTo(11,12.5f);q.lineTo(10,15);q.lineTo(14,11);q.lineTo(11,11);q.close();c.drawPath(q,p);break;
			case 10:c.drawRoundRect(new android.graphics.RectF(6,6,18,18),2,2,p);c.drawLine(9,3,9,6,p);c.drawLine(15,3,15,6,p);c.drawLine(9,18,9,21,p);c.drawLine(15,18,15,21,p);c.drawLine(3,9,6,9,p);c.drawLine(3,15,6,15,p);c.drawLine(18,9,21,9,p);c.drawLine(18,15,21,15,p);break;
			case 11:c.drawArc(new android.graphics.RectF(3,9,21,27),225,90,false,p);c.drawArc(new android.graphics.RectF(6,12,18,24),225,90,false,p);c.drawArc(new android.graphics.RectF(9,15,15,21),225,90,false,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(12,19,1.3f,p);break;
			case 12:q.moveTo(12,3);q.lineTo(20,6);q.lineTo(20,12);q.cubicTo(20,17,16,20,12,21);q.cubicTo(8,20,4,17,4,12);q.lineTo(4,6);q.close();c.drawPath(q,p);break;
			case 13:c.drawRoundRect(new android.graphics.RectF(3,4,21,20),3,3,p);q.moveTo(7,9);q.lineTo(11,12);q.lineTo(7,15);c.drawPath(q,p);c.drawLine(13,15,17,15,p);break;
			case 14:c.drawRoundRect(new android.graphics.RectF(4,4,20,10.5f),2,2,p);c.drawRoundRect(new android.graphics.RectF(4,13.5f,20,20),2,2,p);p.setStyle(android.graphics.Paint.Style.FILL);c.drawCircle(8,7.2f,1.1f,p);c.drawCircle(8,16.8f,1.1f,p);break;
			case 15:c.drawRoundRect(new android.graphics.RectF(9,9,20,20),2.5f,2.5f,p);q.moveTo(15,5.5f);q.lineTo(15,4.5f);q.lineTo(5.5f,4.5f);q.lineTo(4.5f,5.5f);q.lineTo(4.5f,15);q.lineTo(5.5f,15);c.drawPath(q,p);break;
			case 16:q.moveTo(3,11);q.lineTo(21,3);q.lineTo(14,21);q.lineTo(11,13);q.close();c.drawPath(q,p);c.drawLine(11,13,21,3,p);break;
			case 17:c.drawRoundRect(new android.graphics.RectF(3.5f,4,20.5f,16),3.5f,3.5f,p);q.moveTo(9,16);q.lineTo(9,20.5f);q.lineTo(13.5f,16);c.drawPath(q,p);break;
			case 18:c.drawLine(19,12,5,12,p);q.moveTo(11,6);q.lineTo(5,12);q.lineTo(11,18);c.drawPath(q,p);break;
			case 19:q.moveTo(9,6);q.lineTo(15,12);q.lineTo(9,18);c.drawPath(q,p);break;
			case 20:case 21:if(t==21)p.setStyle(android.graphics.Paint.Style.FILL);q.moveTo(12,20.5f);q.cubicTo(5.5f,15,2.5f,12,2.5f,8.3f);q.cubicTo(2.5f,5.5f,4.6f,3.5f,7.2f,3.5f);q.cubicTo(9.2f,3.5f,11,4.6f,12,6.3f);q.cubicTo(13,4.6f,14.8f,3.5f,16.8f,3.5f);q.cubicTo(19.4f,3.5f,21.5f,5.5f,21.5f,8.3f);q.cubicTo(21.5f,12,18.5f,15,12,20.5f);q.close();c.drawPath(q,p);break;
			case 22:c.drawRoundRect(new android.graphics.RectF(3.5f,4,20.5f,16),3.5f,3.5f,p);q.moveTo(9,16);q.lineTo(9,20.5f);q.lineTo(13.5f,16);c.drawPath(q,p);c.drawLine(8,8.5f,16,8.5f,p);c.drawLine(8,11.5f,13,11.5f,p);break;
			case 23:q.moveTo(2,12);q.cubicTo(5,6,19,6,22,12);q.cubicTo(19,18,5,18,2,12);c.drawPath(q,p);c.drawCircle(12,12,3,p);break;
			case 24:c.drawLine(4,7,20,7,p);q.moveTo(9,7);q.lineTo(9,4);q.lineTo(15,4);q.lineTo(15,7);c.drawPath(q,p);q.reset();q.moveTo(6,7);q.lineTo(7,20);q.lineTo(17,20);q.lineTo(18,7);c.drawPath(q,p);break;
			case 25:q.moveTo(5,19);q.lineTo(5.8f,15);q.lineTo(16,4.8f);q.lineTo(19.2f,8);q.lineTo(9,18.2f);q.close();c.drawPath(q,p);break;
			case 26:c.drawRoundRect(new android.graphics.RectF(3,7,21,17),2.5f,2.5f,p);c.drawLine(14,8,14,10,p);c.drawLine(14,11.5f,14,12.5f,p);c.drawLine(14,14,14,16,p);break;
			case 27:q.moveTo(3,8);q.lineTo(8,13);q.lineTo(12,5);q.lineTo(16,13);q.lineTo(21,8);q.lineTo(19,19);q.lineTo(5,19);q.close();c.drawPath(q,p);break;
			case 28:c.drawRoundRect(new android.graphics.RectF(5,11,19,21),3,3,p);q.moveTo(8,11);q.lineTo(8,8);q.cubicTo(8,4.5f,16,4.5f,16,8);q.lineTo(16,11);c.drawPath(q,p);break;
			case 29:c.drawCircle(12,12,9,p);q.moveTo(8,12.5f);q.lineTo(11,15.5f);q.lineTo(16.5f,9);c.drawPath(q,p);break;
			case 30:c.drawCircle(12,12,9,p);c.drawLine(12,7,12,12,p);c.drawLine(12,12,16,14,p);break;
			case 31:c.drawCircle(12,8,4,p);q.moveTo(4,20);q.cubicTo(4,15,8,14,12,14);q.cubicTo(16,14,20,15,20,20);c.drawPath(q,p);break;
			case 32:c.drawRoundRect(new android.graphics.RectF(4,4,10,10),1.5f,1.5f,p);c.drawRoundRect(new android.graphics.RectF(14,4,20,10),1.5f,1.5f,p);c.drawRoundRect(new android.graphics.RectF(4,14,10,20),1.5f,1.5f,p);c.drawRoundRect(new android.graphics.RectF(14,14,20,20),1.5f,1.5f,p);break;
			case 33:q.moveTo(4,10);q.lineTo(4,14);q.lineTo(8,14);q.lineTo(18,19);q.lineTo(18,5);q.lineTo(8,10);q.close();c.drawPath(q,p);c.drawLine(8,14,9.5f,20,p);break;
			case 34:c.drawLine(12,5,12,19,p);c.drawLine(5,12,19,12,p);break;
			case 35:c.drawCircle(12,12,9,p);c.drawLine(5.6f,5.6f,18.4f,18.4f,p);break;
			case 36:p.setStyle(android.graphics.Paint.Style.FILL);q.moveTo(12,2);q.lineTo(14.9f,8.9f);q.lineTo(22,9.3f);q.lineTo(16.5f,14);q.lineTo(18.2f,21);q.lineTo(12,17.2f);q.lineTo(5.8f,21);q.lineTo(7.5f,14);q.lineTo(2,9.3f);q.lineTo(9.1f,8.9f);q.close();c.drawPath(q,p);break;
			case 37:p.setStyle(android.graphics.Paint.Style.FILL);q.moveTo(13,2);q.lineTo(5,13.5f);q.lineTo(11,13.5f);q.lineTo(10,22);q.lineTo(19,10);q.lineTo(13,10);q.close();c.drawPath(q,p);break;
			case 38:c.drawCircle(8,15,4,p);c.drawLine(11,12,20,3,p);c.drawLine(17,6,19.5f,8.5f,p);c.drawLine(14,9,16,11,p);break;
			case 39:c.drawLine(7,17,17,7,p);q.moveTo(8.5f,7);q.lineTo(17,7);q.lineTo(17,15.5f);c.drawPath(q,p);break;
			case 60:q.moveTo(6,11);q.lineTo(12,5);q.lineTo(18,11);c.drawPath(q,p);q.reset();q.moveTo(6,19);q.lineTo(12,13);q.lineTo(18,19);c.drawPath(q,p);break;
			case 61:c.drawCircle(12,12,9,p);c.drawOval(new android.graphics.RectF(8,3,16,21),p);c.drawLine(3,12,21,12,p);break;
			case 62:c.drawRoundRect(new android.graphics.RectF(3,5,21,19),3,3,p);c.drawLine(3,10,21,10,p);c.drawLine(6.5f,15,10.5f,15,p);break;
			case 63:c.drawRoundRect(new android.graphics.RectF(5,3,19,21),2.5f,2.5f,p);c.drawLine(8.5f,8,15.5f,8,p);c.drawLine(8.5f,12,15.5f,12,p);c.drawLine(8.5f,16,12.5f,16,p);break;
			case 64:c.drawCircle(12,12,9,p);q.moveTo(10,8.5f);q.lineTo(16,12);q.lineTo(10,15.5f);q.close();p.setStyle(android.graphics.Paint.Style.FILL);c.drawPath(q,p);break;
			case 65:q.moveTo(12,20);q.cubicTo(4,14.5f,3,9,6.5f,6.5f);q.cubicTo(9,4.7f,11.4f,6,12,8);q.cubicTo(12.6f,6,15,4.7f,17.5f,6.5f);q.cubicTo(21,9,20,14.5f,12,20);q.close();c.drawPath(q,p);break;
			case 66:c.drawRoundRect(new android.graphics.RectF(4,10,20,21),2,2,p);c.drawRoundRect(new android.graphics.RectF(3,7,21,10),1.5f,1.5f,p);c.drawLine(12,7,12,21,p);c.drawLine(12,7,8.5f,4,p);c.drawLine(12,7,15.5f,4,p);break;
			case 67:q.moveTo(12,3);q.cubicTo(13,8,18,10,18,15);q.cubicTo(18,18.5f,15.3f,21,12,21);q.cubicTo(8.7f,21,6,18.5f,6,15);q.cubicTo(6,12.5f,7.5f,11,8.5f,9.5f);q.cubicTo(9.5f,11,10.5f,11.5f,11,12);q.cubicTo(11.5f,9,11,6,12,3);q.close();c.drawPath(q,p);break;
			case 68:c.drawCircle(8,17,3,p);c.drawCircle(16,15,3,p);c.drawLine(11,17,11,5,p);c.drawLine(19,15,19,3,p);c.drawLine(11,5,19,3,p);break;
			case 69:c.drawRoundRect(new android.graphics.RectF(3,7,21,19),3,3,p);c.drawCircle(12,13,3.5f,p);q.moveTo(8,7);q.lineTo(9.5f,4);q.lineTo(14.5f,4);q.lineTo(16,7);c.drawPath(q,p);break;
			case 70:c.drawRoundRect(new android.graphics.RectF(2,8,22,18),5,5,p);c.drawLine(7,11,7,15,p);c.drawLine(5,13,9,13,p);c.drawCircle(15.5f,11.5f,1,p);c.drawCircle(18,14,1,p);break;
			case 71:q.moveTo(6,16);q.lineTo(6,11);q.cubicTo(6,7,9,5,12,5);q.cubicTo(15,5,18,7,18,11);q.lineTo(18,16);q.lineTo(20,18);q.lineTo(4,18);q.close();c.drawPath(q,p);c.drawLine(10,21,14,21,p);break;
			case 72:q.moveTo(7,18);q.cubicTo(2.5f,18,2.5f,11.5f,8,11.5f);q.cubicTo(9,6.5f,16.5f,6.5f,17,11.5f);q.cubicTo(21.5f,11.5f,21.5f,18,17,18);q.close();c.drawPath(q,p);break;
			case 73:c.drawLine(12,4,12,15,p);q.moveTo(7,11);q.lineTo(12,16);q.lineTo(17,11);c.drawPath(q,p);c.drawLine(5,20,19,20,p);break;
			case 74:q.moveTo(3,11);q.lineTo(12,3);q.lineTo(21,11);c.drawPath(q,p);q.reset();q.moveTo(5,10);q.lineTo(5,20);q.lineTo(19,20);q.lineTo(19,10);c.drawPath(q,p);break;
			case 75:q.moveTo(6,4);q.lineTo(18,4);q.lineTo(22,10);q.lineTo(12,21);q.lineTo(2,10);q.close();c.drawPath(q,p);c.drawLine(2,10,22,10,p);break;
			case 76:q.moveTo(12,3);q.lineTo(20,7.5f);q.lineTo(20,16.5f);q.lineTo(12,21);q.lineTo(4,16.5f);q.lineTo(4,7.5f);q.close();c.drawPath(q,p);c.drawLine(4,7.5f,12,12,p);c.drawLine(20,7.5f,12,12,p);c.drawLine(12,12,12,21,p);break;
			case 77:q.moveTo(12,3);q.lineTo(21,8);q.lineTo(12,13);q.lineTo(3,8);q.close();c.drawPath(q,p);q.reset();q.moveTo(3,12);q.lineTo(12,17);q.lineTo(21,12);c.drawPath(q,p);q.reset();q.moveTo(3,16);q.lineTo(12,21);q.lineTo(21,16);c.drawPath(q,p);break;
			case 78:c.drawLine(5,3,5,21,p);q.moveTo(5,4);q.lineTo(19,4);q.lineTo(16,8.5f);q.lineTo(19,13);q.lineTo(5,13);q.close();c.drawPath(q,p);break;
		}
		c.restore();
	}
}
class Flow extends android.view.ViewGroup{
	int gap;
	Flow(int g){super(act);gap=g;}
	protected void onMeasure(int wms,int hms){
		int maxW=View.MeasureSpec.getSize(wms),x=0,y=0,rh=0;
		for(int i=0;i < getChildCount();i++){View c=getChildAt(i);if(c.getVisibility()==8)continue;
			c.measure(View.MeasureSpec.makeMeasureSpec(maxW,View.MeasureSpec.AT_MOST),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));
			int cw=c.getMeasuredWidth(),ch=c.getMeasuredHeight();if(x > 0&&x + cw > maxW){x=0;y +=rh + gap;rh=0;}x +=cw + gap;rh=Math.max(rh,ch);}
		setMeasuredDimension(maxW,y + rh);
	}
	protected void onLayout(boolean changed,int l,int t,int r,int b){
		int maxW=r - l,x=0,y=0,rh=0;
		for(int i=0;i < getChildCount();i++){View c=getChildAt(i);if(c.getVisibility()==8)continue;
			int cw=c.getMeasuredWidth(),ch=c.getMeasuredHeight();if(x > 0&&x + cw > maxW){x=0;y +=rh + gap;rh=0;}c.layout(x,y,x + cw,y + ch);x +=cw + gap;rh=Math.max(rh,ch);}
	}
}
class Ring extends View{
	float frac=-1f,shown=0f;int colP=0xFFFFFFFF,colT=0x33FFFFFF;android.graphics.Paint p=new android.graphics.Paint(1);android.graphics.RectF r=new android.graphics.RectF();
	Ring(){super(act);}
	void setFrac(float f,int col){
		colP=col;if(Math.abs(f - frac)< 0.002f){invalidate();return;}frac=f;
		android.animation.ValueAnimator va=android.animation.ValueAnimator.ofFloat(shown,f);va.setDuration(800);va.setInterpolator(new android.view.animation.DecelerateInterpolator());
		va.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener(){public void onAnimationUpdate(android.animation.ValueAnimator a){shown=(Float)a.getAnimatedValue();invalidate();}});va.start();
	}
	protected void onDraw(android.graphics.Canvas c){
		float w=getWidth(),h=getHeight(),s=Math.min(w,h),sw=s * 0.1f,ox=(w - s)/ 2f,oy=(h - s)/ 2f;r.set(ox + sw / 2f,oy + sw / 2f,ox + s - sw / 2f,oy + s - sw / 2f);
		p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(sw);p.setStrokeCap(android.graphics.Paint.Cap.ROUND);p.setColor(colT);c.drawOval(r,p);p.setColor(colP);if(shown > 0.001f)c.drawArc(r,-90f,360f * shown,false,p);
	}
}
class Qr{
	final int[]DT={0,16,28,44,64,86,108,124,154,182,216},BK={0,1,1,1,2,2,4,4,4,4,5},EC={0,10,16,26,18,24,16,18,22,22,26};
	final int[][]AP={{},{},{6,18},{6,22},{6,26},{6,30},{6,34},{6,22,38},{6,24,42},{6,26,46},{6,28,50}};
	final int[]ex=new int[512],lg=new int[256];
	int sz;boolean[][]mo,fn;
	Qr(){int x=1;for(int i=0;i < 255;i++){ex[i]=x;lg[x]=i;x <<=1;if(x > 255)x ^=0x11D;}for(int i=255;i < 512;i++)ex[i]=ex[i - 255];}
	int mul(int a,int b){return(a==0||b==0)?0:ex[lg[a]+ lg[b]];}
	int[]rs(int[]d,int n){
		int[]g=new int[n + 1];g[0]=1;int len=1;
		for(int i=0;i < n;i++){for(int j=len;j >=0;j--)g[j]=(j < len?g[j]:0)^(j > 0?mul(g[j - 1],ex[i]):0);len++;}
		int[]r=new int[n];
		for(int k=0;k < d.length;k++){int f=d[k]^ r[0];for(int i=0;i < n - 1;i++)r[i]=r[i + 1];r[n - 1]=0;for(int i=0;i < n;i++)r[i]^=mul(g[i + 1],f);}
		return r;
	}
	void put(byte[]a,int[]pos,int val,int len){for(int i=len - 1;i >=0;i--){if(((val >> i)&1)==1)a[pos[0]>> 3]|=(byte)(0x80 >>(pos[0]&7));pos[0]++;}}
	boolean gb(int v,int i){return((v >>> i)&1)!=0;}
	void sf(int x,int y,boolean d){mo[y][x]=d;fn[y][x]=true;}
	void finder(int x,int y){for(int dy=-4;dy <=4;dy++)for(int dx=-4;dx <=4;dx++){int xx=x + dx,yy=y + dy;if(xx >=0&&xx < sz&&yy >=0&&yy < sz){int d=Math.max(Math.abs(dx),Math.abs(dy));sf(xx,yy,d !=2&&d !=4);}}}
	void align(int x,int y){for(int dy=-2;dy <=2;dy++)for(int dx=-2;dx <=2;dx++)sf(x + dx,y + dy,Math.max(Math.abs(dx),Math.abs(dy))!=1);}
	void fmt(int mask){
		int r=mask;for(int i=0;i < 10;i++)r=(r << 1)^((r >>> 9)* 0x537);int bits=((mask << 10)|r)^ 0x5412;
		for(int i=0;i <=5;i++)sf(8,i,gb(bits,i));sf(8,7,gb(bits,6));sf(8,8,gb(bits,7));sf(7,8,gb(bits,8));for(int i=9;i < 15;i++)sf(14 - i,8,gb(bits,i));
		for(int i=0;i < 8;i++)sf(sz - 1 - i,8,gb(bits,i));for(int i=8;i < 15;i++)sf(8,sz - 15 + i,gb(bits,i));sf(8,sz - 8,true);
	}
	void ver(int v){
		if(v < 7)return;int r=v;for(int i=0;i < 12;i++)r=(r << 1)^((r >>> 11)* 0x1F25);int bits=(v << 12)|r;
		for(int i=0;i < 18;i++){boolean b=gb(bits,i);int a=sz - 11 + i % 3,c=i / 3;sf(a,c,b);sf(c,a,b);}
	}
	void mask(int m){
		for(int y=0;y < sz;y++)for(int x=0;x < sz;x++){boolean inv;
			switch(m){case 0:inv=(x + y)% 2==0;break;case 1:inv=y % 2==0;break;case 2:inv=x % 3==0;break;case 3:inv=(x + y)% 3==0;break;case 4:inv=(x / 3 + y / 2)% 2==0;break;case 5:inv=x * y % 2 + x * y % 3==0;break;case 6:inv=(x * y % 2 + x * y % 3)% 2==0;break;default:inv=((x + y)% 2 + x * y % 3)% 2==0;}
			if(inv&&!fn[y][x])mo[y][x]=!mo[y][x];}
	}
	int pen(){
		int res=0;
		for(int t=0;t < 2;t++)for(int a=0;a < sz;a++){int run=0;boolean col=false;
			for(int b=0;b < sz;b++){boolean c=t==0?mo[a][b]:mo[b][a];if(b > 0&&c==col){run++;if(run==5)res +=3;else if(run > 5)res++;}else{col=c;run=1;}}}
		for(int y=0;y < sz - 1;y++)for(int x=0;x < sz - 1;x++){boolean c=mo[y][x];if(c==mo[y][x + 1]&&c==mo[y + 1][x]&&c==mo[y + 1][x + 1])res +=3;}
		int[]pa={1,0,1,1,1,0,1,0,0,0,0},pb={0,0,0,0,1,0,1,1,1,0,1};
		for(int t=0;t < 2;t++)for(int a=0;a < sz;a++)for(int b=0;b + 11 <=sz;b++){boolean ma=true,mb=true;
			for(int k=0;k < 11;k++){boolean c=t==0?mo[a][b + k]:mo[b + k][a];int cv=c?1:0;if(cv !=pa[k])ma=false;if(cv !=pb[k])mb=false;}
			if(ma)res +=40;if(mb)res +=40;}
		int dark=0,total=sz * sz;for(int y=0;y < sz;y++)for(int x=0;x < sz;x++)if(mo[y][x])dark++;
		int k=(Math.abs(dark * 20 - total * 10)+ total - 1)/ total - 1;return res + k * 10;
	}
	boolean[][]make(String text){
		byte[]bs;try{bs=text.getBytes("UTF-8");}catch(Exception e){return null;}
		int v=0,cb=8;for(int i=1;i <=10;i++){int c2=i <=9?8:16;if(4 + c2 + 8 * bs.length <=DT[i]* 8){v=i;cb=c2;break;}}if(v==0)return null;
		byte[]data=new byte[DT[v]];int[]pos={0};put(data,pos,4,4);put(data,pos,bs.length,cb);for(int i=0;i < bs.length;i++)put(data,pos,bs[i]&255,8);
		put(data,pos,0,Math.min(4,DT[v]* 8 - pos[0]));int bp=(pos[0]+ 7)>> 3;for(int i=bp,alt=0;i < DT[v];i++,alt++)data[i]=(byte)(alt % 2==0?0xEC:0x11);
		int nb=BK[v],ec=EC[v],ds=DT[v]/ nb,ns=nb - DT[v]% nb;int[][]bd=new int[nb][],be=new int[nb][];int off=0;
		for(int b=0;b < nb;b++){bd[b]=new int[ds +(b >=ns?1:0)];for(int k=0;k < bd[b].length;k++)bd[b][k]=data[off++]&255;be[b]=rs(bd[b],ec);}
		byte[]all=new byte[DT[v]+ nb * ec];int p=0;for(int k=0;k <=ds;k++)for(int b=0;b < nb;b++)if(k < bd[b].length)all[p++]=(byte)bd[b][k];for(int k=0;k < ec;k++)for(int b=0;b < nb;b++)all[p++]=(byte)be[b][k];
		sz=v * 4 + 17;mo=new boolean[sz][sz];fn=new boolean[sz][sz];
		for(int i=0;i < sz;i++){sf(6,i,i % 2==0);sf(i,6,i % 2==0);}
		finder(3,3);finder(sz - 4,3);finder(3,sz - 4);
		int[]ap=AP[v];int na=ap.length;for(int i=0;i < na;i++)for(int j=0;j < na;j++){if((i==0&&j==0)||(i==0&&j==na - 1)||(i==na - 1&&j==0))continue;align(ap[i],ap[j]);}
		fmt(0);ver(v);
		int bi=0;for(int right=sz - 1;right >=1;right -=2){if(right==6)right=5;for(int vert=0;vert < sz;vert++)for(int j=0;j < 2;j++){int x=right - j;boolean up=((right + 1)&2)==0;int y=up?sz - 1 - vert:vert;if(!fn[y][x]&&bi < all.length * 8){mo[y][x]=gb(all[bi >> 3]&255,7 -(bi&7));bi++;}}}
		int best=0,bpen=Integer.MAX_VALUE;for(int m=0;m < 8;m++){mask(m);fmt(m);int pn=pen();if(pn < bpen){bpen=pn;best=m;}mask(m);}
		mask(best);fmt(best);return mo;
	}
}
class MaxSv extends android.widget.ScrollView{
	int mx;MaxSv(int m){super(act);mx=m;setVerticalScrollBarEnabled(false);}
	protected void onMeasure(int w,int h){super.onMeasure(w,View.MeasureSpec.makeMeasureSpec(mx,View.MeasureSpec.AT_MOST));}
}
class Lg{
	final android.content.SharedPreferences sp=act.getSharedPreferences("dv",0);
	final android.os.Handler hd=new android.os.Handler(android.os.Looper.getMainLooper());
	final java.util.concurrent.ConcurrentHashMap<String,String> mem=new java.util.concurrent.ConcurrentHashMap<String,String>();
	final java.util.Set<String> pend=java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String,Boolean>());
	final java.util.LinkedList<String> q=new java.util.LinkedList<String>();
	final java.util.regex.Pattern NUM=java.util.regex.Pattern.compile("[0-9]+");
	String code=sp.getString("lang","en");int nw;long failAt,lastFire;Runnable onNew;
	final Runnable fire=new Runnable(){public void run(){lastFire=System.currentTimeMillis();if(onNew !=null)onNew.run();}};
	void set(String c){
		c=c==null?"":c.trim();if(c.length()==0||c.equals("null"))c="en";if(c.equals(code))return;
		code=c;mem.clear();pend.clear();synchronized(q){q.clear();}failAt=0;sp.edit().putString("lang",c).apply();hd.removeCallbacks(fire);hd.post(fire);
	}
	String h(String k){long v=1125899906842597L;for(int i=0;i < k.length();i++)v=31 * v + k.charAt(i);return Long.toHexString(v);}
	String gc(String c){if(c.equals("zh"))return "zh-CN";if(c.equals("he"))return "iw";return c;}
	boolean skip(String t){
		if(t.length()< 2||t.length()> 300)return true;
		if(t.indexOf("://")>=0||t.indexOf('@')>=0||t.charAt(0)=='/')return true;
		if(t.indexOf(' ')< 0&&t.length()> 14)return true;
		for(int i=0;i < t.length();i++)if(Character.isLetter(t.charAt(i)))return false;
		return true;
	}
	String tr(String s){
		if(s==null||code.equals("en"))return s;
		String t=s.trim();if(skip(t))return s;
		java.util.ArrayList<String> nums=new java.util.ArrayList<String>();java.util.regex.Matcher m=NUM.matcher(t);StringBuffer sb=new StringBuffer();
		while(m.find()){nums.add(m.group());m.appendReplacement(sb,"\u00a7");}m.appendTail(sb);String k=sb.toString();
		String hit=mem.get(k);if(hit==null){hit=sp.getString("tr_" + code + "_" + h(k),null);if(hit !=null)mem.put(k,hit);}
		if(hit==null){ask(k);return s;}
		int c=0;StringBuilder o=new StringBuilder();
		for(int i=0;i < hit.length();i++){char ch=hit.charAt(i);if(ch=='\u00a7'){if(c >=nums.size())return s;o.append(nums.get(c++));}else o.append(ch);}
		if(c !=nums.size())return s;
		int a=0;while(a < s.length()&&Character.isWhitespace(s.charAt(a)))a++;int b=s.length();while(b > a&&Character.isWhitespace(s.charAt(b - 1)))b--;
		return s.substring(0,a)+ o + s.substring(b);
	}
	void ask(String k){
		if(System.currentTimeMillis()- failAt < 20000||pend.size()> 600||!pend.add(k))return;
		synchronized(q){q.add(k);if(nw < 4){nw++;new Thread(worker).start();}}
	}
	final Runnable worker=new Runnable(){public void run(){
			while(true){
				String k;final String lc;
				synchronized(q){if(q.isEmpty()){nw--;return;}k=q.removeFirst();lc=code;}
				String r=fetch(lc,k);
				if(r==null||r.trim().length()==0){failAt=System.currentTimeMillis();pend.clear();synchronized(q){q.clear();nw--;}return;}
				if(lc.equals(code)){
					sp.edit().putString("tr_" + lc + "_" + h(k),r).apply();mem.put(k,r);
					boolean empty;synchronized(q){empty=q.isEmpty();}long gap=System.currentTimeMillis()- lastFire;
					hd.removeCallbacks(fire);hd.postDelayed(fire,empty?250:(gap > 2500?0:2500 - gap));
				}
				pend.remove(k);
			}
		}};
	String err="";long errAt;
	String get(String u)throws Exception{
		java.net.HttpURLConnection cn=(java.net.HttpURLConnection)new java.net.URL(u).openConnection();cn.setConnectTimeout(8000);cn.setReadTimeout(8000);cn.setRequestProperty("User-Agent","Mozilla/5.0");
		try{int rc=cn.getResponseCode();if(rc !=200){err="HTTP " + rc;return null;}
			java.io.InputStream in=cn.getInputStream();java.io.ByteArrayOutputStream bo=new java.io.ByteArrayOutputStream();byte[]b=new byte[4096];int n;while((n=in.read(b))> 0)bo.write(b,0,n);in.close();return bo.toString("UTF-8");
		}finally{cn.disconnect();}
	}
	String fetch(String lc,String text){
		String q;try{q=java.net.URLEncoder.encode(text,"UTF-8");}catch(Exception e){return null;}
		try{String body=get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=" + gc(lc)+ "&dt=t&q=" + q);
			if(body !=null){org.json.JSONArray a=new org.json.JSONArray(body).getJSONArray(0);StringBuilder sb=new StringBuilder();for(int i=0;i < a.length();i++){org.json.JSONArray p=a.optJSONArray(i);if(p !=null)sb.append(p.optString(0,""));}if(sb.length()> 0)return sb.toString();}
		}catch(Throwable e){err=String.valueOf(e);}
		try{String body=get("https://api.mymemory.translated.net/get?q=" + q + "&langpair=en%7C" + gc(lc));
			if(body !=null){org.json.JSONObject o=new org.json.JSONObject(body);String r=o.getJSONObject("responseData").optString("translatedText","");if(o.optInt("responseStatus",200)==200&&r.length()> 0)return r;err="MyMemory " + o.optString("responseStatus")+ " " + o.optString("responseDetails");}
		}catch(Throwable e){err=String.valueOf(e);}
		if(System.currentTimeMillis()- errAt > 60000){errAt=System.currentTimeMillis();final String m=err;hd.post(new Runnable(){public void run(){android.widget.Toast.makeText(act.getApplicationContext(),"Translation failed: " + m,1).show();}});}
		return null;
	}
}
final Lg LG=new Lg();
class DV{
	final android.content.SharedPreferences sp=act.getSharedPreferences("dv",0);
	final com.google.firebase.database.DatabaseReference db=com.google.firebase.database.FirebaseDatabase.getInstance().getReference("dv");
	final String dev=android.provider.Settings.Secure.getString(act.getContentResolver(),"android_id");
	final android.os.Handler hd=new android.os.Handler(android.os.Looper.getMainLooper());
	final android.widget.FrameLayout root=new android.widget.FrameLayout(act);
	final int[][]THM={
		{0xFFF6F7FA,0xFFEFF2F8,0xFFFFFFFF,0xFFB9C0CB,0xFFE3E7EE,0xFF2A2F36,0xFF8A919B,0xFF3A424C},
		{0xFFF3F6FD,0xFFE8EFFC,0xFFFFFFFF,0xFFB8C7E6,0xFFDDE6F8,0xFF1E2A44,0xFF7B8AA8,0xFF2563EB},
		{0xFFF2F9F6,0xFFE4F3EC,0xFFFFFFFF,0xFFB7D9C8,0xFFD8EDE3,0xFF1D3329,0xFF78948A,0xFF059669},
		{0xFFF6F3FD,0xFFECE6FA,0xFFFFFFFF,0xFFCFC2EE,0xFFE4DAF8,0xFF2B2145,0xFF8A7FAB,0xFF7C3AED},
		{0xFFFDF3F5,0xFFFAE6EB,0xFFFFFFFF,0xFFEDC1CC,0xFFF8DAE1,0xFF45212B,0xFFAB7F89,0xFFE11D48},
		{0xFFFDF8F0,0xFFFAEFDC,0xFFFFFFFF,0xFFEAD3A8,0xFFF7E7C8,0xFF45331D,0xFFAB9578,0xFFD97706},
		{0xFFF6F7FA,0xFFEFF2F8,0xFFFFFFFF,0xFFB9C0CB,0xFFE3E7EE,0xFF2A2F36,0xFF8A919B,0xFF3A424C},
		{0xFFFFF5F0,0xFFFDE9DE,0xFFFFFFFF,0xFFF0C4AE,0xFFFADBCB,0xFF4A2418,0xFFB08573,0xFFEA580C},
		{0xFFF0F9FA,0xFFDFF1F3,0xFFFFFFFF,0xFFB1D8DD,0xFFCDE9ED,0xFF15363B,0xFF6E9399,0xFF0D9488},
		{0xFFF3F4FD,0xFFE7E9FB,0xFFFFFFFF,0xFFC0C5EE,0xFFDADDF8,0xFF1F2347,0xFF7E84AD,0xFF4F46E5},
		{0xFFF8F4F0,0xFFEFE6DD,0xFFFFFFFF,0xFFD6C5B5,0xFFEADFD4,0xFF3A2A20,0xFF9A8676,0xFF8B5E3C},
		{0xFFF6F7FA,0xFFEFF2F8,0xFFFFFFFF,0xFFB9C0CB,0xFFE3E7EE,0xFF2A2F36,0xFF8A919B,0xFF3A424C},
		{0xFFF6F7FA,0xFFEFF2F8,0xFFFFFFFF,0xFFB9C0CB,0xFFE3E7EE,0xFF2A2F36,0xFF8A919B,0xFF3A424C}
	};
	int th=Math.max(0,Math.min(THM.length - 1,sp.getInt("theme",0)));
	int cBg=THM[th][0],cCard=THM[th][1],cWhite=THM[th][2],cStroke=THM[th][3],cSoft=THM[th][4],cText=THM[th][5],cSub=THM[th][6],cInk=THM[th][7];
	final int cGreen=0xFF1FA85A,cRed=0xFFE5484D,cAmber=0xFFF59E0B,cBlue=0xFF3B82F6,cPurple=0xFF8B5CF6;
	final int[]AVC={0xFF3B82F6,0xFF8B5CF6,0xFF1FA85A,0xFFF59E0B,0xFFE5484D,0xFF0EA5E9};
	com.google.firebase.database.DataSnapshot cfg,slidesS,menuS,me,eventsS,notifS,ulS,supS,premS,ordS,faqS;
	android.widget.LinearLayout rwBox;String rwSig="";boolean trialTried;
	long off,notifPrev,lastTouch;int page,tk,slideIdx,slideTick;int[]supSelA={0};
	boolean homeBuilt,setBuilt,updShown,kbOpen,codeAlive=true;String codeKey="",msig="",lockKey="";String lastBs="";boolean quiet;TextView sUnit;
	final java.util.HashMap<String,android.graphics.Bitmap> imgs=new java.util.HashMap<String,android.graphics.Bitmap>();
	final java.util.HashSet<String> viewed=new java.util.HashSet<String>();
	int navShown=-1,navIW;Ring sRing;
	android.widget.LinearLayout headBox,bodyBox,sliderHost,sliderBox,menuBox,dots,chatBox,navBar;android.widget.FrameLayout lockBox,navBox;android.widget.ScrollView sv;android.widget.HorizontalScrollView slider;EditText chatEt;
	android.animation.ObjectAnimator lockA;com.google.firebase.database.DatabaseReference codeRef;com.google.firebase.database.ValueEventListener codeL;
	TextView sTitle,sSub,sDays,sExp,sKey,sCnt,dBat,dRam,dNet,dRoot,dShz,dSto,dId,dReg,dSeen,supSubT,ntSubT;android.widget.LinearLayout sBar;View sBarF,sBarR;
	class TT extends TextView{
		TT(){super(act);}
		public void setText(CharSequence t,android.widget.TextView.BufferType b){super.setText(t instanceof String?LG.tr((String)t):t,b);}
	}
	class ET extends EditText{
		ET(){super(act);}
	}
	class VL implements com.google.firebase.database.ValueEventListener{
		final int k;VL(int k){this.k=k;}
		public void onDataChange(com.google.firebase.database.DataSnapshot d){got(k,d);}
		public void onCancelled(com.google.firebase.database.DatabaseError e){}
	}
	String s(com.google.firebase.database.DataSnapshot d,String k){if(d==null)return "";Object o=d.child(k).getValue();return o==null?"":String.valueOf(o);}
	double n(com.google.firebase.database.DataSnapshot d,String k){try{return Double.parseDouble(s(d,k));}catch(Exception e){return 0;}}
	String g(String k,String def){String v=s(cfg,k).trim();return v.length()> 0?v:def;}
	long gl(String k,long def){try{return(long)Double.parseDouble(s(cfg,k));}catch(Exception e){return def;}}
	boolean gb(String k,boolean def){String v=s(cfg,k);return v.length()==0?def:"true".equals(v);}
	long lv(com.google.firebase.database.MutableData d){Object o=d.getValue();return(o instanceof Number)?((Number)o).longValue():0L;}
	java.util.ArrayList<com.google.firebase.database.DataSnapshot> kids(com.google.firebase.database.DataSnapshot d,String key,boolean desc){
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l=new java.util.ArrayList<com.google.firebase.database.DataSnapshot>();
		if(d !=null)for(com.google.firebase.database.DataSnapshot x:d.getChildren())if(!"false".equals(s(x,"active")))l.add(x);
		for(int i=1;i < l.size();i++){com.google.firebase.database.DataSnapshot x=l.get(i);int j=i - 1;
			while(j >=0&&(desc?n(l.get(j),key)< n(x,key):n(l.get(j),key)> n(x,key))){l.set(j + 1,l.get(j));j--;}l.set(j + 1,x);}
		return l;
	}
	void got(int k,com.google.firebase.database.DataSnapshot d){
		if(k==0){Object o=d.getValue();if(o instanceof Number)off=((Number)o).longValue();return;}
		if(k==1){cfg=d;LG.set(g("lang","en"));checkUpdate();chkTheme();}
		else if(k==2){slidesS=d;if(page==0&&homeBuilt)fillSlider();}
		else if(k==3)menuS=d;
		else if(k==4){me=d;if(!d.hasChild("createdAt"))db.child("users").child(dev).child("createdAt").setValue(com.google.firebase.database.ServerValue.TIMESTAMP);watchCode();}
		else if(k==5)eventsS=d;else if(k==6)notifS=d;else if(k==7)ulS=d;else if(k==8)supS=d;else if(k==9)premS=d;else if(k==10)ordS=d;else if(k==11){faqS=d;if(page==4&&!locked())renderBody();}
		if((k==4||k >=9)&&premD !=null&&premD.isShowing())paintPrem();
		if(k==4)askCountry();
		maybeTrial();refresh();
	}
	void watchCode(){
		String key="code".equals(s(me,"premiumSrc"))?s(me,"premiumKey"):"";if(key.equals(codeKey))return;
		if(codeRef !=null&&codeL !=null)codeRef.removeEventListener(codeL);codeKey=key;codeAlive=true;codeRef=null;if(key.length()==0)return;
		codeRef=db.child("codes").child(key);codeL=new com.google.firebase.database.ValueEventListener(){public void onDataChange(com.google.firebase.database.DataSnapshot d){codeAlive=d.exists();refresh();}public void onCancelled(com.google.firebase.database.DatabaseError e){}};codeRef.addValueEventListener(codeL);
	}
	long now(){return System.currentTimeMillis()+ off;}
	String lshort(long ms){long d=ms / DAY,h=(ms % DAY)/ 3600000L,m=(ms % 3600000L)/ 60000L;if(d >=2)return d + "d";if(d==1)return "1d" +(h > 0?" " + h + "h":"");if(h > 0)return h + "h" +(m > 0?" " + m + "m":"");return Math.max(1L,m)+ "m";}
	int hs(com.google.firebase.database.DataSnapshot d){return d==null?0:String.valueOf(d.getValue()).hashCode();}
	String bsig(){return page + "|" +(page==1?hs(eventsS):0)+ "|" +(page==3?hs(notifS)+ "," + hs(ulS)+ "," + hs(supS):"")+ "|" +(page==4?hs(supS)+ "," + hs(faqS):"")+ "|" + prem()+ locked()+ cc();}
	void relang(){if(headBox==null)return;msig="";rwSig="";lastBs="";lockKey="";quiet=true;if(chatEt !=null)chatEt.setHint(LG.tr("Type your message..."));renderHead();lockUi();renderNav();renderBody();quiet=false;}
	String nf(long v){return java.text.NumberFormat.getInstance(java.util.Locale.US).format(v);}
	String when(long t){return t <=0?"-":new java.text.SimpleDateFormat("dd MMM yyyy, HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(t));}
	String dOnly(long t){return t <=0?"--":new java.text.SimpleDateFormat("dd MMM yyyy",java.util.Locale.getDefault()).format(new java.util.Date(t));}
	String ago(long t){long d=now()- t;if(t <=0)return "";if(d < 60000)return "just now";if(d < 3600000L)return(d / 60000L)+ "m ago";if(d < DAY)return(d / 3600000L)+ "h ago";return when(t);}
	String dayLbl(long t){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US);String d=f.format(new java.util.Date(t));if(d.equals(f.format(new java.util.Date(now()))))return "Today";if(d.equals(f.format(new java.util.Date(now()- DAY))))return "Yesterday";return new java.text.SimpleDateFormat("dd MMM yyyy",java.util.Locale.getDefault()).format(new java.util.Date(t));}
	boolean banned(){return "true".equals(s(me,"banned"));}
	boolean locked(){return banned()||gb("maintenance",false);}
	String lockMsg(){return banned()?g("banMsg","Your device is banned"):g("maintMsg","App is under maintenance, please try later");}
	int avc(String k){return AVC[Math.abs(k.hashCode())% AVC.length];}
	int al(int c,int a){return(a << 24)|(c&0xFFFFFF);}
	long premLeft(){long u=(long)n(me,"premiumUntil");long l=u - now();if(l <=0)return 0;if("code".equals(s(me,"premiumSrc"))&&!codeAlive)return 0;return l;}
	boolean prem(){return premLeft()> 0;}
	String left(long ms){long sec=ms / 1000,d=sec / 86400,h=(sec % 86400)/ 3600,m=(sec % 3600)/ 60,ss=sec % 60;return(d > 0?d + "d ":"")+ String.format(java.util.Locale.US,"%02dh %02dm %02ds",h,m,ss);}
	String uname(){return "User " + dev.substring(Math.max(0,dev.length()- 4));}
	int dp(int v){return(int)(v * dens + 0.5f);}
	void toast(String t){android.widget.Toast.makeText(act.getApplicationContext(),LG.tr(t),0).show();}
	View.OnClickListener ck(final Runnable r){return new View.OnClickListener(){public void onClick(View v){pop(v);r.run();}};}
	void pop(final View v){try{v.animate().cancel();v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(60).withEndAction(new Runnable(){public void run(){v.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new android.view.animation.OvershootInterpolator(3f)).start();}}).start();}catch(Exception e){}}
	void pressAll(View v){
		if(v==null)return;
		if(v.hasOnClickListeners()&&v.getTag()==null){v.setTag("p");v.setOnTouchListener(new View.OnTouchListener(){public boolean onTouch(View x,android.view.MotionEvent e){int a=e.getAction();if(a==0)x.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();else if(a==1||a==3)x.animate().scaleX(1f).scaleY(1f).setDuration(160).start();return false;}});}
		if(v instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)v;for(int i=0;i < g.getChildCount();i++)pressAll(g.getChildAt(i));}
	}
	void hideBar(){
		try{Object ab=act.getClass().getMethod("getSupportActionBar").invoke(act);
			if(ab !=null){java.lang.reflect.Method m=ab.getClass().getMethod("hide");m.setAccessible(true);m.invoke(ab);}}catch(Exception e){}
		try{if(act.getActionBar()!=null)act.getActionBar().hide();}catch(Exception e){}
	}
	android.graphics.drawable.GradientDrawable bg(int c,int r,int stroke,int sw){
		android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();
		g.setColor(c);g.setCornerRadius(r * dens);if(stroke !=0)g.setStroke(Math.max(1,(int)(sw * dens)),stroke);return g;
	}
	TextView tv(String t,int sz,int col,boolean bold){
		TextView x=new TT();x.setText(t);x.setTextSize(sz);x.setTextColor(col);x.setIncludeFontPadding(false);
		if(bold)x.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);return x;
	}
	TextView caps(String t,int sz,int col){TextView x=tv(t,sz,col,true);if(android.os.Build.VERSION.SDK_INT >=21)x.setLetterSpacing(0.12f);return x;}
	android.widget.LinearLayout lin(boolean v){android.widget.LinearLayout l=new android.widget.LinearLayout(act);l.setOrientation(v?1:0);return l;}
	android.widget.LinearLayout.LayoutParams lp(int w,int h){return new android.widget.LinearLayout.LayoutParams(w,h);}
	android.widget.LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){android.widget.LinearLayout.LayoutParams p=new android.widget.LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
	android.widget.LinearLayout.LayoutParams lw(float w,int l,int t,int r,int b){android.widget.LinearLayout.LayoutParams p=new android.widget.LinearLayout.LayoutParams(0,-2,w);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
	View ic(int t,int sz,int col){Ic i=new Ic(t,col);i.setLayoutParams(new android.widget.LinearLayout.LayoutParams(dp(sz),dp(sz)));return i;}
	android.widget.FrameLayout ib(int t,int col,int bgc,int sz,int rad){
		android.widget.FrameLayout f=new android.widget.FrameLayout(act);f.setBackground(bg(bgc,rad,0,0));int in=sz / 2 + 2;f.addView(ic(t,in,col),new android.widget.FrameLayout.LayoutParams(dp(in),dp(in),17));return f;
	}
	android.widget.LinearLayout card(){android.widget.LinearLayout x=lin(true);x.setBackground(bg(cCard,26,cStroke,1));x.setPadding(dp(20),dp(18),dp(20),dp(18));return x;}
	TextView btn(String t,int fg,int bgc,Runnable r){
		TextView b=tv(t,13,fg,true);if(android.os.Build.VERSION.SDK_INT >=21)b.setLetterSpacing(0.1f);b.setGravity(17);b.setSingleLine(true);b.setPadding(dp(18),dp(13),dp(18),dp(13));b.setBackground(bg(bgc,18,0,0));
		if(r !=null)b.setOnClickListener(ck(r));return b;
	}
	EditText edit(String hint){
		EditText e=new ET();e.setHint(LG.tr(hint));e.setTextSize(15);e.setTextColor(cText);e.setHintTextColor(0xFF9AA3AD);e.setSingleLine(true);
		e.setBackground(bg(cWhite,16,cStroke,1));e.setPadding(dp(16),dp(14),dp(16),dp(14));return e;
	}
	android.widget.LinearLayout kv(String l,String v){android.widget.LinearLayout r=lin(false);r.addView(tv(l + " ",14,cSub,false));TextView t=tv(v,14,cText,true);r.addView(t,lw(1f,0,0,0,0));return r;}
	android.app.Dialog dlgI(int icn,int color,String title,String sub,View body,String ok,int okCol,final Runnable onOk,boolean cancelable,boolean showCancel){
		if(act.isFinishing()||(android.os.Build.VERSION.SDK_INT >=17&&act.isDestroyed()))return null;
		color=cInk;okCol=cInk;
		final android.app.Dialog d=new android.app.Dialog(act);d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
		final android.widget.LinearLayout x=lin(true);x.setGravity(android.view.Gravity.CENTER_HORIZONTAL);x.setPadding(dp(24),dp(28),dp(24),dp(18));x.setBackground(bg(cWhite,30,0,0));
		final android.widget.FrameLayout ring=new android.widget.FrameLayout(act);ring.setBackground(bg(cSoft,36,0,0));ring.addView(ic(icn,32,color),new android.widget.FrameLayout.LayoutParams(dp(32),dp(32),17));x.addView(ring,lp(dp(72),dp(72)));
		TextView t=tv(title,20,cText,true);t.setGravity(17);x.addView(t,lp(-1,-2,0,16,0,0));
		if(sub.length()> 0){TextView st=tv(sub,14,cSub,false);st.setGravity(17);st.setLineSpacing(0,1.15f);x.addView(st,lp(-1,-2,4,8,4,0));}
		if(body !=null)x.addView(body,lp(-1,-2,0,16,0,0));
		if(ok !=null)x.addView(btn(ok,0xFFFFFFFF,okCol,new Runnable(){public void run(){d.dismiss();if(onOk !=null)onOk.run();}}),lp(-1,-2,0,20,0,0));
		if(showCancel)x.addView(btn(ok==null?"CLOSE":"CANCEL",ok==null?0xFFFFFFFF:cSub,ok==null?cInk:0x00000000,new Runnable(){public void run(){d.dismiss();}}),lp(-1,-2,0,ok==null?20:6,0,0));
		d.setCancelable(cancelable);d.setContentView(x);d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));d.getWindow().setDimAmount(0.65f);d.show();d.getWindow().setLayout((int)(scrW * 0.88f),-2);
		x.setAlpha(0f);x.setScaleX(0.86f);x.setScaleY(0.86f);x.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(new android.view.animation.OvershootInterpolator(1.2f)).start();
		ring.setScaleX(0f);ring.setScaleY(0f);ring.animate().scaleX(1f).scaleY(1f).setStartDelay(140).setDuration(420).setInterpolator(new android.view.animation.OvershootInterpolator(2.4f)).start();pressAll(x);return d;
	}
	void msg(String title,String text){dlgI(33,cBlue,title,text,null,null,cInk,null,true,true);}
	void copy(String t){try{android.content.ClipboardManager cm=(android.content.ClipboardManager)act.getSystemService("clipboard");cm.setPrimaryClip(android.content.ClipData.newPlainText("dv",t));toast("Copied");}catch(Exception e){}}
	void openUrl(String u){u=u.trim();if(u.length()==0)return;try{act.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(u.contains("://")?u:"https://" + u)));}catch(Exception e){toast("cannot open link");}}
	final long CACHE_MAX=200L * 1024 * 1024,VID_MAX=40L * 1024 * 1024;
	java.io.File cdir(){java.io.File d=new java.io.File(act.getCacheDir(),"dvc");if(!d.exists())d.mkdirs();return d;}
	java.io.File cfile(String url,String ext){return new java.io.File(cdir(),Integer.toHexString(url.hashCode())+ "_" + url.length()+ ext);}
	void trimCache(){
		new Thread(new Runnable(){public void run(){try{
					java.io.File[]fs=cdir().listFiles();if(fs==null)return;long tot=0;for(java.io.File f:fs)tot +=f.length();if(tot <=CACHE_MAX)return;
					java.util.Arrays.sort(fs,new java.util.Comparator<java.io.File>(){public int compare(java.io.File p,java.io.File q2){return Long.compare(p.lastModified(),q2.lastModified());}});
					for(java.io.File f:fs){if(tot <=CACHE_MAX * 3 / 4)break;tot -=f.length();f.delete();}
				}catch(Throwable e){}}}).start();
	}
	boolean fetchTo(String url,java.io.File out,long cap){
		java.io.File tmp=new java.io.File(out.getPath()+ ".tmp");java.net.HttpURLConnection cn=null;java.io.InputStream in=null;java.io.OutputStream o=null;boolean ok=false;
		try{
			cn=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();cn.setConnectTimeout(10000);cn.setReadTimeout(20000);int len=cn.getContentLength();if(cap > 0&&len > cap)return false;
			in=cn.getInputStream();o=new java.io.FileOutputStream(tmp);byte[]b=new byte[16384];int r;long sum=0;
			while((r=in.read(b))!=-1){o.write(b,0,r);sum +=r;if(cap > 0&&sum > cap)throw new java.io.IOException("too big");}
			o.close();o=null;ok=tmp.renameTo(out);
		}catch(Throwable e){ok=false;}
		finally{try{if(o !=null)o.close();}catch(Throwable e){}try{if(in !=null)in.close();}catch(Throwable e){}try{if(cn !=null)cn.disconnect();}catch(Throwable e){}if(tmp.exists())tmp.delete();}
		return ok;
	}
	void loadImg(final ImageView iv,final String url){
		android.graphics.Bitmap c=imgs.get(url);if(c !=null){iv.setImageBitmap(c);return;}
		new Thread(new Runnable(){public void run(){try{
					java.io.File cf=cfile(url,".img");if(!cf.exists()||cf.length()==0)fetchTo(url,cf,20L * 1024 * 1024);if(!cf.exists())return;cf.setLastModified(System.currentTimeMillis());
					android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();o.inJustDecodeBounds=true;android.graphics.BitmapFactory.decodeFile(cf.getPath(),o);
					int sm=1;while(o.outWidth /(sm * 2)>=1000)sm *=2;o=new android.graphics.BitmapFactory.Options();o.inSampleSize=sm;
					final android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeFile(cf.getPath(),o);if(bm==null){cf.delete();return;}
					imgs.put(url,bm);act.runOnUiThread(new Runnable(){public void run(){iv.setImageBitmap(bm);iv.setAlpha(0f);iv.animate().alpha(1f).setDuration(300).start();}});
				}catch(Throwable e){}}}).start();
	}
	void bigDlg(int icn,int col,String title,final String unit,final long val,String sub){
		col=cInk;
		android.widget.FrameLayout h=new android.widget.FrameLayout(act);h.setClipChildren(false);h.setMinimumHeight(dp(110));
		android.widget.LinearLayout c=lin(true);c.setGravity(17);final TextView num=tv("+0",44,col,true);num.setGravity(17);c.addView(num,lp(-2,-2));c.addView(caps(unit,12,cSub),lp(-2,-2,0,4,0,0));h.addView(c,new android.widget.FrameLayout.LayoutParams(-1,-2,17));
		java.util.Random rn=new java.util.Random();int[]cols={cInk,0xFF5B6574,0xFF8A919B,0xFFB9C0CB,0xFFD3D8E0,0xFF2A2F36};int w=(int)(scrW * 0.88f)- dp(48);
		for(int i=0;i < 26;i++){View p=new View(act);int sz=dp(6 + rn.nextInt(5));p.setBackground(bg(cols[i % cols.length],2,0,0));p.setRotation(rn.nextInt(360));android.widget.FrameLayout.LayoutParams fp=new android.widget.FrameLayout.LayoutParams(sz,sz);fp.leftMargin=rn.nextInt(Math.max(1,w - sz));h.addView(p,fp);
			p.setAlpha(0f);p.animate().alpha(1f).translationY(dp(50 + rn.nextInt(70))).rotationBy(360).setStartDelay(150 + rn.nextInt(500)).setDuration(900 + rn.nextInt(700)).start();}
		dlgI(icn,col,title,sub,h,"AWESOME",col,null,true,false);
		android.animation.ValueAnimator va=android.animation.ValueAnimator.ofInt(0,(int)Math.min(val,2000000000L));va.setDuration(1000);va.setStartDelay(300);
		va.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener(){public void onAnimationUpdate(android.animation.ValueAnimator a){num.setText("+" + nf((Integer)a.getAnimatedValue()));}});va.start();
	}
	int battery(){try{android.content.Intent i=act.registerReceiver(null,new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));int l=i.getIntExtra("level",-1),sc=i.getIntExtra("scale",100);return l * 100 / Math.max(1,sc);}catch(Exception e){return -1;}}
	String ramTxt(){try{android.app.ActivityManager am=(android.app.ActivityManager)act.getSystemService("activity");android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();am.getMemoryInfo(mi);return String.format(java.util.Locale.US,"%.1f / %.1f GB",mi.availMem / 1073741824.0,mi.totalMem / 1073741824.0);}catch(Exception e){return "-";}}
	String netTxt(){try{android.net.ConnectivityManager cm=(android.net.ConnectivityManager)act.getSystemService("connectivity");android.net.NetworkInfo ni=cm.getActiveNetworkInfo();if(ni==null||!ni.isConnected())return "Offline";return ni.getType()==1?"WiFi":"Mobile";}catch(Exception e){return "-";}}
	boolean rooted(){String[]ps={"/system/bin/su","/system/xbin/su","/sbin/su","/su/bin/su","/system/app/Superuser.apk","/data/local/xbin/su","/data/local/bin/su"};for(String p:ps)if(new java.io.File(p).exists())return true;return false;}
	boolean shizuku(){try{act.getPackageManager().getPackageInfo("moe.shizuku.privileged.api",0);return true;}catch(Exception e){}try{Class<?> c=Class.forName("rikka.shizuku.Shizuku");return((Boolean)c.getMethod("pingBinder").invoke(null)).booleanValue();}catch(Throwable e){return false;}}
	String stoTxt(){try{android.os.StatFs st=new android.os.StatFs(android.os.Environment.getDataDirectory().getPath());double f=st.getAvailableBytes()/ 1073741824.0,t=st.getTotalBytes()/ 1073741824.0;return String.format(java.util.Locale.US,"%.0f / %.0f GB free",f,t);}catch(Exception e){return "-";}}
	void grant(final long days,final String code){
		db.child("users").child(dev).runTransaction(new com.google.firebase.database.Transaction.Handler(){
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m){
				long tm=now(),u=lv(m.child("premiumUntil"));boolean act2=u > tm;long base=act2?u:tm;
				m.child("premiumUntil").setValue(base + days * DAY);if(!act2)m.child("premiumFrom").setValue(tm);m.child("premiumKey").setValue(code);m.child("premiumSrc").setValue("code");return com.google.firebase.database.Transaction.success(m);
			}
			public void onComplete(com.google.firebase.database.DatabaseError e,boolean ok,com.google.firebase.database.DataSnapshot d){}
		});
	}
	void redeem(String raw){
		final String code=raw.trim().toUpperCase().replaceAll("[^A-Z0-9_-]","");if(code.length()==0){toast("Enter a code");return;}
		if(locked()){toast(lockMsg());return;}
		final String[]res={"Invalid code"};final long[]dy={0};
		db.child("codes").child(code).runTransaction(new com.google.firebase.database.Transaction.Handler(){
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m){
				res[0]="Invalid code";if(m.getValue()==null)return com.google.firebase.database.Transaction.success(m);
				long ex=lv(m.child("expireAt")),mx=lv(m.child("max")),used=lv(m.child("used"));String tg=String.valueOf(m.child("target").getValue());
				if(ex > 0&&now()> ex){res[0]="This code has expired";return com.google.firebase.database.Transaction.abort();}
				if(!(tg.equals("all")||tg.equals(dev))){res[0]="This code is not for your device";return com.google.firebase.database.Transaction.abort();}
				if(m.child("usedBy").hasChild(dev)){res[0]="You already used this code";return com.google.firebase.database.Transaction.abort();}
				if(mx > 0&&used >=mx){res[0]="This code reached its device limit";return com.google.firebase.database.Transaction.abort();}
				m.child("used").setValue(used + 1L);m.child("usedBy").child(dev).setValue(now());dy[0]=lv(m.child("days"));res[0]="ok";
				return com.google.firebase.database.Transaction.success(m);
			}
			public void onComplete(com.google.firebase.database.DatabaseError e,boolean ok,com.google.firebase.database.DataSnapshot d){
				if(ok&&res[0].equals("ok")&&dy[0]> 0){grant(dy[0],code);bigDlg(27,cAmber,"Premium unlocked",dy[0]==1?"DAY ADDED":"DAYS ADDED",dy[0],"All premium tools are now unlocked on this device");}
				else toast(e !=null?"Error: " + e.getMessage():res[0]);
			}
		});
	}
	void redeemDlg(){
		final EditText et=edit("ENTER CODE");et.setInputType(4096|1);et.setGravity(17);et.setTextSize(20);et.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);if(android.os.Build.VERSION.SDK_INT >=21)et.setLetterSpacing(0.12f);
		dlgI(26,cPurple,"Redeem code","Enter your premium code to unlock all tools",et,"REDEEM",cInk,new Runnable(){public void run(){redeem(et.getText().toString());}},true,true);
	}
	void premDlg(){dlgI(27,cAmber,"Premium required","This tool is for premium users. Buy a plan or redeem a code to unlock all tools.",null,"GO PREMIUM",cInk,new Runnable(){public void run(){openPremium();}},true,true);}
	void openMenu(int i){openMenu("m" + i);}
	String findAct(){
		String[]c={"ManuActivity","CustomMenuActivity","CustommenuActivity","CustomManuActivity","CustommanuActivity","MenuActivity","NewmenuActivity","CustomActivity","CustomPageActivity","CustompageActivity"};
		for(String n:c){try{act.getPackageManager().getActivityInfo(new android.content.ComponentName(act.getPackageName(),act.getPackageName()+ "." + n),0);return n;}catch(Exception e){}}
		return "CustomMenuActivity";
	}
	void openMenu(String key){
		if(locked()){toast(lockMsg());return;}com.google.firebase.database.DataSnapshot m=menuS==null?null:menuS.child(key);boolean custom=key.charAt(0)=='c';
		if("true".equals(s(m,"premium"))&&!prem()){premDlg();return;}
		String cn=custom?(s(m,"act").trim().length()> 0?s(m,"act").trim():findAct()):(s(m,"act").trim().length()> 0?s(m,"act").trim():MENU_ACT[Integer.parseInt(key.substring(1))]);
		try{android.content.Intent it=new android.content.Intent();it.setClassName(act.getPackageName(),cn.contains(".")?cn:act.getPackageName()+ "." + cn);it.putExtra("premium",prem());it.putExtra("device",dev);if(custom){it.putExtra("menuKey",key);it.putExtra("menuTitle",s(m,"title"));}act.startActivity(it);}
		catch(Exception e){toast("This tool is coming soon");}
	}
	String[][]CL;
	String[][]cl(){if(CL==null){String[]a=CTRY.split(";");CL=new String[a.length][];for(int i=0;i < a.length;i++)CL[i]=a[i].split("\\|");}return CL;}
	String[]cInfo(String code){for(String[]c:cl())if(c[0].equals(code))return c;return null;}
	final String[]PN={"7 Days","30 Days","90 Days","1 Year"};final long[]PD={7,30,90,365};
	String money(double v){return v==Math.floor(v)?nf((long)v):String.format(java.util.Locale.US,"%.2f",v);}
	String ccTmp="";android.app.Dialog cDlg,premD;android.widget.LinearLayout premBody,premBar;TextView premCt;int selPlan=-1;
	String cc(){String c=s(me,"country");return c.length()> 0?c:ccTmp;}
	void askCountry(){if(!locked()&&cc().length()==0)pickCountry(null,false);}
	void saveCountry(String[]c,android.app.Dialog d,Runnable after){
		ccTmp=c[0];java.util.HashMap<String,Object> u=new java.util.HashMap<String,Object>();u.put("country",c[0]);u.put("countryName",c[1]);db.child("users").child(dev).updateChildren(u);
		d.dismiss();if(page==2&&setBuilt)renderBody();if(premD !=null&&premD.isShowing())paintPrem();if(after !=null)after.run();
	}
	void fillC(final android.widget.LinearLayout list,String q,final android.app.Dialog d,final Runnable after){
		list.removeAllViews();String f=q.trim().toLowerCase();String cur=cc();
		for(final String[]c:cl()){
			if(f.length()> 0&&!(c[1].toLowerCase().contains(f)||c[2].toLowerCase().contains(f)))continue;
			android.widget.LinearLayout r=lin(false);r.setGravity(16);r.setPadding(dp(6),dp(13),dp(6),dp(13));
			r.addView(tv(c[1],15,cText,c[0].equals(cur)),lw(1f,0,0,8,0));r.addView(tv(c[2]+ "  " + c[3],12,cSub,false));
			r.setOnClickListener(ck(new Runnable(){public void run(){saveCountry(c,d,after);}}));list.addView(r);
			View dv=new View(act);dv.setBackgroundColor(0xFFE9ECF2);list.addView(dv,lp(-1,dp(1)));
		}
		pressAll(list);
	}
	void pickCountry(final Runnable after,final boolean cancelable){
		if(act.isFinishing()||(cDlg !=null&&cDlg.isShowing()))return;
		final android.app.Dialog d=new android.app.Dialog(act);d.requestWindowFeature(1);cDlg=d;
		final android.widget.LinearLayout x=lin(true);x.setPadding(dp(22),dp(24),dp(22),dp(16));x.setBackground(bg(cWhite,30,0,0));
		x.addView(tv("Select your country",20,cText,true));x.addView(tv("Prices and payment methods are shown for your region.",13,cSub,false),lp(-1,-2,0,6,0,0));
		final EditText q=edit("Search country");x.addView(q,lp(-1,-2,0,14,0,0));
		final android.widget.LinearLayout list=lin(true);android.widget.ScrollView sc=new android.widget.ScrollView(act);sc.setVerticalScrollBarEnabled(false);sc.addView(list);x.addView(sc,lp(-1,(int)(scrH * 0.5f),0,10,0,0));
		if(cancelable)x.addView(btn("CANCEL",cSub,0x00000000,new Runnable(){public void run(){d.dismiss();}}),lp(-1,-2,0,8,0,0));
		fillC(list,"",d,after);
		q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence a,int b,int c,int e){}public void onTextChanged(CharSequence a,int b,int c,int e){}public void afterTextChanged(android.text.Editable e){fillC(list,e.toString(),d,after);}});
		d.setCancelable(cancelable);d.setContentView(x);d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));d.getWindow().setDimAmount(0.65f);d.show();d.getWindow().setLayout((int)(scrW * 0.9f),-2);pressAll(x);
	}
	String pg(String k,String def){String v=premS==null?"":s(premS.child("cfg"),k).trim();return v.length()> 0?v:def;}
	com.google.firebase.database.DataSnapshot pp(int i){return premS==null?null:premS.child("plans").child("p" + i);}
	String pName(int i){String v=s(pp(i),"name");return v.length()> 0?v:PN[i];}
	long pDays(int i){long v=(long)n(pp(i),"days");return v > 0?v:PD[i];}
	com.google.firebase.database.DataSnapshot pCountry(){
		if(premS==null)return null;com.google.firebase.database.DataSnapshot cs=premS.child("countries");String c=cc();
		if(c.length()> 0&&cs.hasChild(c)&&!"false".equals(s(cs.child(c),"active")))return cs.child(c);
		com.google.firebase.database.DataSnapshot best=null;double bt=0;
		for(com.google.firebase.database.DataSnapshot x:cs.getChildren()){if("false".equals(s(x,"active")))continue;double t=n(x,"createdAt");if(best==null||t < bt){best=x;bt=t;}}
		return best;
	}
	boolean planOk(int i,com.google.firebase.database.DataSnapshot pc){return pc !=null&&!"false".equals(s(pp(i),"active"))&&n(pc,"p" + i)> 0;}
	com.google.firebase.database.DataSnapshot pendingOrder(){if(ordS !=null)for(com.google.firebase.database.DataSnapshot x:ordS.getChildren())if("pending".equals(s(x,"status")))return x;return null;}
	void createOrder(int pi,com.google.firebase.database.DataSnapshot pc){
		if(locked()){toast(lockMsg());return;}if(pendingOrder()!=null){toast("You already have a payment waiting for approval");return;}
		String[]ci=cInfo(cc());java.util.HashMap<String,Object> m=new java.util.HashMap<String,Object>();
		m.put("dev",dev);m.put("plan",pName(pi));m.put("days",pDays(pi));m.put("price",n(pc,"p" + pi));m.put("sym",s(pc,"sym"));m.put("cur",s(pc,"cur"));m.put("country",cc());m.put("cname",ci !=null?ci[1]:cc());m.put("status","pending");m.put("time",com.google.firebase.database.ServerValue.TIMESTAMP);
		db.child("orders").child(dev).push().setValue(m);
		dlgI(30,cInk,"Request sent","Your payment request was sent with your device ID. Premium starts as soon as admin approves it.",null,null,cInk,null,true,true);
	}
	String upiPayload(String pid,com.google.firebase.database.DataSnapshot pc,int pi){
		if(!"INR".equalsIgnoreCase(s(pc,"cur").trim())||pid.indexOf('@')< 1||pid.matches(".*\\s.*"))return pid;
		double am=n(pc,"p" + pi);String u="upi://pay?pa=" + pid + "&pn=" + android.net.Uri.encode(PAY_TO);
		if(am > 0)u +="&am=" + String.format(java.util.Locale.US,"%.2f",am);
		return u + "&cu=INR&tn=" + android.net.Uri.encode(pName(pi)+ " premium");
	}
	void payDlg(final int pi){
		final com.google.firebase.database.DataSnapshot pc=pCountry();if(pc==null){toast("Payment is not available yet");return;}
		final String pid=s(pc,"payId").trim();if(pid.length()==0){toast("Payment method is not set yet");return;}
		if(pendingOrder()!=null){toast("You already have a payment waiting for approval");return;}
		MaxSv sv2=new MaxSv((int)(scrH * 0.42f));android.widget.LinearLayout b=lin(true);b.setGravity(android.view.Gravity.CENTER_HORIZONTAL);sv2.addView(b);
		b.addView(tv(s(pc,"sym")+ " " + money(n(pc,"p" + pi)),30,cText,true));
		b.addView(tv(pName(pi)+ "  |  " + pDays(pi)+ " days  |  " + s(pc,"cur"),12,cSub,false),lp(-2,-2,0,4,0,14));
		boolean[][]mx=new Qr().make(upiPayload(pid,pc,pi));
		if(mx !=null){
			int nq=mx.length,quiet=4,tot=nq + 2 * quiet,sc2=Math.max(2,dp(200)/ tot),px=tot * sc2;
			android.graphics.Bitmap bm=android.graphics.Bitmap.createBitmap(px,px,android.graphics.Bitmap.Config.ARGB_8888);android.graphics.Canvas cv=new android.graphics.Canvas(bm);cv.drawColor(0xFFFFFFFF);android.graphics.Paint pt=new android.graphics.Paint();pt.setColor(0xFF000000);
			for(int y=0;y < nq;y++)for(int x2=0;x2 < nq;x2++)if(mx[y][x2])cv.drawRect((x2 + quiet)* sc2,(y + quiet)* sc2,(x2 + quiet + 1)* sc2,(y + quiet + 1)* sc2,pt);
			ImageView qi=new ImageView(act);qi.setImageBitmap(bm);android.widget.LinearLayout qb=lin(false);qb.setPadding(dp(8),dp(8),dp(8),dp(8));qb.setBackground(bg(cWhite,20,cStroke,1));qb.addView(qi,lp(px,px));b.addView(qb,lp(-2,-2));
		}
		android.widget.LinearLayout ir=lin(false);ir.setGravity(16);ir.setPadding(dp(14),dp(12),dp(12),dp(12));ir.setBackground(bg(cCard,16,cStroke,1));android.widget.LinearLayout il=lin(true);
		il.addView(caps(s(pc,"payName").length()> 0?s(pc,"payName").toUpperCase():"PAYMENT ID",9,cSub));TextView idt=tv(pid,14,cText,true);idt.setSingleLine(true);idt.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);il.addView(idt,lp(-1,-2,0,4,0,0));ir.addView(il,lw(1f,0,0,10,0));
		android.widget.FrameLayout cpb=ib(15,cInk,cSoft,40,14);cpb.setOnClickListener(ck(new Runnable(){public void run(){copy(pid);}}));ir.addView(cpb,lp(dp(40),dp(40)));b.addView(ir,lp(-1,-2,0,14,0,0));
		TextView dn=tv("Device ID: " + dev,11,cSub,false);dn.setGravity(17);b.addView(dn,lp(-1,-2,0,12,0,0));
		dlgI(62,cInk,pg("dlgTitle","Complete your payment"),pg("dlgText","Scan the QR code, pay the exact amount, then tap I HAVE PAID. Premium starts after admin approval."),sv2,"I HAVE PAID",cInk,new Runnable(){public void run(){createOrder(pi,pc);}},true,true);
	}
	void openPremium(){
		if(locked()){toast(lockMsg());return;}
		if(cc().length()==0){pickCountry(new Runnable(){public void run(){openPremium();}},true);return;}
		if(premD !=null&&premD.isShowing())return;
		final android.app.Dialog d=new android.app.Dialog(act,android.R.style.Theme_Light_NoTitleBar);premD=d;
		android.widget.LinearLayout col=lin(true);col.setBackgroundColor(cBg);
		col.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){public android.view.WindowInsets onApplyWindowInsets(View v,android.view.WindowInsets i){v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;}});
		android.widget.LinearLayout top=lin(false);top.setGravity(16);top.setPadding(dp(20),dp(16),dp(20),dp(10));
		android.widget.FrameLayout bk=new android.widget.FrameLayout(act);bk.setBackground(bg(cCard,18,cStroke,1));bk.addView(ic(18,20,cText),new android.widget.FrameLayout.LayoutParams(dp(20),dp(20),17));bk.setOnClickListener(ck(new Runnable(){public void run(){d.dismiss();}}));top.addView(bk,lp(dp(44),dp(44),0,0,14,0));
		top.addView(tv("Premium",22,cText,true),lw(1f,0,0,8,0));
		android.widget.LinearLayout cp=lin(false);cp.setGravity(16);cp.setPadding(dp(12),dp(9),dp(12),dp(9));cp.setBackground(bg(cCard,16,cStroke,1));cp.addView(ic(61,16,cInk),lp(dp(16),dp(16),0,0,6,0));premCt=tv("",12,cText,true);cp.addView(premCt);
		cp.setOnClickListener(ck(new Runnable(){public void run(){pickCountry(null,true);}}));top.addView(cp);col.addView(top,lp(-1,-2));
		android.widget.ScrollView ps=new android.widget.ScrollView(act);ps.setVerticalScrollBarEnabled(false);premBody=lin(true);premBody.setPadding(dp(20),dp(6),dp(20),dp(20));ps.addView(premBody);col.addView(ps,new android.widget.LinearLayout.LayoutParams(-1,0,1f));
		premBar=lin(true);premBar.setPadding(dp(20),dp(12),dp(20),dp(14));premBar.setBackgroundColor(cWhite);col.addView(premBar,lp(-1,-2));
		d.setContentView(col);d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(cBg));d.getWindow().setLayout(-1,-1);
		try{d.getWindow().setStatusBarColor(cBg);d.getWindow().setNavigationBarColor(cWhite);if(android.os.Build.VERSION.SDK_INT >=23){int f=0x2000;if(android.os.Build.VERSION.SDK_INT >=26)f|=0x10;d.getWindow().getDecorView().setSystemUiVisibility(f);}}catch(Exception e){}
		d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener(){public void onDismiss(android.content.DialogInterface x){premD=null;premBody=null;premBar=null;premCt=null;}});
		paintPrem();d.show();
	}
	void paintPrem(){
		if(premBody==null||premBar==null)return;premBody.removeAllViews();premBar.removeAllViews();
		com.google.firebase.database.DataSnapshot pc=pCountry();String[]ci=cInfo(cc());if(premCt !=null)premCt.setText(ci !=null?ci[1]:"Country");
		String sym=s(pc,"sym");final String vid=pg("videoUrl","");
		android.widget.LinearLayout h=lin(true);h.setPadding(dp(22),dp(22),dp(22),dp(22));android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{0xFF343E4C,0xFF171C24});g.setCornerRadius(30 * dens);h.setBackground(g);
		android.widget.LinearLayout hr=lin(false);hr.setGravity(16);hr.addView(ib(27,0xFFFFFFFF,0x1AFFFFFF,52,18),lp(dp(52),dp(52),0,0,14,0));
		android.widget.LinearLayout ht=lin(true);ht.addView(tv(pg("headTitle","Go Premium"),24,0xFFFFFFFF,true));ht.addView(tv(pg("headSub","Unlock every tool on your device"),13,0xFFB7BEC8,false),lp(-2,-2,0,4,0,0));hr.addView(ht,lw(1f,0,0,0,0));h.addView(hr);
		if(prem()){TextView ac=tv("PREMIUM ACTIVE  |  " + lshort(premLeft())+ " left",12,0xFFFFFFFF,true);ac.setPadding(dp(12),dp(7),dp(12),dp(7));ac.setBackground(bg(0x1AFFFFFF,12,0,0));h.addView(ac,lp(-2,-2,0,16,0,0));}
		if(vid.length()> 0){android.widget.LinearLayout wv=lin(false);wv.setGravity(16);wv.setPadding(dp(14),dp(9),dp(16),dp(9));wv.setBackground(bg(cWhite,16,0,0));wv.addView(ic(64,16,cInk),lp(dp(16),dp(16),0,0,8,0));wv.addView(caps("WATCH VIDEO",10,cInk));h.addView(wv,lp(-2,-2,0,16,0,0));h.setOnClickListener(ck(new Runnable(){public void run(){openUrl(vid);}}));}
		premBody.addView(h,lp(-1,-2,0,4,0,0));
		if("true".equals(pg("discOn","false"))&&pg("disc","").length()> 0){android.widget.LinearLayout dc=lin(false);dc.setGravity(16);dc.setPadding(dp(16),dp(14),dp(16),dp(14));dc.setBackground(bg(cCard,20,cInk,1));dc.addView(ic(36,20,cInk),lp(dp(20),dp(20),0,0,12,0));dc.addView(tv(pg("disc",""),14,cText,true),lw(1f,0,0,0,0));premBody.addView(dc,lp(-1,-2,0,14,0,0));}
		com.google.firebase.database.DataSnapshot po=pendingOrder();
		if(po !=null){android.widget.LinearLayout oc=lin(false);oc.setGravity(16);oc.setPadding(dp(16),dp(14),dp(16),dp(14));oc.setBackground(bg(cWhite,20,cStroke,1));oc.addView(ib(30,cInk,cSoft,42,14),lp(dp(42),dp(42),0,0,12,0));
			android.widget.LinearLayout ot=lin(true);ot.addView(tv("Payment under review",15,cText,true));ot.addView(tv(s(po,"plan")+ "  |  " + s(po,"sym")+ " " + money(n(po,"price"))+ "  |  " + ago((long)n(po,"time")),12,cSub,false),lp(-2,-2,0,3,0,0));ot.addView(tv("Premium starts after admin approves it.",12,cSub,false),lp(-2,-2,0,2,0,0));oc.addView(ot,lw(1f,0,0,0,0));premBody.addView(oc,lp(-1,-2,0,14,0,0));}
		int firstOk=-1;for(int i=0;i < 4;i++)if(planOk(i,pc)){firstOk=i;break;}
		if(selPlan < 0||selPlan > 3||!planOk(selPlan,pc))selPlan=firstOk;
		premBody.addView(caps("CHOOSE A PLAN",11,cSub),lp(-2,-2,4,20,0,10));
		if(firstOk < 0){premBody.addView(tv("Payment is not available for your country yet. Please contact support.",14,cSub,false),lp(-1,-2,4,0,4,12));premBody.addView(btn("CONTACT SUPPORT",0xFFFFFFFF,cInk,new Runnable(){public void run(){if(premD !=null)premD.dismiss();go(4);}}),lp(-1,-2));}
		for(int i=0;i < 4;i++){
			if(!planOk(i,pc))continue;final int ix=i;boolean on=i==selPlan;long dy=pDays(i);double pr=n(pc,"p" + i);
			android.widget.LinearLayout c=lin(false);c.setGravity(16);c.setPadding(dp(18),dp(16),dp(18),dp(16));c.setBackground(bg(on?cWhite:cCard,22,on?cInk:cStroke,on?2:1));
			android.widget.FrameLayout rd=new android.widget.FrameLayout(act);rd.setBackground(bg(on?cInk:cWhite,12,on?cInk:cStroke,2));if(on){View dot=new View(act);dot.setBackground(bg(cWhite,4,0,0));rd.addView(dot,new android.widget.FrameLayout.LayoutParams(dp(8),dp(8),17));}c.addView(rd,lp(dp(24),dp(24),0,0,14,0));
			android.widget.LinearLayout m=lin(true);android.widget.LinearLayout nr=lin(false);nr.setGravity(16);nr.addView(tv(pName(i),16,cText,true));String tg=s(pp(i),"tag");if(tg.length()> 0){TextView tp=caps(tg.toUpperCase(),8,0xFFFFFFFF);tp.setPadding(dp(8),dp(3),dp(8),dp(3));tp.setBackground(bg(cInk,8,0,0));nr.addView(tp,lp(-2,-2,8,0,0,0));}m.addView(nr);
			m.addView(tv(dy + " days  |  " + sym + " " + money(pr / dy)+ " per day",12,cSub,false),lp(-2,-2,0,4,0,0));c.addView(m,lw(1f,0,0,8,0));c.addView(tv(sym + " " + money(pr),18,cText,true));
			c.setOnClickListener(ck(new Runnable(){public void run(){selPlan=ix;paintPrem();}}));premBody.addView(c,lp(-1,-2,0,0,0,10));
		}
		if(firstOk >=0){boolean pend=po !=null;premBar.addView(btn(pend?"WAITING FOR APPROVAL":"BUY NOW  |  " + sym + " " + money(n(pc,"p" + selPlan)),0xFFFFFFFF,pend?cSub:cInk,new Runnable(){public void run(){payDlg(selPlan);}}),lp(-1,-2));}
		premBar.addView(btn("HAVE A CODE?  REDEEM",cSub,0x00000000,new Runnable(){public void run(){redeemDlg();}}),lp(-1,-2,0,4,0,0));
		pressAll(premBody);pressAll(premBar);
	}
	void checkUpdate(){
		if(updShown||cfg==null||!gb("updOn",false)||gl("updVer",0)<=APP_VER)return;updShown=true;final boolean force=gb("updForce",false);final String url=g("updUrl","");
		android.widget.LinearLayout b=lin(true);b.setGravity(17);TextView pv=caps("VERSION " + gl("updVer",0),11,cPurple);pv.setPadding(dp(12),dp(5),dp(12),dp(5));pv.setBackground(bg(al(cPurple,0x22),10,0,0));b.addView(pv,lp(-2,-2));
		if(force)b.addView(tv("This update is required to continue",12,cText,true),lp(-2,-2,0,10,0,0));
		dlgI(37,cPurple,g("updTitle","New update available"),g("updMsg","A new version is ready with improvements and fixes."),b,"UPDATE NOW",cPurple,new Runnable(){public void run(){
				if(url.length()> 0)openUrl(url);else toast("Update link not set");if(force){updShown=false;hd.postDelayed(new Runnable(){public void run(){checkUpdate();}},500);}}},!force,!force);
	}
	void lockUi(){
		if(lockBox==null)return;
		if(!locked()||(banned()&&page==4)){if(lockBox.getVisibility()==0){if(lockA !=null)lockA.cancel();lockBox.setVisibility(8);lockBox.removeAllViews();lockKey="";}return;}
		String key=(banned()?"b":"m")+ lockMsg();if(key.equals(lockKey)&&lockBox.getVisibility()==0)return;lockKey=key;if(lockA !=null)lockA.cancel();lockBox.removeAllViews();lockBox.setBackgroundColor(cBg);lockBox.setVisibility(0);
		final boolean ban=banned();int col=cInk;android.widget.LinearLayout c=lin(true);c.setGravity(17);c.setPadding(dp(32),dp(20),dp(32),dp(60));
		android.widget.FrameLayout halo=new android.widget.FrameLayout(act);halo.setBackground(bg(al(col,0x1A),76,0,0));android.widget.FrameLayout core=new android.widget.FrameLayout(act);core.setBackground(bg(al(col,0x30),52,0,0));
		core.addView(new Ic(ban?35:3,col),new android.widget.FrameLayout.LayoutParams(dp(52),dp(52),17));halo.addView(core,new android.widget.FrameLayout.LayoutParams(dp(104),dp(104),17));c.addView(halo,lp(dp(152),dp(152)));
		TextView t=tv(ban?"Device banned":"Under maintenance",26,cText,true);t.setGravity(17);c.addView(t,lp(-1,-2,0,30,0,0));TextView m=tv(lockMsg(),15,cSub,false);m.setGravity(17);m.setLineSpacing(0,1.2f);c.addView(m,lp(-1,-2,0,12,0,0));
		if(ban)c.addView(btn("CONTACT SUPPORT",0xFFFFFFFF,cInk,new Runnable(){public void run(){go(4);}}),lp(-2,-2,0,24,0,0));
		lockBox.addView(c,new android.widget.FrameLayout.LayoutParams(-1,-1,17));
		lockA=android.animation.ObjectAnimator.ofPropertyValuesHolder(halo,android.animation.PropertyValuesHolder.ofFloat("scaleX",1f,1.12f),android.animation.PropertyValuesHolder.ofFloat("scaleY",1f,1.12f));lockA.setDuration(1300);lockA.setRepeatMode(2);lockA.setRepeatCount(-1);lockA.start();pressAll(lockBox);
	}
	void chkTheme(){int t=(int)gl("theme",0);if(t < 0||t >=THM.length)t=0;if(t !=th){sp.edit().putInt("theme",t).apply();if(!act.isFinishing())act.recreate();}}
	void refresh(){
		if(headBox==null)return;renderHead();lockUi();if(locked()&&!(banned()&&page==4))return;
		if(page==0&&homeBuilt){fillMenus();fillReward();}else if(page==2&&setBuilt)updSettings();else{if(!bsig().equals(lastBs)){quiet=true;renderBody();quiet=false;}}
	}
	void go(int p){
		page=p;lockUi();if(p==3){notifPrev=sp.getLong("seenN",0);long mx=notifPrev;if(notifS !=null)for(com.google.firebase.database.DataSnapshot x:notifS.getChildren())mx=Math.max(mx,(long)n(x,"time"));sp.edit().putLong("seenN",mx).apply();}
		chatBox.setVisibility(p==4?0:8);navVis();bodyBox.setPadding(dp(20),dp(4),dp(20),dp(p==4||p==3?12:130));renderHead();renderBody();renderNav();sv.scrollTo(0,0);
		bodyBox.setAlpha(0f);bodyBox.setTranslationY(dp(18));bodyBox.animate().alpha(1f).translationY(0f).setDuration(260).start();
	}
	void navVis(){if(navBox !=null)navBox.setVisibility(kbOpen||page==4||page==3?8:0);}
	int unread(){
		long seen=sp.getLong("seenN",0);int c=0;
		if(notifS !=null)for(com.google.firebase.database.DataSnapshot x:notifS.getChildren()){String to=s(x,"to");if((to.equals("all")||to.equals(dev))&&(long)n(x,"time")> seen)c++;}
		return c + supUnread();
	}
	void renderHead(){
		headBox.removeAllViews();headBox.setGravity(16);
		if(page >=3){
			android.widget.FrameLayout bk=new android.widget.FrameLayout(act);bk.setBackground(bg(cCard,18,cStroke,1));bk.setOnClickListener(ck(new Runnable(){public void run(){go(page==3?0:2);}}));
			bk.addView(ic(18,20,cText),new android.widget.FrameLayout.LayoutParams(dp(20),dp(20),17));headBox.addView(bk,lp(dp(46),dp(46),0,0,14,0));
			headBox.addView(tv(page==3?"Notifications":"Customer support",21,cText,true),lw(1f,0,0,0,0));return;
		}
		android.widget.LinearLayout l=lin(true);
		if(page==0){TextView t=tv(g("appName","Drone Tools"),25,cText,true);t.setSingleLine(true);l.addView(t);l.addView(tv("Pick a tool to get started",13,cSub,false),lp(-2,-2,0,3,0,0));}
		else{l.addView(tv(page==1?"Events":"Settings",25,cText,true));l.addView(tv(page==1?"news and app details":"your device and subscription",13,cSub,false),lp(-2,-2,0,3,0,0));}
		headBox.addView(l,lw(1f,0,0,8,0));
		android.widget.FrameLayout bell=new android.widget.FrameLayout(act);bell.setBackground(bg(cWhite,22,0xFFDDE1E8,1));bell.addView(ic(0,22,cInk),new android.widget.FrameLayout.LayoutParams(dp(22),dp(22),17));bell.setOnClickListener(ck(new Runnable(){public void run(){go(3);}}));
		int u=unread();if(u > 0){TextView bd=tv(u > 9?"9+":String.valueOf(u),9,0xFFFFFFFF,true);bd.setGravity(17);bd.setBackground(bg(cRed,8,0xFFFFFFFF,1));android.widget.FrameLayout.LayoutParams bp=new android.widget.FrameLayout.LayoutParams(dp(18),dp(18),53);bp.setMargins(0,dp(2),dp(2),0);bell.addView(bd,bp);}
		headBox.addView(bell,lp(dp(44),dp(44),0,0,10,0));
		boolean pr=prem();android.widget.LinearLayout chip=lin(false);chip.setGravity(16);chip.setPadding(dp(12),dp(8),dp(14),dp(8));chip.setBackground(bg(pr?cInk:cCard,20,pr?0:cStroke,1));
		chip.addView(ic(27,16,pr?0xFFFFD54F:cSub),lp(dp(16),dp(16),0,0,7,0));chip.addView(caps(pr?"PRO " + lshort(premLeft()):"FREE",11,pr?0xFFFFFFFF:cSub));chip.setOnClickListener(ck(new Runnable(){public void run(){go(2);}}));headBox.addView(chip);
	}
	void placeInd(View ind,int from,int sel,int iw){
		android.widget.FrameLayout.LayoutParams ip=(android.widget.FrameLayout.LayoutParams)ind.getLayoutParams();ip.width=iw;ind.setLayoutParams(ip);ind.setAlpha(1f);ind.setTranslationX(dp(8)+ from * iw);
		if(from !=sel)ind.animate().translationX(dp(8)+ sel * iw).setDuration(300).setInterpolator(new android.view.animation.OvershootInterpolator(0.8f)).start();
	}
	void renderNav(){
		navBox.removeAllViews();final int sel=page==4?2:(page==3?-1:page);
		final android.widget.FrameLayout dock=new android.widget.FrameLayout(act);dock.setBackground(bg(0xFF262D38,30,0,0));
		final View ind=new View(act);ind.setBackground(bg(0x33FFFFFF,22,0,0));ind.setAlpha(0f);ind.setVisibility(sel < 0?4:0);dock.addView(ind,new android.widget.FrameLayout.LayoutParams(dp(80),dp(54),19));
		android.widget.LinearLayout row=lin(false);row.setPadding(dp(8),dp(7),dp(8),dp(7));int[]ics={1,2,3};String[]nm={"HOME","EVENTS","SETTINGS"};
		for(int i=0;i < 3;i++){
			final int idx=i;boolean on=sel==i;int cl=on?0xFFFFFFFF:0xFF8D97A5;android.widget.LinearLayout it=lin(true);it.setGravity(17);it.setPadding(0,dp(8),0,dp(8));
			View icn=ic(ics[i],22,cl);if(on){icn.setScaleX(1.14f);icn.setScaleY(1.14f);}it.addView(icn,lp(dp(22),dp(22)));it.addView(caps(nm[i],8,cl),lp(-2,-2,0,4,0,0));
			it.setOnClickListener(ck(new Runnable(){public void run(){go(idx);}}));row.addView(it,new android.widget.LinearLayout.LayoutParams(0,-2,1f));
		}
		dock.addView(row,new android.widget.FrameLayout.LayoutParams(-1,-2));navBox.addView(dock,new android.widget.FrameLayout.LayoutParams(-1,-2));
		final int from=navShown < 0?sel:navShown;if(sel >=0)navShown=sel;
		if(sel >=0&&navIW > 0)placeInd(ind,from,sel,navIW);
		dock.post(new Runnable(){public void run(){int w=dock.getWidth();if(w <=0||sel < 0)return;int iw=(w - dp(16))/ 3;if(iw !=navIW){navIW=iw;placeInd(ind,from,sel,iw);}}});
	}
	void renderBody(){
		if(page !=0&&page !=1)vids.clear();homeBuilt=false;setBuilt=false;bodyBox.removeAllViews();sliderHost.removeAllViews();sliderHost.setVisibility(page==0&&!(locked())?0:8);if(locked()&&!(banned()&&page==4))return;
		if(page==0){buildHome();homeBuilt=true;}else if(page==1)pgEvents();else if(page==2){buildSettings();setBuilt=true;}else if(page==3)pgNotifs();else pgSupport();lastBs=bsig();
	}
	void buildHome(){
		sliderBox=lin(true);sliderHost.addView(sliderBox,lp(-1,-2));rwBox=lin(true);bodyBox.addView(rwBox,lp(-1,-2,0,16,0,0));menuBox=lin(true);bodyBox.addView(menuBox,lp(-1,-2,0,16,0,0));msig="";rwSig="";fillSlider();fillMenus();fillReward();
	}
	void setDots(int a){
		hd.postDelayed(updV,150);
		if(dots==null)return;dots.removeAllViews();int cnt=kids(slidesS,"order",false).size();
		for(int i=0;i < cnt;i++){View d=new View(act);d.setBackground(bg(i==a?cInk:0xFFCDD2DA,3,0,0));dots.addView(d,lp(dp(i==a?22:6),dp(6),3,0,3,0));}
	}
	void snapSlide(){if(slider==null)return;int cw=scrW - dp(40),step=cw + dp(12),cnt=kids(slidesS,"order",false).size();int i=Math.max(0,Math.min(cnt - 1,Math.round(slider.getScrollX()/(float)step)));slideIdx=i;slider.smoothScrollTo(i * step,0);setDots(i);}
	final java.util.ArrayList<Vid> vids=new java.util.ArrayList<Vid>();
	final Runnable updV=new Runnable(){public void run(){updVids();}};
	boolean isVid(String u){String l=u.toLowerCase();int q2=l.indexOf('?');if(q2 > 0)l=l.substring(0,q2);return l.endsWith(".mp4")||l.endsWith(".webm")||l.endsWith(".m4v")||l.endsWith(".3gp")||l.endsWith(".mkv")||l.endsWith(".m3u8");}
	void updVids(){if(vids.isEmpty())return;android.graphics.Rect r=new android.graphics.Rect();for(Vid v:vids){boolean vis=v.tx.isShown()&&v.tx.getGlobalVisibleRect(r)&&r.width()> v.tx.getWidth()/ 2&&r.height()> dp(40);v.play(vis);}}
	class Vid implements android.view.TextureView.SurfaceTextureListener{
		final String url;final android.view.TextureView tx;android.media.MediaPlayer mp;boolean ready,want;int vw,vh;
		Vid(String u){url=u;tx=new android.view.TextureView(act);tx.setAlpha(0f);tx.setSurfaceTextureListener(this);}
		void fit(){if(vw <=0||vh <=0||tx.getWidth()<=0)return;float W=tx.getWidth(),H=tx.getHeight(),sc=Math.max(W / vw,H / vh);android.graphics.Matrix m=new android.graphics.Matrix();m.setScale(vw * sc / W,vh * sc / H,W / 2f,H / 2f);tx.setTransform(m);}
		public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st,int w,int h){
			try{mp=new android.media.MediaPlayer();mp.setSurface(new android.view.Surface(st));mp.setVolume(0f,0f);mp.setLooping(true);
				mp.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener(){public void onPrepared(android.media.MediaPlayer p){ready=true;vw=p.getVideoWidth();vh=p.getVideoHeight();fit();tx.animate().alpha(1f).setDuration(250).start();hd.post(updV);}});
				mp.setOnVideoSizeChangedListener(new android.media.MediaPlayer.OnVideoSizeChangedListener(){public void onVideoSizeChanged(android.media.MediaPlayer p,int w2,int h2){vw=w2;vh=h2;fit();}});
				mp.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener(){public boolean onError(android.media.MediaPlayer p,int a,int b){ready=false;tx.setVisibility(8);return true;}});
				src();
			}catch(Throwable e){tx.setVisibility(8);}
		}
		void src(){
			final android.media.MediaPlayer mine=mp;final java.io.File cf=cfile(url,".vid");
			if(url.toLowerCase().contains(".m3u8")){try{mine.setDataSource(url);mine.prepareAsync();}catch(Throwable e){tx.setVisibility(8);}return;}
			if(cf.exists()&&cf.length()> 0){cf.setLastModified(System.currentTimeMillis());try{mine.setDataSource(cf.getPath());mine.prepareAsync();}catch(Throwable e){tx.setVisibility(8);}return;}
			new Thread(new Runnable(){public void run(){
					final boolean ok=fetchTo(url,cf,VID_MAX);
					hd.post(new Runnable(){public void run(){if(mp !=mine)return;try{mine.setDataSource(ok?cf.getPath():url);mine.prepareAsync();}catch(Throwable e){tx.setVisibility(8);}}});
				}}).start();
		}
		public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st,int w,int h){fit();}
		public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st){ready=false;try{if(mp !=null)mp.release();}catch(Throwable e){}mp=null;return true;}
		public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st){}
		void play(boolean on){want=on;try{if(mp !=null&&ready){if(on&&!mp.isPlaying())mp.start();else if(!on&&mp.isPlaying())mp.pause();}}catch(Throwable e){}}
	}
	void fillSlider(){
		vids.clear();
		sliderBox.removeAllViews();slider=null;dots=null;java.util.ArrayList<com.google.firebase.database.DataSnapshot> l=kids(slidesS,"order",false);if(l.size()==0)return;
		final int cw=scrW - dp(40),ch=(int)(cw * 0.5f),step=cw + dp(12);slider=new android.widget.HorizontalScrollView(act){
			float dx0,dy0;boolean vert,horiz;final int slop=android.view.ViewConfiguration.get(act).getScaledTouchSlop();
			public boolean onInterceptTouchEvent(android.view.MotionEvent e){
				int a=e.getAction();
				if(a==0){dx0=e.getX();dy0=e.getY();vert=false;horiz=false;}
				else if(a==2&&!vert&&!horiz){float dx=Math.abs(e.getX()- dx0),dy=Math.abs(e.getY()- dy0);if(dx > slop||dy > slop){if(dy > dx)vert=true;else{horiz=true;if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);}}}
				if(vert)return false;
				return super.onInterceptTouchEvent(e);
			}
			public boolean onTouchEvent(android.view.MotionEvent e){
				if(vert)return false;
				return super.onTouchEvent(e);
			}
		};slider.setHorizontalScrollBarEnabled(false);android.widget.LinearLayout strip=lin(false);
		for(final com.google.firebase.database.DataSnapshot x:l){
			android.widget.FrameLayout f=new android.widget.FrameLayout(act);android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{0xFF4A525D,0xFF2A3038});g.setCornerRadius(26 * dens);f.setBackground(g);
			if(android.os.Build.VERSION.SDK_INT >=21)f.setClipToOutline(true);String im=s(x,"image").trim();
			if(isVid(im)){Vid vd=new Vid(im);vids.add(vd);f.addView(vd.tx,new android.widget.FrameLayout.LayoutParams(-1,-1));}else if(im.length()> 0){ImageView iv=new ImageView(act);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);f.addView(iv,new android.widget.FrameLayout.LayoutParams(-1,-1));loadImg(iv,im);}
			View sh=new View(act);sh.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00000000,0xB0000000}));f.addView(sh,new android.widget.FrameLayout.LayoutParams(-1,-1));
			android.widget.LinearLayout t=lin(true);t.setPadding(dp(18),dp(14),dp(18),dp(16));t.setGravity(android.view.Gravity.BOTTOM);
			if(s(x,"title").length()> 0){TextView tt=tv(s(x,"title"),17,0xFFFFFFFF,true);tt.setMaxLines(2);t.addView(tt,lp(-2,-2));}
			if(s(x,"sub").length()> 0){TextView st=tv(s(x,"sub"),12,0xE6FFFFFF,false);st.setMaxLines(2);t.addView(st,lp(-2,-2,0,3,0,0));}
			f.addView(t,new android.widget.FrameLayout.LayoutParams(-1,-1));final String url=s(x,"url").trim();if(url.length()> 0)f.setOnClickListener(ck(new Runnable(){public void run(){openUrl(url);}}));
			strip.addView(f,lp(cw,ch,0,0,12,0));
		}
		slider.addView(strip);sliderBox.addView(slider,lp(-1,-2));dots=lin(false);dots.setGravity(17);sliderBox.addView(dots,lp(-1,-2,0,12,0,0));slideIdx=0;slideTick=0;setDots(0);
		slider.setOnTouchListener(new View.OnTouchListener(){public boolean onTouch(View v,android.view.MotionEvent e){lastTouch=System.currentTimeMillis();int a=e.getAction();if(a==1||a==3)hd.postDelayed(new Runnable(){public void run(){snapSlide();}},180);return false;}});
		if(android.os.Build.VERSION.SDK_INT >=23)slider.setOnScrollChangeListener(new View.OnScrollChangeListener(){public void onScrollChange(View v,int x,int y,int ox,int oy){int i=Math.round(x /(float)step);if(i !=slideIdx){slideIdx=i;setDots(i);}updVids();}});
	}
	com.google.firebase.database.DataSnapshot mn(String k){return menuS==null?null:menuS.child(k);}
	boolean cust(String k){return k.charAt(0)=='c';}
	double mo2(String k){com.google.firebase.database.DataSnapshot m=mn(k);if(m !=null&&m.hasChild("order"))return n(m,"order");return cust(k)?100:Integer.parseInt(k.substring(1));}
	String mt2(String k){return cust(k)?s(mn(k),"title"):mt(Integer.parseInt(k.substring(1)));}
	String md2(String k){return cust(k)?s(mn(k),"desc"):md(Integer.parseInt(k.substring(1)));}
	void fillMenus(){
		if(menuBox==null)return;java.util.ArrayList<String> ix=new java.util.ArrayList<String>();
		for(int i=0;i < 6;i++){com.google.firebase.database.DataSnapshot m=mn("m" + i);if(m !=null&&"false".equals(s(m,"active")))continue;ix.add("m" + i);}
		if(menuS !=null)for(com.google.firebase.database.DataSnapshot c:menuS.getChildren()){String kk=c.getKey();if(kk !=null&&kk.startsWith("c_")&&!"false".equals(s(c,"active")))ix.add(kk);}
		java.util.Collections.sort(ix,new java.util.Comparator<String>(){public int compare(String a,String b){return Double.compare(mo2(a),mo2(b));}});
		StringBuilder sg=new StringBuilder();boolean pr=prem();for(String i:ix){com.google.firebase.database.DataSnapshot m=mn(i);sg.append(i).append(mt2(i)).append(md2(i)).append(s(m,"premium")).append(s(m,"image")).append(s(m,"icon")).append("|");}sg.append(pr);
		if(sg.toString().equals(msig))return;msig=sg.toString();menuBox.removeAllViews();int k=0;
		for(final String i:ix){
			com.google.firebase.database.DataSnapshot m=mn(i);boolean lockedM="true".equals(s(m,"premium"))&&!pr;String img=cust(i)?s(m,"image").trim():"";
			android.widget.LinearLayout c=lin(false);c.setGravity(16);c.setBackground(bg(cCard,28,cStroke,1));c.setPadding(dp(22),dp(22),dp(20),dp(22));
			android.widget.LinearLayout l=lin(true);TextView t=tv(mt2(i),19,cInk,true);if(android.os.Build.VERSION.SDK_INT >=21)t.setLetterSpacing(0.02f);l.addView(t,lp(-2,-2));l.addView(tv(md2(i),13,cSub,false),lp(-1,-2,0,6,0,0));
			if(lockedM){android.widget.LinearLayout pl=lin(false);pl.setGravity(16);pl.setPadding(dp(10),dp(5),dp(12),dp(5));pl.setBackground(bg(cInk,12,0,0));pl.addView(ic(28,12,0xFFFFFFFF),lp(dp(12),dp(12),0,0,5,0));pl.addView(caps("PREMIUM",9,0xFFFFFFFF));l.addView(pl,lp(-2,-2,0,12,0,0));}
			c.addView(l,lw(1f,0,0,14,0));android.widget.FrameLayout bx=new android.widget.FrameLayout(act);bx.setBackground(bg(cSoft,20,cStroke,1));
			if(img.length()> 0){ImageView iv=new ImageView(act);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);if(android.os.Build.VERSION.SDK_INT >=21)bx.setClipToOutline(true);bx.addView(iv,new android.widget.FrameLayout.LayoutParams(-1,-1));loadImg(iv,img);}else bx.addView(ic(cust(i)?((m !=null&&m.hasChild("icon"))?(int)n(m,"icon"):4):MENU_I[Integer.parseInt(i.substring(1))],32,cInk),new android.widget.FrameLayout.LayoutParams(dp(32),dp(32),17));
			c.addView(bx,lp(dp(74),dp(74)));
			c.setOnClickListener(ck(new Runnable(){public void run(){openMenu(i);}}));menuBox.addView(c,lp(-1,-2,0,0,0,14));
			if(!quiet){c.setAlpha(0f);c.setTranslationY(dp(26));c.animate().alpha(1f).translationY(0f).setStartDelay(70 * k).setDuration(420).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();}k++;
		}
		pressAll(menuBox);
	}
	double mo(int i){com.google.firebase.database.DataSnapshot m=menuS==null?null:menuS.child("m" + i);return m !=null&&m.hasChild("order")?n(m,"order"):i;}
	String mt(int i){com.google.firebase.database.DataSnapshot m=menuS==null?null:menuS.child("m" + i);return s(m,"title").length()> 0?s(m,"title"):MENU_T[i];}
	String md(int i){com.google.firebase.database.DataSnapshot m=menuS==null?null:menuS.child("m" + i);return s(m,"desc").length()> 0?s(m,"desc"):MENU_D[i];}
	void pgEvents(){
		vids.clear();
		android.widget.LinearLayout a=lin(true);a.setBackground(bg(cWhite,26,0xFFE3E7EE,1));a.setPadding(dp(20),dp(18),dp(20),dp(18));
		android.widget.LinearLayout top=lin(false);top.setGravity(16);top.addView(ib(33,cInk,cSoft,46,16),lp(dp(46),dp(46),0,0,14,0));
		android.widget.LinearLayout m=lin(true);m.addView(tv(g("aboutTitle","About this app"),17,cText,true));m.addView(caps("VERSION " + APP_VER,9,cSub),lp(-2,-2,0,4,0,0));top.addView(m,lw(1f,0,0,0,0));a.addView(top);
		TextView at=tv(g("aboutText","Everything about this app, new tools and updates will be shown here."),13,cSub,false);at.setLineSpacing(0,1.15f);a.addView(at,lp(-1,-2,0,14,0,0));bodyBox.addView(a,lp(-1,-2,0,6,0,22));
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l=kids(eventsS,"time",true);
		android.widget.LinearLayout sh=lin(false);sh.setGravity(16);sh.addView(caps("LATEST UPDATES",11,cSub),lp(-2,-2,0,0,12,0));View sl=new View(act);sl.setBackgroundColor(0xFFDDE1E8);sh.addView(sl,new android.widget.LinearLayout.LayoutParams(0,dp(1),1f));
		TextView cn=tv(String.valueOf(l.size()),11,cInk,true);cn.setPadding(dp(10),dp(4),dp(10),dp(4));cn.setBackground(bg(cSoft,10,0,0));sh.addView(cn,lp(-2,-2,12,0,0,0));bodyBox.addView(sh,lp(-1,-2,4,0,4,14));int k=0;
		for(final com.google.firebase.database.DataSnapshot x:l){
			android.widget.LinearLayout c=lin(true);c.setBackground(bg(cWhite,26,0xFFE3E7EE,1));if(android.os.Build.VERSION.SDK_INT >=21)c.setClipToOutline(true);String im=s(x,"image").trim(),tg=s(x,"tag").trim(),tx=s(x,"text");final String url=s(x,"url").trim();
			android.widget.FrameLayout fl=new android.widget.FrameLayout(act);int fh=im.length()> 0?210:140;
			if(im.length()> 0){ImageView iv=new ImageView(act);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackgroundColor(cSoft);fl.addView(iv,new android.widget.FrameLayout.LayoutParams(-1,dp(fh)));if(isVid(im)){Vid vd=new Vid(im);vids.add(vd);fl.addView(vd.tx,new android.widget.FrameLayout.LayoutParams(-1,dp(fh)));}else loadImg(iv,im);
				View scr=new View(act);scr.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00000000,0xD0101419}));fl.addView(scr,new android.widget.FrameLayout.LayoutParams(-1,dp(130),80));}
			else{fl.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{0xFF3A4452,0xFF1D232C}));fl.addView(new View(act),new android.widget.FrameLayout.LayoutParams(-1,dp(fh)));
				android.widget.FrameLayout.LayoutParams wp=new android.widget.FrameLayout.LayoutParams(dp(110),dp(110),85);wp.setMargins(0,0,-dp(18),-dp(22));fl.addView(ic(2,110,0x12FFFFFF),wp);}
			android.widget.LinearLayout dc=lin(false);dc.setGravity(16);dc.setPadding(dp(10),dp(6),dp(12),dp(6));dc.setBackground(bg(0xB31D232C,12,0,0));dc.addView(ic(2,13,0xFFFFFFFF),lp(dp(13),dp(13),0,0,6,0));dc.addView(tv(dOnly((long)n(x,"time")),11,0xFFFFFFFF,true));
			android.widget.FrameLayout.LayoutParams dpar=new android.widget.FrameLayout.LayoutParams(-2,-2,51);dpar.setMargins(dp(14),dp(14),0,0);fl.addView(dc,dpar);
			if(tg.length()> 0){TextView t=caps(tg.toUpperCase(),9,cInk);t.setPadding(dp(10),dp(6),dp(10),dp(6));t.setBackground(bg(0xE6FFFFFF,10,0,0));android.widget.FrameLayout.LayoutParams tpar=new android.widget.FrameLayout.LayoutParams(-2,-2,53);tpar.setMargins(0,dp(14),dp(14),0);fl.addView(t,tpar);}
			TextView tt=tv(s(x,"title"),21,0xFFFFFFFF,true);tt.setLineSpacing(0,1.05f);android.widget.FrameLayout.LayoutParams ttp=new android.widget.FrameLayout.LayoutParams(-1,-2,83);ttp.setMargins(dp(18),0,dp(18),dp(16));fl.addView(tt,ttp);c.addView(fl,lp(-1,-2));
			if(tx.length()> 0||url.length()> 0){android.widget.LinearLayout b=lin(true);b.setPadding(dp(18),dp(14),dp(18),dp(16));
				if(tx.length()> 0){TextView bt=tv(tx,14,cSub,false);bt.setLineSpacing(0,1.15f);b.addView(bt,lp(-1,-2));}
				if(url.length()> 0){android.widget.LinearLayout lk=lin(false);lk.setGravity(17);lk.setPadding(dp(16),dp(12),dp(16),dp(12));lk.setBackground(bg(cInk,16,0,0));lk.addView(caps("OPEN LINK",11,0xFFFFFFFF),lp(-2,-2,0,0,8,0));lk.addView(ic(39,14,0xFFFFFFFF),lp(dp(14),dp(14)));lk.setOnClickListener(ck(new Runnable(){public void run(){openUrl(url);}}));b.addView(lk,lp(-1,-2,0,tx.length()> 0?14:0,0,0));}
				c.addView(b);}
			bodyBox.addView(c,lp(-1,-2,0,0,0,14));if(!quiet){c.setAlpha(0f);c.setTranslationY(dp(22));c.animate().alpha(1f).translationY(0f).setStartDelay(70 * Math.min(k,6)).setDuration(400).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();}k++;
		}
		if(l.size()==0){android.widget.LinearLayout em=lin(true);em.setGravity(17);em.addView(ib(2,cSub,cSoft,64,32),lp(dp(64),dp(64)));em.addView(tv("No events yet",15,cSub,true),lp(-2,-2,0,14,0,0));em.addView(tv("News and updates will appear here",12,cSub,false),lp(-2,-2,0,4,0,0));bodyBox.addView(em,lp(-1,-2,0,30,0,0));}
		pressAll(bodyBox);hd.postDelayed(updV,350);
	}
	android.widget.LinearLayout tile(int icn,int col,String label,TextView[]out,int idx){
		android.widget.LinearLayout t=lin(true);t.setPadding(dp(14),dp(14),dp(14),dp(14));t.setBackground(bg(cWhite,22,0xFFE3E7EE,1));android.widget.LinearLayout top=lin(false);top.setGravity(16);
		top.addView(ib(icn,cInk,cSoft,34,12),lp(dp(34),dp(34),0,0,10,0));top.addView(caps(label,9,cSub),lw(1f,0,0,0,0));t.addView(top);
		TextView v=tv("-",17,cText,true);v.setSingleLine(true);v.setEllipsize(android.text.TextUtils.TruncateAt.END);out[idx]=v;t.addView(v,lp(-1,-2,0,12,0,0));return t;
	}
	android.widget.LinearLayout linkRow(int icn,int col,String t,TextView[]out,int idx,final Runnable r){
		android.widget.LinearLayout x=lin(false);x.setGravity(16);x.setPadding(dp(14),dp(13),dp(16),dp(13));x.setBackground(bg(cWhite,22,0xFFE3E7EE,1));x.addView(ib(icn,cInk,cSoft,44,16),lp(dp(44),dp(44),0,0,14,0));
		android.widget.LinearLayout m=lin(true);m.addView(tv(t,15,cText,true));TextView v=tv("",12,cSub,false);v.setSingleLine(true);v.setEllipsize(android.text.TextUtils.TruncateAt.END);out[idx]=v;m.addView(v,lp(-2,-2,0,3,0,0));
		x.addView(m,lw(1f,0,0,8,0));x.addView(ic(19,16,cSub));x.setOnClickListener(ck(r));return x;
	}
	void buildSettings(){
		TextView[]o=new TextView[12];
		android.widget.LinearLayout sc=lin(true);sc.setPadding(dp(22),dp(22),dp(22),dp(22));android.graphics.drawable.GradientDrawable sg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{0xFF343E4C,0xFF171C24});sg.setCornerRadius(32 * dens);sc.setBackground(sg);
		android.widget.LinearLayout r1=lin(false);r1.setGravity(16);android.widget.FrameLayout rf=new android.widget.FrameLayout(act);sRing=new Ring();rf.addView(sRing,new android.widget.FrameLayout.LayoutParams(-1,-1));
		android.widget.LinearLayout cc=lin(true);cc.setGravity(17);sDays=tv("0",28,0xFFFFFFFF,true);sDays.setSingleLine(true);sDays.setGravity(17);cc.addView(sDays,lp(-2,-2));sUnit=caps("DAYS",8,0xFFB7BEC8);cc.addView(sUnit,lp(-2,-2,0,3,0,0));rf.addView(cc,new android.widget.FrameLayout.LayoutParams(-2,-2,17));r1.addView(rf,lp(dp(104),dp(104),0,0,18,0));
		android.widget.LinearLayout m=lin(true);m.addView(caps("MEMBERSHIP",10,0xFFB7BEC8));sTitle=tv("FREE",28,0xFFFFFFFF,true);m.addView(sTitle,lp(-2,-2,0,5,0,0));sSub=tv("Upgrade to unlock all features",13,0xFFB7BEC8,false);m.addView(sSub,lp(-2,-2,0,6,0,0));r1.addView(m,lw(1f,0,0,0,0));sc.addView(r1);
		android.widget.LinearLayout r2=lin(false);r2.setBackground(bg(0x1AFFFFFF,18,0,0));r2.setPadding(dp(16),dp(12),dp(16),dp(12));sExp=tv("--",15,0xFFFFFFFF,true);sKey=tv("-",15,0xFFFFFFFF,true);sKey.setSingleLine(true);sKey.setEllipsize(android.text.TextUtils.TruncateAt.END);
		String[]lb={"EXPIRES","LICENSE KEY"};TextView[]vv={sExp,sKey};for(int i=0;i < 2;i++){android.widget.LinearLayout c=lin(true);c.addView(caps(lb[i],9,0xFFB7BEC8));c.addView(vv[i],lp(-1,-2,0,5,0,0));r2.addView(c,lw(1f,i==0?0:12,0,i==0?12:0,0));}sc.addView(r2,lp(-1,-2,0,18,0,0));
		sCnt=tv("",12,0xFFB7BEC8,false);sc.addView(sCnt,lp(-2,-2,2,12,0,0));
		sc.addView(btn("GO PREMIUM",0xFF1D232C,cWhite,new Runnable(){public void run(){openPremium();}}),lp(-1,-2,0,16,0,0));sc.addView(btn("REDEEM CODE",0xFFFFFFFF,0x1AFFFFFF,new Runnable(){public void run(){redeemDlg();}}),lp(-1,-2,0,8,0,0));bodyBox.addView(sc,lp(-1,-2,0,6,0,18));
		bodyBox.addView(caps("THIS DEVICE",11,cSub),lp(-2,-2,4,0,0,10));
		int[]gi={9,10,11,12,13,14},gc={cInk,cInk,cInk,cInk,cInk,cInk};String[]gn={"BATTERY","RAM","NETWORK","ROOT","SHIZUKU","STORAGE"};
		for(int i=0;i < 6;i +=2){android.widget.LinearLayout gr=lin(false);gr.addView(tile(gi[i],gc[i],gn[i],o,i),lw(1f,0,0,6,0));gr.addView(tile(gi[i + 1],gc[i + 1],gn[i + 1],o,i + 1),lw(1f,6,0,0,0));bodyBox.addView(gr,lp(-1,-2,0,0,0,12));}
		android.widget.LinearLayout ic2=lin(true);ic2.setBackground(bg(cWhite,22,0xFFE3E7EE,1));ic2.setPadding(dp(16),dp(16),dp(16),dp(16));android.widget.LinearLayout idr=lin(false);idr.setGravity(16);android.widget.LinearLayout idl=lin(true);idl.addView(caps("DEVICE ID",9,cSub));dId=tv(dev,16,cText,true);dId.setSingleLine(true);dId.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);idl.addView(dId,lp(-1,-2,0,5,0,0));
		idr.addView(idl,lw(1f,0,0,12,0));android.widget.FrameLayout cpb=ib(15,cInk,cSoft,42,14);cpb.setOnClickListener(ck(new Runnable(){public void run(){copy(dev);}}));idr.addView(cpb,lp(dp(42),dp(42)));ic2.addView(idr);
		View d2=new View(act);d2.setBackgroundColor(0xFFE9ECF2);ic2.addView(d2,lp(-1,dp(1),0,14,0,14));android.widget.LinearLayout r3=lin(false);
		android.widget.LinearLayout a1=lin(false);a1.setGravity(16);a1.addView(ic(2,18,cSub),lp(dp(18),dp(18),0,0,10,0));android.widget.LinearLayout a1t=lin(true);a1t.addView(tv("Registered",11,cSub,false));dReg=tv("-",14,cText,true);a1t.addView(dReg,lp(-2,-2,0,3,0,0));a1.addView(a1t);
		android.widget.LinearLayout a2=lin(false);a2.setGravity(16);a2.addView(ic(30,18,cSub),lp(dp(18),dp(18),0,0,10,0));android.widget.LinearLayout a2t=lin(true);a2t.addView(tv("Last online",11,cSub,false));dSeen=tv("-",14,cText,true);a2t.addView(dSeen,lp(-2,-2,0,3,0,0));a2.addView(a2t);
		r3.addView(a1,lw(1f,0,0,8,0));r3.addView(a2,lw(1f,0,0,0,0));ic2.addView(r3);bodyBox.addView(ic2,lp(-1,-2,0,0,0,18));
		bodyBox.addView(caps("SUPPORT AND MORE",11,cSub),lp(-2,-2,4,0,0,10));
		bodyBox.addView(linkRow(17,cInk,"Customer support",o,6,new Runnable(){public void run(){go(4);}}),lp(-1,-2,0,0,0,10));bodyBox.addView(linkRow(0,cInk,"Notifications",o,7,new Runnable(){public void run(){go(3);}}),lp(-1,-2,0,0,0,10));bodyBox.addView(linkRow(61,cInk,"Country",o,9,new Runnable(){public void run(){pickCountry(null,true);}}),lp(-1,-2,0,0,0,10));{String[]ci9=cInfo(cc());o[9].setText(ci9 !=null?ci9[1]+ "  |  " + ci9[2]+ " " + ci9[3]:"Not selected");}
		final String help=g("helpUrl","");if(help.length()> 0){bodyBox.addView(linkRow(33,cInk,"Help & community",o,8,new Runnable(){public void run(){openUrl(help);}}),lp(-1,-2,0,0,0,10));o[8].setText(help);}
		dBat=o[0];dRam=o[1];dNet=o[2];dRoot=o[3];dShz=o[4];dSto=o[5];supSubT=o[6];ntSubT=o[7];updSettings();updDev();pressAll(bodyBox);
		bodyBox.setAlpha(1f);if(!quiet)for(int i=0;i < bodyBox.getChildCount();i++){View c=bodyBox.getChildAt(i);c.setAlpha(0f);c.setTranslationY(dp(22));c.animate().alpha(1f).translationY(0f).setStartDelay(55 * i).setDuration(380).start();}
	}
	void updDev(){if(dBat==null)return;int b=battery();dBat.setText(b < 0?"-":b + "%");dRam.setText(ramTxt());dNet.setText(netTxt());boolean rt=rooted();dRoot.setText(rt?"Rooted":"Not Rooted");boolean sz=shizuku();dShz.setText(sz?"Installed":"Not Available");dSto.setText(stoTxt());}
	void updSettings(){
		if(sTitle==null)return;long l=premLeft(),total=Math.max(1L,(long)n(me,"premiumUntil")-(long)n(me,"premiumFrom"));boolean pr=l > 0;
		sTitle.setText(pr?"PREMIUM":"FREE");sSub.setText(pr?"Active  |  " + left(l):"Upgrade to unlock all features");String ds="0",un0="DAYS";if(pr){if(l >=DAY)ds=String.valueOf((l + DAY - 1)/ DAY);else if(l >=3600000L){ds=String.valueOf((l + 3599999L)/ 3600000L);un0="HOURS";}else{ds=String.valueOf(Math.max(1L,(l + 59999L)/ 60000L));un0="MINS";}}if(sUnit !=null)sUnit.setText(un0);sDays.setText(ds);sDays.setTextSize(ds.length()<=2?28:(ds.length()==3?22:17));sExp.setText(pr?dOnly((long)n(me,"premiumUntil")):"--");String kk=s(me,"premiumKey");sKey.setText(pr&&kk.length()> 0?kk:"none");
		float fr=pr?Math.max(0.03f,Math.min(1f,l /(float)total)):0.04f;if(sRing !=null)sRing.setFrac(fr,pr?0xFFFFFFFF:0x80FFFFFF);sTitle.setTextColor(0xFFFFFFFF);
		sCnt.setText(pr?"Premium cooldown is live. It ends in " + left(l):"No active premium on this device");dReg.setText(dOnly((long)n(me,"createdAt")));dSeen.setText(when((long)n(me,"lastSeen")));
		int su=supUnread();supSubT.setText(su > 0?su + " new repl" +(su > 1?"ies":"y"):"chat with us about any problem");int un=unread()- su;ntSubT.setText(un > 0?un + " new":"no new messages");
	}
	int ntI(String ty){return ty.equals("offer")?27:(ty.equals("success")?29:(ty.equals("warning")?37:33));}
	String ntL(String ty){return ty.equals("offer")?"OFFER":(ty.equals("success")?"SUCCESS":(ty.equals("warning")?"IMPORTANT":"UPDATE"));}
	int ntC(String ty){return ty.equals("offer")?cPurple:(ty.equals("success")?cGreen:(ty.equals("warning")?cAmber:cBlue));}
	void markViews(final String nid){
		if(viewed.contains(nid)||sp.getBoolean("v_" + nid,false))return;viewed.add(nid);
		db.child("views").child(nid).child(dev).runTransaction(new com.google.firebase.database.Transaction.Handler(){
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m){if(m.getValue()!=null)return com.google.firebase.database.Transaction.abort();m.setValue(now());return com.google.firebase.database.Transaction.success(m);}
			public void onComplete(com.google.firebase.database.DatabaseError e,boolean ok,com.google.firebase.database.DataSnapshot d){sp.edit().putBoolean("v_" + nid,true).apply();if(ok)bumpN(nid,"viewCount",1);}
		});
	}
	void bumpN(String nid,String f,final long dlt){
		db.child("notifs").child(nid).child(f).runTransaction(new com.google.firebase.database.Transaction.Handler(){
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m){m.setValue(Math.max(0L,lv(m)+ dlt));return com.google.firebase.database.Transaction.success(m);}
			public void onComplete(com.google.firebase.database.DatabaseError e,boolean ok,com.google.firebase.database.DataSnapshot d){}});
	}
	void toggleLike(com.google.firebase.database.DataSnapshot x){
		String nid=x.getKey();boolean liked=ulS !=null&&ulS.hasChild(nid);
		if(liked){db.child("ulikes").child(dev).child(nid).removeValue();db.child("likes").child(nid).child(dev).removeValue();bumpN(nid,"likeCount",-1);}
		else{db.child("ulikes").child(dev).child(nid).setValue(true);db.child("likes").child(nid).child(dev).setValue(now());bumpN(nid,"likeCount",1);}
	}
	void commentsDlg(final com.google.firebase.database.DataSnapshot nx){
		final String nid=nx.getKey();if(act.isFinishing())return;final android.app.Dialog d=new android.app.Dialog(act);d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
		final android.widget.LinearLayout x=lin(true);x.setPadding(dp(20),dp(18),dp(20),dp(16));x.setBackground(bg(cWhite,28,0,0));android.widget.LinearLayout top=lin(false);top.setGravity(16);top.addView(tv("Comments",19,cText,true),lw(1f,0,0,8,0));
		android.widget.FrameLayout cl=new android.widget.FrameLayout(act);cl.setBackground(bg(cSoft,16,0,0));cl.addView(ic(34,18,cInk),new android.widget.FrameLayout.LayoutParams(dp(18),dp(18),17));cl.setRotation(45f);cl.setOnClickListener(ck(new Runnable(){public void run(){d.dismiss();}}));top.addView(cl,lp(dp(36),dp(36)));x.addView(top);
		final android.widget.LinearLayout list=lin(true);android.widget.ScrollView csv=new android.widget.ScrollView(act);csv.setVerticalScrollBarEnabled(false);csv.addView(list);x.addView(csv,lp(-1,(int)(scrH * 0.4f),0,12,0,12));
		android.widget.LinearLayout in=lin(false);in.setGravity(16);final EditText et=edit("Write a comment...");in.addView(et,lw(1f,0,0,10,0));
		android.widget.FrameLayout sb=new android.widget.FrameLayout(act);sb.setBackground(bg(cInk,24,0,0));sb.addView(ic(16,20,0xFFFFFFFF),new android.widget.FrameLayout.LayoutParams(dp(20),dp(20),17));
		sb.setOnClickListener(ck(new Runnable(){public void run(){String t=et.getText().toString().trim();if(t.length()==0)return;java.util.HashMap<String,Object> c=new java.util.HashMap<String,Object>();c.put("dev",dev);c.put("name",uname());c.put("text",t);c.put("time",com.google.firebase.database.ServerValue.TIMESTAMP);db.child("comments").child(nid).push().setValue(c);bumpN(nid,"commentCount",1);et.setText("");}}));in.addView(sb,lp(dp(48),dp(48)));x.addView(in);
		final com.google.firebase.database.DatabaseReference ref=db.child("comments").child(nid);
		final com.google.firebase.database.ValueEventListener l=new com.google.firebase.database.ValueEventListener(){
			public void onDataChange(com.google.firebase.database.DataSnapshot s0){
				list.removeAllViews();java.util.ArrayList<com.google.firebase.database.DataSnapshot> cs=kids(s0,"time",false);
				for(final com.google.firebase.database.DataSnapshot c:cs){android.widget.LinearLayout r=lin(true);r.setPadding(dp(14),dp(10),dp(14),dp(10));r.setBackground(bg(cCard,16,0,0));android.widget.LinearLayout h=lin(false);h.setGravity(16);h.addView(tv(s(c,"name"),13,cText,true),lw(1f,0,0,8,0));h.addView(tv(ago((long)n(c,"time")),10,cSub,false));
					if(dev.equals(s(c,"dev"))){View del=ic(24,16,cSub);del.setOnClickListener(ck(new Runnable(){public void run(){c.getRef().removeValue();bumpN(nid,"commentCount",-1);}}));h.addView(del,lp(dp(16),dp(16),10,0,0,0));}
					r.addView(h);r.addView(tv(s(c,"text"),13,cSub,false),lp(-1,-2,0,4,0,0));list.addView(r,lp(-1,-2,0,0,0,8));}
				if(cs.size()==0)list.addView(tv("No comments yet. Be the first!",13,cSub,false),lp(-2,-2,0,20,0,0));pressAll(list);}public void onCancelled(com.google.firebase.database.DatabaseError e){}};
		ref.addValueEventListener(l);d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener(){public void onDismiss(android.content.DialogInterface i){ref.removeEventListener(l);}});
		d.setContentView(x);d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));d.getWindow().setDimAmount(0.65f);d.getWindow().setSoftInputMode(16);d.show();d.getWindow().setLayout((int)(scrW * 0.92f),-2);
		x.setAlpha(0f);x.setTranslationY(dp(40));x.animate().alpha(1f).translationY(0f).setDuration(300).start();pressAll(x);
	}
	void pgNotifs(){
		int su=supUnread();
		if(su > 0){android.widget.LinearLayout a=lin(false);a.setGravity(16);a.setPadding(dp(16),dp(14),dp(16),dp(14));a.setBackground(bg(cInk,24,0,0));a.addView(ib(17,0xFFFFFFFF,0x26FFFFFF,42,15),lp(dp(42),dp(42),0,0,12,0));
			android.widget.LinearLayout m=lin(true);m.addView(tv("Support replied",15,0xFFFFFFFF,true));m.addView(tv(su + " new message" +(su > 1?"s":"")+ " from support",12,0xFFB7BEC8,false),lp(-2,-2,0,2,0,0));a.addView(m,lw(1f,0,0,8,0));a.addView(ic(19,16,0xFFB7BEC8));
			a.setOnClickListener(ck(new Runnable(){public void run(){go(4);}}));bodyBox.addView(a,lp(-1,-2,0,6,0,14));}
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l=kids(notifS,"time",true);int c=0;String lastG="";
		for(final com.google.firebase.database.DataSnapshot x:l){
			String to=s(x,"to");if(!(to.equals("all")||to.equals(dev)))continue;c++;long tm=(long)n(x,"time");String g2=tm > 0?dayLbl(tm):"Today";markViews(x.getKey());
			if(!g2.equals(lastG)){lastG=g2;android.widget.LinearLayout gh=lin(false);gh.setGravity(16);gh.addView(caps(g2.toUpperCase(),11,cSub),lp(-2,-2,0,0,12,0));View gline=new View(act);gline.setBackgroundColor(0xFFDDE1E8);gh.addView(gline,new android.widget.LinearLayout.LayoutParams(0,dp(1),1f));bodyBox.addView(gh,lp(-1,-2,4,c==1&&su==0?6:10,4,10));}
			String ty=s(x,"type");boolean isNew=tm > notifPrev;
			android.widget.LinearLayout c1=lin(true);c1.setPadding(dp(16),dp(16),dp(16),dp(14));c1.setBackground(isNew?bg(cWhite,24,cInk,2):bg(cCard,24,0xFFDDE1E8,1));
			android.widget.LinearLayout tr=lin(false);tr.setGravity(16);tr.addView(ib(ntI(ty),cInk,isNew?cSoft:cWhite,44,16),lp(dp(44),dp(44),0,0,12,0));
			android.widget.LinearLayout tm2=lin(true);android.widget.LinearLayout lr=lin(false);lr.setGravity(16);lr.addView(caps(ntL(ty),9,cSub),lp(-2,-2,0,0,8,0));
			if(isNew){TextView nw=caps("NEW",8,0xFFFFFFFF);nw.setPadding(dp(8),dp(3),dp(8),dp(3));nw.setBackground(bg(cInk,8,0,0));lr.addView(nw);}tm2.addView(lr);tm2.addView(tv(s(x,"title"),16,cText,true),lp(-1,-2,0,4,0,0));
			tr.addView(tm2,lw(1f,0,0,8,0));tr.addView(tv(ago(tm),11,cSub,false));c1.addView(tr);
			if(s(x,"body").length()> 0){TextView bt=tv(s(x,"body"),14,cSub,false);bt.setLineSpacing(0,1.15f);c1.addView(bt,lp(-1,-2,0,12,0,0));}
			String im=s(x,"image").trim();if(im.length()> 0){ImageView iv=new ImageView(act);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(bg(cSoft,18,0,0));if(android.os.Build.VERSION.SDK_INT >=21)iv.setClipToOutline(true);c1.addView(iv,lp(-1,dp(170),0,12,0,0));loadImg(iv,im);}
			final String url=s(x,"url").trim();if(url.length()> 0){android.widget.LinearLayout lk=lin(false);lk.setGravity(17);lk.setPadding(dp(16),dp(11),dp(16),dp(11));lk.setBackground(bg(cInk,14,0,0));lk.addView(caps("OPEN",11,0xFFFFFFFF),lp(-2,-2,0,0,8,0));lk.addView(ic(39,14,0xFFFFFFFF),lp(dp(14),dp(14)));lk.setOnClickListener(ck(new Runnable(){public void run(){openUrl(url);}}));c1.addView(lk,lp(-1,-2,0,12,0,0));}
			android.widget.LinearLayout ar=lin(false);ar.setGravity(16);boolean liked=ulS !=null&&ulS.hasChild(x.getKey());
			android.widget.LinearLayout lk2=lin(false);lk2.setGravity(16);lk2.setPadding(dp(12),dp(8),dp(14),dp(8));lk2.setBackground(bg(liked?cInk:cSoft,16,0,0));lk2.addView(ic(liked?21:20,18,liked?0xFFFFFFFF:cInk),lp(dp(18),dp(18),0,0,6,0));lk2.addView(tv(nf((long)n(x,"likeCount")),13,liked?0xFFFFFFFF:cInk,true));lk2.setOnClickListener(ck(new Runnable(){public void run(){toggleLike(x);}}));ar.addView(lk2,lp(-2,-2,0,0,8,0));
			android.widget.LinearLayout cm=lin(false);cm.setGravity(16);cm.setPadding(dp(12),dp(8),dp(14),dp(8));cm.setBackground(bg(cSoft,16,0,0));cm.addView(ic(22,18,cInk),lp(dp(18),dp(18),0,0,6,0));cm.addView(tv(nf((long)n(x,"commentCount")),13,cInk,true));cm.setOnClickListener(ck(new Runnable(){public void run(){commentsDlg(x);}}));ar.addView(cm,lp(-2,-2));
			c1.addView(ar,lp(-1,-2,0,14,0,0));bodyBox.addView(c1,lp(-1,-2,0,0,0,12));if(!quiet){c1.setAlpha(0f);c1.setTranslationY(dp(22));c1.animate().alpha(1f).translationY(0f).setStartDelay(60 * Math.min(c,6)).setDuration(380).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();}
		}
		if(c==0&&su==0){android.widget.LinearLayout em=lin(true);em.setGravity(17);em.addView(ib(0,cSub,cSoft,64,32),lp(dp(64),dp(64)));em.addView(tv("You are all caught up",15,cText,true),lp(-2,-2,0,14,0,0));em.addView(tv("New messages will show here",12,cSub,false),lp(-2,-2,0,4,0,0));bodyBox.addView(em,lp(-1,-2,0,50,0,0));}
		pressAll(bodyBox);
	}
	int supUnread(){return supS==null?0:(int)n(supS.child("meta"),"unreadUser");}
	String[]topics(){String[]t2=g("supTopics","Premium problem,Redeem code issue,Payment / Purchase,App problem,Feature request,Other").split(",");for(int i=0;i < t2.length;i++)t2[i]=t2[i].trim();return t2;}
	View chipRow(final String[]labels,final int[]sel){
		final TextView[]cs=new TextView[labels.length];Flow row=new Flow(dp(8));
		for(int i=0;i < labels.length;i++){final int idx=i;TextView b=tv(labels[i],13,cSub,true);b.setGravity(17);b.setPadding(dp(16),dp(10),dp(16),dp(10));cs[i]=b;b.setOnClickListener(ck(new Runnable(){public void run(){sel[0]=idx;paintC(cs,idx);}}));row.addView(b);}
		paintC(cs,sel[0]);return row;
	}
	void paintC(TextView[]cs,int s){for(int i=0;i < cs.length;i++){boolean on=i==s;cs[i].setTextColor(on?0xFFFFFFFF:cSub);cs[i].setBackground(bg(on?cInk:cSoft,14,0,0));}}
	void sendSupport(){
		final String txt=chatEt.getText().toString().trim();if(txt.length()==0)return;com.google.firebase.database.DatabaseReference r=db.child("support").child(dev);java.util.HashMap<String,Object> m=new java.util.HashMap<String,Object>();
		m.put("from","user");m.put("text",txt);m.put("time",com.google.firebase.database.ServerValue.TIMESTAMP);m.put("seen",false);r.child("msgs").push().setValue(m);
		java.util.HashMap<String,Object> mt=new java.util.HashMap<String,Object>();mt.put("name",android.os.Build.MODEL);mt.put("device",dev);mt.put("lastMsg",txt.length()> 80?txt.substring(0,80):txt);mt.put("lastTime",com.google.firebase.database.ServerValue.TIMESTAMP);mt.put("lastFrom","user");
		if(supS==null||!supS.child("msgs").hasChildren()){String[]tp=topics();mt.put("topic",tp[Math.min(supSelA[0],tp.length - 1)]);}r.child("meta").updateChildren(mt);
		r.child("meta").child("unreadAdmin").runTransaction(new com.google.firebase.database.Transaction.Handler(){
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData d){d.setValue(lv(d)+ 1L);return com.google.firebase.database.Transaction.success(d);}
			public void onComplete(com.google.firebase.database.DatabaseError e,boolean ok,com.google.firebase.database.DataSnapshot d){}});
		chatEt.setText("");
	}
	android.widget.LinearLayout bubble(final com.google.firebase.database.DataSnapshot x){
		boolean mine="user".equals(s(x,"from"));android.widget.LinearLayout row=lin(false);row.setGravity(mine?android.view.Gravity.END:android.view.Gravity.START);
		android.widget.LinearLayout b=lin(true);b.setPadding(dp(14),dp(10),dp(14),dp(8));b.setBackground(bg(mine?cInk:cCard,20,mine?0:cStroke,1));
		if(!mine)b.addView(tv("Support",11,cSub,true),lp(-2,-2,0,0,0,3));TextView t=tv(s(x,"text"),14,mine?0xFFFFFFFF:cText,false);t.setMaxWidth((int)(scrW * 0.66f));b.addView(t,lp(-2,-2));
		long tm=(long)n(x,"time");android.widget.LinearLayout mr=lin(false);mr.setGravity(android.view.Gravity.END|16);mr.addView(tv(tm > 0?new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(tm)):"...",10,mine?0xFFB4BEC8:cSub,false));
		if(mine){boolean sn="true".equals(s(x,"seen"));mr.addView(tv(sn?"  \u2713\u2713 Seen":"  \u2713 Sent",10,sn?0xFF6CB6FF:0xFFB4BEC8,true));}b.addView(mr,lp(-1,-2,0,4,0,0));
		if(mine)b.setOnLongClickListener(new View.OnLongClickListener(){public boolean onLongClick(View v){dlgI(24,cRed,"Delete message?","",null,"DELETE",cRed,new Runnable(){public void run(){x.getRef().removeValue();}},true,true);return true;}});
		row.addView(b,lp(-2,-2));return row;
	}
	void pgSupport(){
		faqBlock();
		com.google.firebase.database.DataSnapshot ms=supS==null?null:supS.child("msgs");java.util.ArrayList<com.google.firebase.database.DataSnapshot> l=kids(ms,"time",false);
		if(l.size()==0){
			android.widget.LinearLayout c1=card();c1.addView(ib(17,cInk,cSoft,64,22),lp(dp(64),dp(64)));c1.addView(tv("How can we help?",20,cText,true),lp(-2,-2,0,14,0,0));c1.addView(tv(g("supWelcome","Pick a topic, then tell us your problem. We will reply as soon as possible."),13,cSub,false),lp(-1,-2,0,6,0,0));
			c1.addView(caps("CHOOSE A TOPIC",11,cSub),lp(-2,-2,0,16,0,8));c1.addView(chipRow(topics(),supSelA));c1.addView(tv("Then type your message below and tap send.",12,cSub,false),lp(-2,-2,0,16,0,0));bodyBox.addView(c1,lp(-1,-2,0,6,0,0));
		}else{
			String lastD="";
			for(com.google.firebase.database.DataSnapshot x:l){long tm=(long)n(x,"time");
				if(tm > 0){String dl=dayLbl(tm);if(!dl.equals(lastD)){lastD=dl;TextView sp1=caps(dl,10,cSub);sp1.setPadding(dp(12),dp(5),dp(12),dp(5));sp1.setBackground(bg(cSoft,10,0,0));android.widget.LinearLayout w=lin(false);w.setGravity(17);w.addView(sp1);bodyBox.addView(w,lp(-1,-2,0,8,0,10));}}
				bodyBox.addView(bubble(x),lp(-1,-2,0,0,0,8));if("admin".equals(s(x,"from"))&&!"true".equals(s(x,"seen")))x.getRef().child("seen").setValue(true);}
			if(supUnread()> 0)db.child("support").child(dev).child("meta").child("unreadUser").setValue(0);
		}
		pressAll(bodyBox);sv.post(new Runnable(){public void run(){sv.fullScroll(View.FOCUS_DOWN);}});
	}
	String dk(long t){return new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(new java.util.Date(t));}
	void fillReward(){
		if(rwBox==null)return;
		boolean on=gb("dailyOn",false)&&!locked();String today=dk(now()),last=s(me,"rwDay");final boolean can=!today.equals(last);
		long st=(long)n(me,"rwStreak");if(!today.equals(last)&&!dk(now()- DAY).equals(last))st=0;if(can&&st >=7)st=0;
		long hr=gl("dailyHours",2),bon=gl("dailyBonusHours",12);
		String sg=on + "|" + can + "|" + st + "|" + hr + "|" + bon + "|" + today;if(sg.equals(rwSig))return;rwSig=sg;rwBox.removeAllViews();if(!on)return;
		android.widget.LinearLayout c=card();c.addView(caps("DAILY REWARD",11,cSub));
		c.addView(tv(can?"Claim +" + hr + "h premium":"Reward claimed today",18,cText,true),lp(-2,-2,0,8,0,0));
		c.addView(tv("Day 7 gives +" + bon + "h. Come back every day to keep your streak.",12,cSub,false),lp(-1,-2,0,4,0,12));
		android.widget.LinearLayout row=lin(false);
		for(int i=1;i <=7;i++){boolean fill=i <=st;TextView d=tv(String.valueOf(i),12,fill?0xFFFFFFFF:(i==7?cAmber:cSub),true);d.setGravity(17);d.setPadding(0,dp(9),0,dp(9));d.setBackground(bg(fill?cInk:(i==7?0x33F59E0B:cSoft),12,0,0));row.addView(d,lw(1f,0,0,i < 7?6:0,0));}
		c.addView(row,lp(-1,-2,0,0,0,14));
		Runnable go=can?new Runnable(){public void run(){claimDaily();}}:null;
		c.addView(btn(can?"CLAIM +" + hr + "H":"COME BACK TOMORROW",can?0xFFFFFFFF:cSub,can?cInk:cSoft,go),lp(-1,-2));
		rwBox.addView(c);pressAll(rwBox);
	}
	void claimDaily(){
		if(!gb("dailyOn",false)||locked()||me==null)return;
		final long mx=gl("dailyMaxDev",0);
		if(mx > 0&&!"true".equals(s(me,"rwDevice"))){
			db.child("rwCount").runTransaction(new com.google.firebase.database.Transaction.Handler(){
				public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m){long v=lv(m);if(v >=mx)return com.google.firebase.database.Transaction.abort();m.setValue(v + 1L);return com.google.firebase.database.Transaction.success(m);}
				public void onComplete(com.google.firebase.database.DatabaseError e,final boolean ok,com.google.firebase.database.DataSnapshot d){
					act.runOnUiThread(new Runnable(){public void run(){if(ok){db.child("users").child(dev).child("rwDevice").setValue(true);claimNow();}else toast("Daily reward device limit reached");}});
				}
			});
		}else claimNow();
	}
	void claimNow(){
		if(!gb("dailyOn",false)||locked())return;
		final String today=dk(now()),yest=dk(now()- DAY);final long hr=gl("dailyHours",2)* 3600000L,bon=gl("dailyBonusHours",12)* 3600000L;final long[]added={0};
		db.child("users").child(dev).runTransaction(new com.google.firebase.database.Transaction.Handler(){
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m){
				Object o=m.child("rwDay").getValue();String last=o==null?"":String.valueOf(o);if(today.equals(last))return com.google.firebase.database.Transaction.abort();
				long prev=yest.equals(last)?lv(m.child("rwStreak")):0L;long st=prev >=7?1:prev + 1;long add=st==7?bon:hr;added[0]=add;
				long tm=now(),u=lv(m.child("premiumUntil"));boolean live=u > tm;m.child("premiumUntil").setValue((live?u:tm)+ add);
				if(!live){m.child("premiumFrom").setValue(tm);m.child("premiumSrc").setValue("reward");m.child("premiumKey").setValue("");}
				m.child("rwDay").setValue(today);m.child("rwStreak").setValue(st);m.child("rwTotal").setValue(lv(m.child("rwTotal"))+ 1L);return com.google.firebase.database.Transaction.success(m);
			}
			public void onComplete(com.google.firebase.database.DatabaseError e,final boolean ok,com.google.firebase.database.DataSnapshot d){
				act.runOnUiThread(new Runnable(){public void run(){rwSig="";if(ok)toast("Reward added: +" +(added[0]/ 3600000L)+ "h premium");refresh();}});
			}
		});
	}
	void maybeTrial(){
		if(trialTried||cfg==null||me==null||locked()||!gb("trialOn",false))return;
		trialTried=true;if(me.hasChild("trialAt")||me.hasChild("premiumUntil"))return;
		final long days=Math.max(1L,gl("trialDays",1));
		db.child("users").child(dev).runTransaction(new com.google.firebase.database.Transaction.Handler(){
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m){
				if(m.child("trialAt").getValue()!=null||m.child("premiumUntil").getValue()!=null)return com.google.firebase.database.Transaction.abort();
				long tm=now();m.child("premiumUntil").setValue(tm + days * DAY);m.child("premiumFrom").setValue(tm);m.child("premiumSrc").setValue("trial");m.child("premiumKey").setValue("");m.child("trialAt").setValue(tm);
				return com.google.firebase.database.Transaction.success(m);
			}
			public void onComplete(com.google.firebase.database.DatabaseError e,final boolean ok,com.google.firebase.database.DataSnapshot d){
				if(ok)act.runOnUiThread(new Runnable(){public void run(){msg("Free trial started","Premium is unlocked for " + days +(days==1?" day":" days")+ ". Enjoy all tools.");}});
			}
		});
	}
	void faqBlock(){
		if(faqS==null||!faqS.hasChildren())return;java.util.ArrayList<com.google.firebase.database.DataSnapshot> l=kids(faqS,"order",false);
		android.widget.LinearLayout c=card();c.addView(caps("FAQ",11,cSub),lp(-2,-2,0,0,0,4));int cn=0;
		for(final com.google.firebase.database.DataSnapshot x:l){
			if("false".equals(s(x,"active"))||s(x,"q").length()==0)continue;cn++;
			android.widget.LinearLayout row=lin(true);row.setPadding(0,dp(12),0,dp(12));android.widget.LinearLayout top=lin(false);top.setGravity(16);
			top.addView(tv(s(x,"q"),14,cText,true),lw(1f,0,0,8,0));final TextView pl=tv("+",18,cSub,true);top.addView(pl);row.addView(top);
			final TextView an=tv(s(x,"a"),13,cSub,false);an.setVisibility(8);row.addView(an,lp(-1,-2,0,8,0,0));
			row.setOnClickListener(ck(new Runnable(){public void run(){boolean o=an.getVisibility()==0;an.setVisibility(o?8:0);pl.setText(o?"+":"\u2212");}}));
			View dv=new View(act);dv.setBackgroundColor(cStroke);c.addView(dv,lp(-1,dp(1),0,0,0,0));c.addView(row);
		}
		if(cn > 0)bodyBox.addView(c,lp(-1,-2,0,6,0,12));
	}
	androidx.activity.result.ActivityResultLauncher<android.net.Uri> safL;android.app.Dialog pd;int permSel;String permErr="";
	android.widget.LinearLayout[]pCard=new android.widget.LinearLayout[2];TextView[]pSt=new TextView[2];TextView pErrT,pAll;
	void initSaf(){
		try{safL=((androidx.activity.ComponentActivity)act).registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree(),new androidx.activity.result.ActivityResultCallback<android.net.Uri>(){public void onActivityResult(android.net.Uri u){safResult(u);}});}catch(Throwable e){safL=null;}
	}
	String safWant(){return "primary:" + SAF_PATH.trim().replaceAll("^/storage/emulated/\\d+/|^/storage/self/primary/|^/sdcard/|^/+","").replaceAll("/+$","");}
	boolean shzOk(){try{Class<?> c=Class.forName("rikka.shizuku.Shizuku");return((Boolean)c.getMethod("pingBinder").invoke(null))&&((Integer)c.getMethod("checkSelfPermission").invoke(null))==0;}catch(Throwable e){return false;}}
	boolean safOk(){
		try{String sv=sp.getString("safUri","");if(sv.length()==0)return false;
			if(!android.provider.DocumentsContract.getTreeDocumentId(android.net.Uri.parse(sv)).replaceAll("/+$","").equalsIgnoreCase(safWant()))return false;
			for(android.content.UriPermission p:act.getContentResolver().getPersistedUriPermissions())if(p.getUri().toString().equals(sv)&&p.isWritePermission())return true;
		}catch(Throwable e){}return false;
	}
	boolean permOk(){return shzOk()||safOk();}
	boolean allOk(){
		if(android.os.Build.VERSION.SDK_INT < 23)return true;
		try{if(android.os.Build.VERSION.SDK_INT >=30)return(Boolean)android.os.Environment.class.getMethod("isExternalStorageManager").invoke(null);return act.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")==0;}catch(Throwable e){return false;}
	}
	void askAll(){
		try{if(android.os.Build.VERSION.SDK_INT >=30)act.startActivity(new android.content.Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION",android.net.Uri.parse("package:" + act.getPackageName())));
			else if(android.os.Build.VERSION.SDK_INT >=23)act.requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE","android.permission.WRITE_EXTERNAL_STORAGE"},7701);}
		catch(Exception e){try{act.startActivity(new android.content.Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"));}catch(Exception e2){toast("cannot open settings");}}
	}
	boolean openShizuku(){try{android.content.Intent li=act.getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");if(li==null){li=new android.content.Intent(android.content.Intent.ACTION_MAIN);li.setClassName("moe.shizuku.privileged.api","moe.shizuku.manager.MainActivity");}li.addFlags(268435456);act.startActivity(li);return true;}catch(Throwable e){return false;}}
	void shzGen(){
		try{Class<?> c=Class.forName("rikka.shizuku.Shizuku");
			if(!((Boolean)c.getMethod("pingBinder").invoke(null))){permErr=openShizuku()?"Shizuku is not running. Start Shizuku, then tap generate again":"Shizuku app is not installed on this device";return;}
			if(((Integer)c.getMethod("checkSelfPermission").invoke(null))==0){updPerm();return;}
			boolean denied=false;try{denied=(Boolean)c.getMethod("shouldShowRequestPermissionRationale").invoke(null);}catch(Throwable ig){}
			if(denied){permErr="Shizuku permission was denied. Open Shizuku, find this app and allow it";openShizuku();return;}
			c.getMethod("requestPermission",int.class).invoke(null,4501);toast("Approve in the Shizuku popup");
		}catch(ClassNotFoundException e){permErr="Shizuku library is missing in this project";}
		catch(Throwable e){permErr="Shizuku failed: " +(e.getCause()!=null?e.getCause().getMessage():e.getMessage());}
	}
	void safGen(){
		if(android.os.Build.VERSION.SDK_INT < 21||safL==null){permErr="Folder picker is not supported on this device";return;}
		try{safL.launch(android.provider.DocumentsContract.buildDocumentUri("com.android.externalstorage.documents",safWant()));toast("Open the folder, tap USE THIS FOLDER, then ALLOW");}
		catch(Throwable e){permErr="Cannot open folder picker";}
	}
	void safResult(android.net.Uri u){
		if(u==null){permErr="No folder selected, permission generate failed";paintPerm();return;}
		String id="";try{id=android.provider.DocumentsContract.getTreeDocumentId(u);}catch(Exception e){}
		if(!id.replaceAll("/+$","").equalsIgnoreCase(safWant())){permErr="Wrong folder selected, permission generate failed. Select exactly: " + SAF_PATH;paintPerm();return;}
		try{act.getContentResolver().takePersistableUriPermission(u,3);sp.edit().putString("safUri",u.toString()).apply();permErr="";}catch(Exception e){permErr="Could not save folder permission, try again";}
		updPerm();paintPerm();
	}
	void genPerm(){permErr="";if(permSel==0)shzGen();else safGen();paintPerm();}
	void paintPerm(){
		if(pd==null)return;
		for(int i=0;i < 2;i++){boolean on=permSel==i,ok=i==0?shzOk():safOk();pCard[i].setBackground(on?bg(cWhite,20,cInk,2):bg(cCard,20,cStroke,1));pSt[i].setText(ok?"GRANTED":"NOT GIVEN");pSt[i].setTextColor(ok?cGreen:cSub);}
		boolean ao=allOk();pAll.setText(ao?"ALL FILES ACCESS  |  ON":"ALL FILES ACCESS  |  TAP TO ALLOW");pAll.setTextColor(ao?cGreen:cInk);
		pErrT.setText(permErr);pErrT.setVisibility(permErr.length()> 0?0:8);
	}
	void updPerm(){
		if(pd==null||!pd.isShowing())return;
		if(permOk()){try{pd.dismiss();}catch(Exception e){}pd=null;toast("Permission generated");cleanup();return;}
		paintPerm();
	}
	void showPerm(){
		if(permOk()||act.isFinishing()||(pd !=null&&pd.isShowing()))return;permSel=shizuku()?0:1;permErr="";
		pd=new android.app.Dialog(act);pd.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);pd.setCancelable(false);pd.setCanceledOnTouchOutside(false);
		final android.widget.LinearLayout x=lin(true);x.setGravity(android.view.Gravity.CENTER_HORIZONTAL);x.setPadding(dp(22),dp(26),dp(22),dp(20));x.setBackground(bg(cWhite,30,0,0));
		final android.widget.FrameLayout ring=new android.widget.FrameLayout(act);ring.setBackground(bg(cSoft,36,0,0));ring.addView(ic(12,32,cInk),new android.widget.FrameLayout.LayoutParams(dp(32),dp(32),17));x.addView(ring,lp(dp(72),dp(72)));
		TextView t=tv("Permission required",20,cText,true);t.setGravity(17);x.addView(t,lp(-1,-2,0,16,0,0));
		TextView st=tv("Allow any one of these to continue. This stays open until a permission is generated.",13,cSub,false);st.setGravity(17);st.setLineSpacing(0,1.15f);x.addView(st,lp(-1,-2,4,8,4,0));
		String[]tt={"Shizuku","Safe storage folder"};String[]dd={"Recommended. Needs the Shizuku app running","Android 11 and below. Pick the exact game folder"};int[]ii={10,14};
		for(int i=0;i < 2;i++){
			final int idx=i;android.widget.LinearLayout c=lin(false);c.setGravity(16);c.setPadding(dp(14),dp(14),dp(14),dp(14));c.addView(ib(ii[i],cInk,cSoft,44,16),lp(dp(44),dp(44),0,0,12,0));
			android.widget.LinearLayout m=lin(true);m.addView(tv(tt[i],15,cText,true));m.addView(tv(dd[i],12,cSub,false),lp(-2,-2,0,3,0,0));c.addView(m,lw(1f,0,0,8,0));
			TextView s2=caps("",9,cSub);pSt[i]=s2;c.addView(s2);pCard[i]=c;c.setOnClickListener(ck(new Runnable(){public void run(){permSel=idx;permErr="";paintPerm();}}));x.addView(c,lp(-1,-2,0,i==0?18:10,0,0));
		}
		pAll=caps("",10,cInk);pAll.setGravity(17);pAll.setPadding(dp(12),dp(12),dp(12),dp(12));pAll.setBackground(bg(cSoft,14,0,0));pAll.setOnClickListener(ck(new Runnable(){public void run(){if(!allOk())askAll();}}));x.addView(pAll,lp(-1,-2,0,10,0,0));
		pErrT=tv("",12,cRed,true);pErrT.setGravity(17);pErrT.setVisibility(8);x.addView(pErrT,lp(-1,-2,4,12,4,0));
		x.addView(btn("GENERATE PERMISSION",0xFFFFFFFF,cInk,new Runnable(){public void run(){genPerm();}}),lp(-1,-2,0,16,0,0));
		pd.setContentView(x);pd.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));pd.getWindow().setDimAmount(0.65f);pd.show();pd.getWindow().setLayout((int)(scrW * 0.9f),-2);
		x.setAlpha(0f);x.setScaleX(0.86f);x.setScaleY(0.86f);x.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(new android.view.animation.OvershootInterpolator(1.2f)).start();
		ring.setScaleX(0f);ring.setScaleY(0f);ring.animate().scaleX(1f).scaleY(1f).setStartDelay(140).setDuration(420).setInterpolator(new android.view.animation.OvershootInterpolator(2.4f)).start();
		paintPerm();pressAll(x);
	}
	void tick(){
		hd.postDelayed(new Runnable(){public void run(){
				if(act.isFinishing())return;tk++;
				try{
					if(page==2&&setBuilt){updSettings();if(tk % 5==0)updDev();}
					if(page==0&&slider !=null){int cnt=kids(slidesS,"order",false).size();long sec=Math.max(2,gl("slideSec",4));if(cnt > 1&&System.currentTimeMillis()- lastTouch > 3500&&++slideTick >=sec){slideTick=0;slideIdx=(slideIdx + 1)% cnt;slider.smoothScrollTo(slideIdx *(scrW - dp(40)+ dp(12)),0);setDots(slideIdx);}}
					if(tk % 45==0)db.child("users").child(dev).child("lastSeen").setValue(com.google.firebase.database.ServerValue.TIMESTAMP);
					if(pd !=null&&pd.isShowing())updPerm();
				}catch(Exception e){}
				tick();}},1000);
	}
	boolean cleaned,cDone,cErr;android.app.Dialog cdl;TextView cTx,cSb;View cRing;final float[]cp={0f};android.graphics.Paint pTr,pAr,pTx;
	String relPath(String p){
		String gp="/storage/emulated/0/" + safWant().substring(8)+ "/";p=p==null?"":p.trim().replace("\\","/").replaceFirst("^/sdcard/","/storage/emulated/0/");
		if(p.startsWith("/")){if(!p.startsWith(gp))return null;p=p.substring(gp.length());}
		p=p.replaceAll("^/+|/+$","");if(p.length()==0)return null;
		for(String seg:p.split("/"))if(seg.length()==0||seg.equals("..")||seg.equals("."))return null;
		return p;
	}
	String kidId(android.net.Uri tree,String pid,String name){
		android.database.Cursor c=null;
		try{c=act.getContentResolver().query(android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree,pid),new String[]{"document_id","_display_name"},null,null,null);
			while(c !=null&&c.moveToNext())if(name.equals(c.getString(1)))return c.getString(0);}catch(Throwable e){}finally{if(c !=null)c.close();}
		return null;
	}
	void safRm(String rel)throws Exception{
		android.net.Uri tree=android.net.Uri.parse(sp.getString("safUri",""));String id=android.provider.DocumentsContract.getTreeDocumentId(tree);
		for(String seg:rel.split("/")){id=kidId(tree,id,seg);if(id==null)return;}
		android.provider.DocumentsContract.deleteDocument(act.getContentResolver(),android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,id));
	}
	void shzRm(String path)throws Exception{
		try{Class<?> c=Class.forName("rikka.shizuku.Shizuku");java.lang.reflect.Method m=c.getDeclaredMethod("newProcess",String[].class,String[].class,String.class);m.setAccessible(true);
			java.lang.Process p=(java.lang.Process)m.invoke(null,new Object[]{new String[]{"sh","-c","rm -rf \"$0\"",path},null,null});
			if(p.waitFor()!=0)throw new java.io.IOException("rm failed");return;
		}catch(Throwable e){}
		new ShizukuMaster().deleteShizuku(path);
	}
	void cAnim(float t){android.animation.ValueAnimator a=android.animation.ValueAnimator.ofFloat(cp[0],t);a.setDuration(260);a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener(){public void onAnimationUpdate(android.animation.ValueAnimator v){cp[0]=(Float)v.getAnimatedValue();if(cRing !=null)cRing.invalidate();}});a.start();}
	void cShow(){
		if(cdl !=null||act.isFinishing())return;
		pTr=new android.graphics.Paint(1);pTr.setStyle(android.graphics.Paint.Style.STROKE);pTr.setStrokeWidth(dp(5));pTr.setColor(cSoft);
		pAr=new android.graphics.Paint(1);pAr.setStyle(android.graphics.Paint.Style.STROKE);pAr.setStrokeWidth(dp(5));pAr.setStrokeCap(android.graphics.Paint.Cap.ROUND);pAr.setColor(cInk);
		pTx=new android.graphics.Paint(1);pTx.setColor(cText);pTx.setTextSize(dp(13));pTx.setTextAlign(android.graphics.Paint.Align.CENTER);pTx.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
		cRing=new View(act){protected void onDraw(android.graphics.Canvas c){float w=getWidth(),h=getHeight(),s=dp(5)/ 2f;android.graphics.RectF r=new android.graphics.RectF(s,s,w - s,h - s);
				c.drawArc(r,0,360,false,pTr);c.drawArc(r,-90,360f * cp[0],false,pAr);c.drawText((int)(cp[0]* 100)+ "%",w / 2f,h / 2f + dp(5),pTx);}};
		android.widget.LinearLayout card=lin(false);card.setGravity(16);card.setPadding(dp(14),dp(12),dp(20),dp(12));card.setBackground(bg(cWhite,22,cStroke,1));
		card.addView(cRing,lp(dp(54),dp(54),0,0,14,0));
		android.widget.LinearLayout tx=lin(true);cTx=tv("Cleaning up",15,cText,true);cSb=tv("Preparing...",12,cSub,false);cSb.setSingleLine(true);cSb.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);cSb.setMaxWidth(dp(200));
		tx.addView(cTx);tx.addView(cSb,lp(-2,-2,0,2,0,0));card.addView(tx,lp(-2,-2));
		cdl=new android.app.Dialog(act);cdl.requestWindowFeature(1);cdl.setCancelable(false);cdl.setContentView(card);
		android.view.Window w=cdl.getWindow();w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));w.clearFlags(2);w.addFlags(0x28);w.setGravity(49);w.setLayout(-2,-2);
		android.view.WindowManager.LayoutParams a=w.getAttributes();a.y=dp(24);w.setAttributes(a);cdl.show();
	}
	void cStep(int k,int n,String r,boolean done){if(cdl==null)return;cAnim(done?(k + 1f)/ n:(k + 0.5f)/ n);cSb.setText((k + 1)+ " of " + n + "  |  " + r);}
	void cEnd(){
		if(cdl==null)return;cAnim(1f);cTx.setText(cErr?"Finished with errors":"All clean");cSb.setText(cErr?"Some folders could not be removed":"Nothing left to remove");
		hd.postDelayed(new Runnable(){public void run(){try{if(cdl !=null)cdl.dismiss();}catch(Throwable e){}cdl=null;}},900);
	}
	void cleanup(){
		if(cleaned||DEL_PATHS.length==0||!permOk())return;cleaned=true;
		final java.util.ArrayList<String> L=new java.util.ArrayList<String>();for(String p:DEL_PATHS){String r=relPath(p);if(r !=null)L.add(r);}
		if(L.isEmpty())return;
		final boolean shz=shzOk();final String gp="/storage/emulated/0/" + safWant().substring(8)+ "/";cDone=false;cErr=false;cp[0]=0f;
		hd.postDelayed(new Runnable(){public void run(){if(!cDone)cShow();}},450);
		new Thread(new Runnable(){public void run(){
				final int n=L.size();
				for(int i=0;i < n;i++){final int k=i;final String r=L.get(i);
					hd.post(new Runnable(){public void run(){cStep(k,n,r,false);}});
					try{if(shz)shzRm(gp + r);else safRm(r);}catch(Throwable e){cErr=true;}
					hd.post(new Runnable(){public void run(){cStep(k,n,r,true);}});}
				hd.post(new Runnable(){public void run(){cDone=true;cEnd();}});
			}}).start();
	}
	void start(){
		LG.onNew=new Runnable(){public void run(){relang();}};
		initSaf();sp.edit().putString("gamePath","/storage/emulated/0/" + safWant().substring(8)+ "/").apply();hideBar();act.getWindow().setStatusBarColor(cBg);act.getWindow().setNavigationBarColor(cBg);act.getWindow().setSoftInputMode(16);
		if(android.os.Build.VERSION.SDK_INT >=23){int f=0x2000;if(android.os.Build.VERSION.SDK_INT >=26)f|=0x10;act.getWindow().getDecorView().setSystemUiVisibility(f);}
		root.setBackgroundColor(cBg);
		root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){public android.view.WindowInsets onApplyWindowInsets(View v,android.view.WindowInsets i){v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;}});
		android.widget.LinearLayout r=lin(true);headBox=lin(false);headBox.setPadding(dp(20),dp(16),dp(20),dp(10));r.addView(headBox,lp(-1,-2));sliderHost=lin(true);sliderHost.setPadding(dp(20),dp(4),dp(20),0);sliderHost.setVisibility(8);r.addView(sliderHost,lp(-1,-2));
		sv=new android.widget.ScrollView(act);sv.setVerticalScrollBarEnabled(false);bodyBox=lin(true);bodyBox.setPadding(dp(20),dp(4),dp(20),dp(130));sv.addView(bodyBox);sv.getViewTreeObserver().addOnScrollChangedListener(new android.view.ViewTreeObserver.OnScrollChangedListener(){public void onScrollChanged(){updVids();}});r.addView(sv,new android.widget.LinearLayout.LayoutParams(-1,0,1f));
		chatBox=lin(false);chatBox.setGravity(16);chatBox.setPadding(dp(14),dp(8),dp(14),dp(10));chatBox.setVisibility(8);chatEt=edit("Type your message...");chatEt.setSingleLine(false);chatEt.setMaxLines(4);chatEt.setInputType(1|16384|131072);chatBox.addView(chatEt,lw(1f,0,0,10,0));
		android.widget.FrameLayout sendB=new android.widget.FrameLayout(act);sendB.setBackground(bg(cInk,24,0,0));sendB.addView(ic(16,22,0xFFFFFFFF),new android.widget.FrameLayout.LayoutParams(dp(22),dp(22),17));sendB.setOnClickListener(ck(new Runnable(){public void run(){sendSupport();}}));chatBox.addView(sendB,lp(dp(48),dp(48)));
		r.addView(chatBox,lp(-1,-2));root.addView(r,new android.widget.FrameLayout.LayoutParams(-1,-1));
		navBox=new android.widget.FrameLayout(act);android.widget.FrameLayout.LayoutParams nl=new android.widget.FrameLayout.LayoutParams(-1,-2,80);nl.setMargins(dp(16),0,dp(16),dp(14));root.addView(navBox,nl);
		lockBox=new android.widget.FrameLayout(act);lockBox.setVisibility(8);lockBox.setClickable(true);root.addView(lockBox,new android.widget.FrameLayout.LayoutParams(-1,-1));
		root.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener(){public void onGlobalLayout(){android.graphics.Rect fr=new android.graphics.Rect();root.getWindowVisibleDisplayFrame(fr);int diff=root.getRootView().getHeight()- fr.bottom;kbOpen=diff > dp(160);navVis();updVids();pressAll(root);}});
		act.setContentView(root);root.requestApplyInsets();root.getViewTreeObserver().addOnWindowFocusChangeListener(new android.view.ViewTreeObserver.OnWindowFocusChangeListener(){public void onWindowFocusChanged(boolean f){if(f)updVids();else for(Vid v:vids)v.play(false);}});
		if(dev==null||dev.trim().length()==0){toast("Device id not available");return;}
		startAt0=System.currentTimeMillis();java.util.HashMap<String,Object> u=new java.util.HashMap<String,Object>();
		u.put("device",dev);u.put("model",android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);u.put("androidVer",android.os.Build.VERSION.RELEASE);u.put("appVer",APP_VER);u.put("root",rooted());u.put("shizuku",shizuku());u.put("ram",ramTxt());u.put("lastSeen",com.google.firebase.database.ServerValue.TIMESTAMP);
		db.child("users").child(dev).updateChildren(u);renderHead();renderBody();renderNav();
		com.google.firebase.database.FirebaseDatabase.getInstance().getReference(".info/serverTimeOffset").addValueEventListener(new VL(0));
		db.child("config").addValueEventListener(new VL(1));db.child("slides").addValueEventListener(new VL(2));db.child("menus").addValueEventListener(new VL(3));db.child("users").child(dev).addValueEventListener(new VL(4));db.child("events").limitToLast(50).addValueEventListener(new VL(5));
		db.child("notifs").limitToLast(60).addValueEventListener(new VL(6));db.child("ulikes").child(dev).addValueEventListener(new VL(7));db.child("support").child(dev).addValueEventListener(new VL(8));db.child("prem").addValueEventListener(new VL(9));db.child("orders").child(dev).addValueEventListener(new VL(10));db.child("faq").addValueEventListener(new VL(11));
		showPerm();cleanup();tick();trimCache();
	}
	long startAt0;
}
new DV().start();
