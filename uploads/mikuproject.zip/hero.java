final android.app.Activity act = this;
final float dens = act.getResources().getDisplayMetrics().density;
final String KEY = "hero";
final String DEF_HEAD = "1 HERO";
final String DEF_HINT = "Search by title";
final long NEW_DAYS = 3;
final int[][] PAL = {
	{0xFFF6F7FA, 0xFFFFFFFF, 0xFF2A2F36, 0xFF8A919B, 0xFFD5DAE2, 0xFF3A424C, 0xFFFFFFFF, 0xFFE3E7EE},
	{0xFFF3F6FD, 0xFFFFFFFF, 0xFF1E2A44, 0xFF7B8AA8, 0xFFCAD6F0, 0xFF2563EB, 0xFFFFFFFF, 0xFFE0E8FA},
	{0xFFF2F9F6, 0xFFFFFFFF, 0xFF1D3329, 0xFF78948A, 0xFFC4E1D4, 0xFF059669, 0xFFFFFFFF, 0xFFDDF0E8},
	{0xFFF6F3FD, 0xFFFFFFFF, 0xFF2B2145, 0xFF8A7FAB, 0xFFD6C8F2, 0xFF7C3AED, 0xFFFFFFFF, 0xFFE8DEFA},
	{0xFFFDF3F5, 0xFFFFFFFF, 0xFF45212B, 0xFFAB7F89, 0xFFF0C6D0, 0xFFE11D48, 0xFFFFFFFF, 0xFFFADDE3},
	{0xFFFDF8F0, 0xFFFFFFFF, 0xFF45331D, 0xFFAB9578, 0xFFF0DAB6, 0xFFD97706, 0xFFFFFFFF, 0xFFFAEBD2},
	{0xFF12151A, 0xFF1C2028, 0xFFF1F3F6, 0xFF8F98A5, 0xFF2B313B, 0xFFF1F3F6, 0xFF12151A, 0xFF262C36},
	{0xFFFFF5F0, 0xFFFFFFFF, 0xFF4A2418, 0xFFB08573, 0xFFF0C4AE, 0xFFEA580C, 0xFFFFFFFF, 0xFFFADBCB},
	{0xFFF0F9FA, 0xFFFFFFFF, 0xFF15363B, 0xFF6E9399, 0xFFB1D8DD, 0xFF0D9488, 0xFFFFFFFF, 0xFFCDE9ED},
	{0xFFF3F4FD, 0xFFFFFFFF, 0xFF1F2347, 0xFF7E84AD, 0xFFC0C5EE, 0xFF4F46E5, 0xFFFFFFFF, 0xFFDADDF8},
	{0xFFF8F4F0, 0xFFFFFFFF, 0xFF3A2A20, 0xFF9A8676, 0xFFD6C5B5, 0xFF8B5E3C, 0xFFFFFFFF, 0xFFEADFD4},
	{0xFF0A1020, 0xFF131B30, 0xFFE8EEFF, 0xFF8090B8, 0xFF25304D, 0xFF60A5FA, 0xFF0A1020, 0xFF1B2540},
	{0xFF0C1511, 0xFF14211B, 0xFFE6F2EC, 0xFF7F9A8C, 0xFF22352C, 0xFF34D399, 0xFF0C1511, 0xFF1B2C24}
};
class Lg {
	final android.content.SharedPreferences sp = act.getSharedPreferences("dv", 0);
	final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());
	final java.util.concurrent.ConcurrentHashMap<String, String> mem = new java.util.concurrent.ConcurrentHashMap<String, String>();
	final java.util.Set<String> pend = java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String, Boolean>());
	final java.util.LinkedList<String> q = new java.util.LinkedList<String>();
	final java.util.regex.Pattern NUM = java.util.regex.Pattern.compile("[0-9]+");
	String code = sp.getString("lang", "en"); int nw; long failAt, lastFire; Runnable onNew;
	final Runnable fire = new Runnable() { public void run() { lastFire = System.currentTimeMillis(); if (onNew != null) onNew.run(); } };
	void set(String c) {
		c = c == null ? "" : c.trim(); if (c.length() == 0 || c.equals("null")) c = "en"; if (c.equals(code)) return;
		code = c; mem.clear(); pend.clear(); synchronized (q) { q.clear(); } failAt = 0; sp.edit().putString("lang", c).apply(); hd.removeCallbacks(fire); hd.post(fire);
	}
	String h(String k) { long v = 1125899906842597L; for (int i = 0; i < k.length(); i++) v = 31 * v + k.charAt(i); return Long.toHexString(v); }
	String gc(String c) { if (c.equals("zh")) return "zh-CN"; if (c.equals("he")) return "iw"; return c; }
	boolean skip(String t) {
		if (t.length() < 2 || t.length() > 300) return true;
		if (t.indexOf("://") >= 0 || t.indexOf('@') >= 0 || t.charAt(0) == '/') return true;
		if (t.indexOf(' ') < 0 && t.length() > 14) return true;
		for (int i = 0; i < t.length(); i++) if (Character.isLetter(t.charAt(i))) return false;
		return true;
	}
	String tr(String s) {
		if (s == null || code.equals("en")) return s;
		String t = s.trim(); if (skip(t)) return s;
		java.util.ArrayList<String> nums = new java.util.ArrayList<String>(); java.util.regex.Matcher m = NUM.matcher(t); StringBuffer sb = new StringBuffer();
		while (m.find()) { nums.add(m.group()); m.appendReplacement(sb, "\u00a7"); } m.appendTail(sb); String k = sb.toString();
		String hit = mem.get(k); if (hit == null) { hit = sp.getString("tr_" + code + "_" + h(k), null); if (hit != null) mem.put(k, hit); }
		if (hit == null) { ask(k); return s; }
		int c = 0; StringBuilder o = new StringBuilder();
		for (int i = 0; i < hit.length(); i++) { char ch = hit.charAt(i); if (ch == '\u00a7') { if (c >= nums.size()) return s; o.append(nums.get(c++)); } else o.append(ch); }
		if (c != nums.size()) return s;
		int a = 0; while (a < s.length() && Character.isWhitespace(s.charAt(a))) a++; int b = s.length(); while (b > a && Character.isWhitespace(s.charAt(b - 1))) b--;
		return s.substring(0, a) + o + s.substring(b);
	}
	void ask(String k) {
		if (System.currentTimeMillis() - failAt < 20000 || pend.size() > 600 || !pend.add(k)) return;
		synchronized (q) { q.add(k); if (nw < 4) { nw++; new Thread(worker).start(); } }
	}
	final Runnable worker = new Runnable() { public void run() {
			while (true) {
				String k; final String lc;
				synchronized (q) { if (q.isEmpty()) { nw--; return; } k = q.removeFirst(); lc = code; }
				String r = fetch(lc, k);
				if (r == null || r.trim().length() == 0) { failAt = System.currentTimeMillis(); pend.clear(); synchronized (q) { q.clear(); nw--; } return; }
				if (lc.equals(code)) {
					sp.edit().putString("tr_" + lc + "_" + h(k), r).apply(); mem.put(k, r);
					boolean empty; synchronized (q) { empty = q.isEmpty(); } long gap = System.currentTimeMillis() - lastFire;
					hd.removeCallbacks(fire); hd.postDelayed(fire, empty ? 250 : (gap > 2500 ? 0 : 2500 - gap));
				}
				pend.remove(k);
			}
		} };
	String err = ""; long errAt;
	String get(String u) throws Exception {
		java.net.HttpURLConnection cn = (java.net.HttpURLConnection) new java.net.URL(u).openConnection(); cn.setConnectTimeout(8000); cn.setReadTimeout(8000); cn.setRequestProperty("User-Agent", "Mozilla/5.0");
		try { int rc = cn.getResponseCode(); if (rc != 200) { err = "HTTP " + rc; return null; }
			java.io.InputStream in = cn.getInputStream(); java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) bo.write(b, 0, n); in.close(); return bo.toString("UTF-8");
		} finally { cn.disconnect(); }
	}
	String fetch(String lc, String text) {
		String q; try { q = java.net.URLEncoder.encode(text, "UTF-8"); } catch (Exception e) { return null; }
		try { String body = get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=" + gc(lc) + "&dt=t&q=" + q);
			if (body != null) { org.json.JSONArray a = new org.json.JSONArray(body).getJSONArray(0); StringBuilder sb = new StringBuilder(); for (int i = 0; i < a.length(); i++) { org.json.JSONArray p = a.optJSONArray(i); if (p != null) sb.append(p.optString(0, "")); } if (sb.length() > 0) return sb.toString(); }
		} catch (Throwable e) { err = String.valueOf(e); }
		try { String body = get("https://api.mymemory.translated.net/get?q=" + q + "&langpair=en%7C" + gc(lc));
			if (body != null) { org.json.JSONObject o = new org.json.JSONObject(body); String r = o.getJSONObject("responseData").optString("translatedText", ""); if (o.optInt("responseStatus", 200) == 200 && r.length() > 0) return r; err = "MyMemory " + o.optString("responseStatus") + " " + o.optString("responseDetails"); }
		} catch (Throwable e) { err = String.valueOf(e); }
		if (System.currentTimeMillis() - errAt > 60000) { errAt = System.currentTimeMillis(); final String m = err; hd.post(new Runnable() { public void run() { android.widget.Toast.makeText(act.getApplicationContext(), "Translation failed: " + m, 1).show(); } }); }
		return null;
	}
}
final Lg LG = new Lg();
class CT {
	final android.content.SharedPreferences sp = act.getSharedPreferences("dv", 0);
	final com.google.firebase.database.DatabaseReference db = com.google.firebase.database.FirebaseDatabase.getInstance().getReference("dv");
	final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());
	final boolean prem = act.getIntent().getBooleanExtra("premium", false);
	com.google.firebase.database.DataSnapshot gcfg;
	final String dev = act.getIntent().getStringExtra("device") != null ? act.getIntent().getStringExtra("device") : String.valueOf(android.provider.Settings.Secure.getString(act.getContentResolver(), "android_id"));
	class TT extends TextView {
		TT() { super(act); }
		public void setText(CharSequence t, android.widget.TextView.BufferType b) { super.setText(t instanceof String ? LG.tr((String) t) : t, b); }
	}
	class ET extends EditText {
		ET() { super(act); }
	}
	final java.util.HashMap<String, android.graphics.Bitmap> imgs = new java.util.HashMap<String, android.graphics.Bitmap>();
	final android.widget.FrameLayout root = new android.widget.FrameLayout(act);
	int[] P = PAL[0]; int palIdx = 0, flt = 0, lastP = -1; String head = DEF_HEAD, hint = DEF_HINT, q = "", lastS = ""; boolean busy;
	com.google.firebase.database.DataSnapshot items;
	android.widget.LinearLayout listBox; TextView hTv; EditText sEt; TextView[] ch = new TextView[4]; TextView helpB; com.google.firebase.database.DataSnapshot cfgS;
	android.app.Dialog pdlg; ProgressBar pBar; TextView tSt, tPc;
	int dp(int v) { return (int) (v * dens + 0.5f); }
	void toast(String t) { android.widget.Toast.makeText(act.getApplicationContext(), LG.tr(t), 0).show(); }
	String s(com.google.firebase.database.DataSnapshot d, String k) { if (d == null) return ""; Object o = d.child(k).getValue(); return o == null ? "" : String.valueOf(o); }
	double n(com.google.firebase.database.DataSnapshot d, String k) { try { return Double.parseDouble(s(d, k)); } catch (Exception e) { return 0; } }
	android.graphics.drawable.GradientDrawable bg(int c, int r, int st, int sw) { android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); if (sw > 0) g.setStroke(dp(sw), st); return g; }
	TextView tv(String t, int sz, int col, boolean bold) { TextView x = new TT(); x.setText(t); x.setTextSize(sz); x.setTextColor(col); if (bold) x.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); return x; }
	android.widget.LinearLayout lin(boolean v) { android.widget.LinearLayout l = new android.widget.LinearLayout(act); l.setOrientation(v ? 1 : 0); return l; }
	android.widget.LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) { android.widget.LinearLayout.LayoutParams p = new android.widget.LinearLayout.LayoutParams(w, h); p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p; }
	String ikey(com.google.firebase.database.DataSnapshot x) { return "i_" + KEY + "_" + x.getKey(); }
	String fkey(com.google.firebase.database.DataSnapshot x) { return "f_" + KEY + "_" + x.getKey(); }
	String ver(com.google.firebase.database.DataSnapshot x) { String v = s(x, "ver").trim(); return v.length() > 0 ? v : s(x, "link").trim(); }
	boolean fav(com.google.firebase.database.DataSnapshot x) { return sp.getBoolean(fkey(x), false); }
	boolean isNew(com.google.firebase.database.DataSnapshot x) { long t = (long) n(x, "time"); return t > 0 && System.currentTimeMillis() - t < NEW_DAYS * 86400000L; }
	String cnt(long v) { if (v >= 1000000L) return String.format(java.util.Locale.US, "%.1fM", v / 1000000.0); if (v >= 1000L) return String.format(java.util.Locale.US, "%.1fK", v / 1000.0); return String.valueOf(v); }
	TextView badge(String t, int fg, int bgc) { TextView b = tv(t, 10, fg, true); b.setPadding(dp(9), dp(5), dp(9), dp(5)); b.setBackground(bg(bgc, 10, 0, 0)); return b; }
	void bump(com.google.firebase.database.DatabaseReference r) {
		r.runTransaction(new com.google.firebase.database.Transaction.Handler() {
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m) { Object o = m.getValue(); long v = o instanceof Number ? ((Number) o).longValue() : 0L; m.setValue(v + 1L); return com.google.firebase.database.Transaction.success(m); }
			public void onComplete(com.google.firebase.database.DatabaseError e, boolean ok, com.google.firebase.database.DataSnapshot d) {}
		});
	}
	void markDev(final String id) {
		db.child("cat").child(KEY).child(id).runTransaction(new com.google.firebase.database.Transaction.Handler() {
			public com.google.firebase.database.Transaction.Result doTransaction(com.google.firebase.database.MutableData m) {
				if (m.getValue() == null || m.child("devs").hasChild(dev)) return com.google.firebase.database.Transaction.success(m);
				m.child("devs").child(dev).setValue(true); Object o = m.child("dlUsers").getValue(); long v = o instanceof Number ? ((Number) o).longValue() : 0L; m.child("dlUsers").setValue(v + 1L); return com.google.firebase.database.Transaction.success(m);
			}
			public void onComplete(com.google.firebase.database.DatabaseError e, boolean ok, com.google.firebase.database.DataSnapshot d) {}
		});
	}
	void confirmDlg(String icon, String title, String msg, String okT, final Runnable onOk) { confirmDlgX(icon, null, title, msg, okT, onOk, true); }
	void confirmDlgX(String icon, android.graphics.drawable.Drawable dr, String title, String msg, String okT, final Runnable onOk, boolean cancel) {
		if (act.isFinishing()) return;
		final android.app.Dialog dd = new android.app.Dialog(act); dd.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
		android.widget.LinearLayout r = lin(true); r.setGravity(1); r.setPadding(dp(24), dp(26), dp(24), dp(20)); r.setBackground(bg(P[1], 28, P[4], 1));
		if (dr != null) { ImageView gi = new ImageView(act); gi.setImageDrawable(dr); gi.setScaleType(ImageView.ScaleType.FIT_CENTER); r.addView(gi, lp(dp(68), dp(68), 0, 0, 0, 0)); }
		else { TextView ic = tv(icon, 26, P[6], true); ic.setGravity(17); ic.setBackground(bg(P[5], 28, 0, 0)); r.addView(ic, lp(dp(56), dp(56), 0, 0, 0, 0)); }
		TextView t = tv(title, 20, P[2], true); t.setGravity(17); r.addView(t, lp(-1, -2, 0, 16, 0, 0));
		TextView m = tv(msg, 14, P[3], false); m.setGravity(17); m.setLineSpacing(0, 1.15f); r.addView(m, lp(-1, -2, 4, 8, 4, 0));
		android.widget.LinearLayout row = lin(false);
		if (cancel) { TextView cn = tv("CANCEL", 13, P[3], true); cn.setGravity(17); cn.setPadding(dp(16), dp(13), dp(16), dp(13)); cn.setBackground(bg(P[7], 14, P[4], 1)); cn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dd.dismiss(); } });
			android.widget.LinearLayout.LayoutParams p1 = new android.widget.LinearLayout.LayoutParams(0, -2, 1f); p1.setMargins(0, 0, dp(8), 0); row.addView(cn, p1); }
		TextView ok = tv(okT, 13, P[6], true); ok.setGravity(17); ok.setPadding(dp(16), dp(13), dp(16), dp(13)); ok.setBackground(bg(P[5], 14, 0, 0)); ok.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dd.dismiss(); onOk.run(); } });
		row.addView(ok, new android.widget.LinearLayout.LayoutParams(0, -2, 1f)); r.addView(row, lp(-1, -2, 0, 22, 0, 0));
		dd.setContentView(r); dd.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0)); dd.getWindow().setDimAmount(0.6f); dd.show(); dd.getWindow().setLayout((int) (act.getResources().getDisplayMetrics().widthPixels * 0.88f), -2);
	}
	String gs(String k, String d) { return gcfg != null && gcfg.hasChild(k) && String.valueOf(gcfg.child(k).getValue()).trim().length() > 0 ? String.valueOf(gcfg.child(k).getValue()).trim() : d; }
	void askOpen() {
		if ("false".equals(gs("openAsk", "true"))) return; final String pkg = gs("gamePkg", "com.mobile.legends"); final android.content.pm.PackageManager pm = act.getPackageManager();
		CharSequence lbl = ""; android.graphics.drawable.Drawable icn = null; boolean inst = false;
		try { android.content.pm.ApplicationInfo ai = pm.getApplicationInfo(pkg, 0); inst = true; lbl = pm.getApplicationLabel(ai); icn = pm.getApplicationIcon(ai); } catch (Throwable e) {}
		if (!inst) { confirmDlgX("!", null, "Game not installed", "The game (" + pkg + ") is not installed on this phone.", "OK", new Runnable() { public void run() {} }, false); return; }
		confirmDlgX("\u25B6", icn, "Open game?", lbl + " is ready. Do you want to open it now?", "OPEN", new Runnable() { public void run() { try { android.content.Intent li = pm.getLaunchIntentForPackage(pkg); if (li == null) { toast("Cannot open the game"); return; } li.addFlags(268435456); act.startActivity(li); } catch (Throwable e) { toast("Cannot open the game"); } } }, true);
	}
	void helpDlg() {
		final String vu = s(cfgS, "tutVideo").trim(), st = s(cfgS, "tutSteps").trim();
		final android.app.Dialog dd = new android.app.Dialog(act); dd.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
		android.widget.LinearLayout r = lin(true); r.setPadding(dp(22), dp(22), dp(22), dp(22)); r.setBackground(bg(P[1], 28, P[4], 1));
		r.addView(tv("HOW TO USE", 20, P[2], true));
		if (st.length() > 0) { int k = 0; for (String z : st.split("\\||\\n")) { z = z.trim(); if (z.length() == 0) continue; k++;
				android.widget.LinearLayout row = lin(false); TextView nb = tv(String.valueOf(k), 12, P[6], true); nb.setGravity(17); nb.setBackground(bg(P[5], 12, 0, 0)); row.addView(nb, lp(dp(24), dp(24), 0, 0, 12, 0));
				row.addView(tv(z, 14, P[2], false), new android.widget.LinearLayout.LayoutParams(0, -2, 1f)); r.addView(row, lp(-1, -2, 0, 14, 0, 0)); } }
		if (vu.length() > 0) { TextView vb = tv("\u25B6  WATCH VIDEO", 13, P[6], true); vb.setGravity(17); vb.setPadding(dp(16), dp(13), dp(16), dp(13)); vb.setBackground(bg(P[5], 14, 0, 0));
			vb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dd.dismiss(); playTut(vu); } }); r.addView(vb, lp(-1, -2, 0, 18, 0, 0)); }
		TextView cl = tv("CLOSE", 13, P[3], true); cl.setGravity(17); cl.setPadding(dp(16), dp(12), dp(16), dp(12)); cl.setBackground(bg(P[7], 14, P[4], 1)); cl.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { dd.dismiss(); } }); r.addView(cl, lp(-1, -2, 0, 10, 0, 0));
		dd.setContentView(r); dd.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0)); dd.show(); dd.getWindow().setLayout((int) (act.getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
	}
	void playTut(String u) {
		if (!isVid(u)) { try { act.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(u))); } catch (Throwable e) { toast("Cannot open link"); } return; }
		final android.app.Dialog vd = new android.app.Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
		android.widget.FrameLayout fl = new android.widget.FrameLayout(act); fl.setBackgroundColor(0xFF000000); final android.widget.VideoView vv = new android.widget.VideoView(act); fl.addView(vv, new android.widget.FrameLayout.LayoutParams(-1, -1, 17));
		android.widget.MediaController mc = new android.widget.MediaController(act); mc.setAnchorView(vv); vv.setMediaController(mc);
		java.io.File cf = cfile(u, ".vid"); if (cf.exists() && cf.length() > 0) vv.setVideoPath(cf.getPath()); else vv.setVideoURI(android.net.Uri.parse(u));
		vv.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() { public void onPrepared(android.media.MediaPlayer p) { vv.start(); } });
		vv.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() { public boolean onError(android.media.MediaPlayer p, int a, int b) { toast("Video failed to load"); vd.dismiss(); return true; } });
		TextView x = tv("\u2715", 20, 0xFFFFFFFF, true); x.setPadding(dp(16), dp(12), dp(16), dp(12)); x.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { vd.dismiss(); } });
		fl.addView(x, new android.widget.FrameLayout.LayoutParams(-2, -2, 53));
		vd.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() { public void onDismiss(android.content.DialogInterface d) { try { vv.stopPlayback(); } catch (Throwable e) {} } });
		vd.setContentView(fl); vd.show();
	}
	boolean safOk() {
		try { String sv = sp.getString("safUri", ""); if (sv.length() == 0) return false;
			for (android.content.UriPermission p : act.getContentResolver().getPersistedUriPermissions()) if (p.getUri().toString().equals(sv) && p.isWritePermission()) return true;
		} catch (Throwable e) {} return false;
	}
	boolean shzOk() { try { Class<?> c = Class.forName("rikka.shizuku.Shizuku"); return ((Boolean) c.getMethod("pingBinder").invoke(null)) && ((Integer) c.getMethod("checkSelfPermission").invoke(null)) == 0; } catch (Throwable e) { return false; } }
	int mode() { return safOk() ? 1 : (shzOk() ? 2 : 0); }
	final long CACHE_MAX = 200L * 1024 * 1024, VID_MAX = 40L * 1024 * 1024;
	java.io.File cdir() { java.io.File d = new java.io.File(act.getCacheDir(), "dvc"); if (!d.exists()) d.mkdirs(); return d; }
	java.io.File cfile(String url, String ext) { return new java.io.File(cdir(), Integer.toHexString(url.hashCode()) + "_" + url.length() + ext); }
	void trimCache() {
		new Thread(new Runnable() { public void run() { try {
					java.io.File[] fs = cdir().listFiles(); if (fs == null) return; long tot = 0; for (java.io.File f : fs) tot += f.length(); if (tot <= CACHE_MAX) return;
					java.util.Arrays.sort(fs, new java.util.Comparator<java.io.File>() { public int compare(java.io.File p, java.io.File q2) { return Long.compare(p.lastModified(), q2.lastModified()); } });
					for (java.io.File f : fs) { if (tot <= CACHE_MAX * 3 / 4) break; tot -= f.length(); f.delete(); }
				} catch (Throwable e) {} } }).start();
	}
	boolean fetchTo(String url, java.io.File out, long cap) {
		java.io.File tmp = new java.io.File(out.getPath() + ".tmp"); java.net.HttpURLConnection cn = null; java.io.InputStream in = null; java.io.OutputStream o = null; boolean ok = false;
		try {
			cn = (java.net.HttpURLConnection) new java.net.URL(url).openConnection(); cn.setConnectTimeout(10000); cn.setReadTimeout(20000); int len = cn.getContentLength(); if (cap > 0 && len > cap) return false;
			in = cn.getInputStream(); o = new java.io.FileOutputStream(tmp); byte[] b = new byte[16384]; int r; long sum = 0;
			while ((r = in.read(b)) != -1) { o.write(b, 0, r); sum += r; if (cap > 0 && sum > cap) throw new java.io.IOException("too big"); }
			o.close(); o = null; ok = tmp.renameTo(out);
		} catch (Throwable e) { ok = false; }
		finally { try { if (o != null) o.close(); } catch (Throwable e) {} try { if (in != null) in.close(); } catch (Throwable e) {} try { if (cn != null) cn.disconnect(); } catch (Throwable e) {} if (tmp.exists()) tmp.delete(); }
		return ok;
	}
	void loadImg(final ImageView iv, final String url) {
		android.graphics.Bitmap c = imgs.get(url); if (c != null) { iv.setImageBitmap(c); return; }
		new Thread(new Runnable() { public void run() { try {
					java.io.File cf = cfile(url, ".img"); if (!cf.exists() || cf.length() == 0) fetchTo(url, cf, 20L * 1024 * 1024); if (!cf.exists()) return; cf.setLastModified(System.currentTimeMillis());
					android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options(); o.inJustDecodeBounds = true; android.graphics.BitmapFactory.decodeFile(cf.getPath(), o);
					int sm = 1; while (o.outWidth / (sm * 2) >= 1000) sm *= 2; o = new android.graphics.BitmapFactory.Options(); o.inSampleSize = sm;
					final android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeFile(cf.getPath(), o); if (bm == null) { cf.delete(); return; }
					hd.post(new Runnable() { public void run() { imgs.put(url, bm); iv.setImageBitmap(bm); } });
				} catch (Throwable e) {} } }).start();
	}
	final java.util.ArrayList<Vid> vids = new java.util.ArrayList<Vid>();
	final Runnable rr = new Runnable() { public void run() { render(); } };
	final Runnable upd = new Runnable() { public void run() { updVids(); } };
	boolean isVid(String u) { String l = u.toLowerCase(); int q2 = l.indexOf('?'); if (q2 > 0) l = l.substring(0, q2); return l.endsWith(".mp4") || l.endsWith(".webm") || l.endsWith(".m4v") || l.endsWith(".3gp") || l.endsWith(".mkv") || l.endsWith(".m3u8"); }
	void updVids() { android.graphics.Rect r = new android.graphics.Rect(); for (Vid v : vids) { boolean vis = v.tx.isShown() && v.tx.getGlobalVisibleRect(r) && r.height() > dp(50); v.play(vis); } }
	class Vid implements android.view.TextureView.SurfaceTextureListener {
		final String url; final android.view.TextureView tx; android.media.MediaPlayer mp; boolean ready, want; int vw, vh;
		Vid(String u) { url = u; tx = new android.view.TextureView(act); tx.setAlpha(0f); tx.setSurfaceTextureListener(this); }
		void fit() { if (vw <= 0 || vh <= 0 || tx.getWidth() <= 0) return; float W = tx.getWidth(), H = tx.getHeight(), sc = Math.max(W / vw, H / vh); android.graphics.Matrix m = new android.graphics.Matrix(); m.setScale(vw * sc / W, vh * sc / H, W / 2f, H / 2f); tx.setTransform(m); }
		public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st, int w, int h) {
			try { mp = new android.media.MediaPlayer(); mp.setSurface(new android.view.Surface(st)); mp.setVolume(0f, 0f); mp.setLooping(true);
				mp.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() { public void onPrepared(android.media.MediaPlayer p) { ready = true; vw = p.getVideoWidth(); vh = p.getVideoHeight(); fit(); tx.animate().alpha(1f).setDuration(250).start(); hd.post(upd); } });
				mp.setOnVideoSizeChangedListener(new android.media.MediaPlayer.OnVideoSizeChangedListener() { public void onVideoSizeChanged(android.media.MediaPlayer p, int w2, int h2) { vw = w2; vh = h2; fit(); } });
				mp.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() { public boolean onError(android.media.MediaPlayer p, int a, int b) { ready = false; tx.setVisibility(8); return true; } });
				src();
			} catch (Throwable e) { tx.setVisibility(8); }
		}
		void src() {
			final android.media.MediaPlayer mine = mp; final java.io.File cf = cfile(url, ".vid");
			if (url.toLowerCase().contains(".m3u8")) { try { mine.setDataSource(url); mine.prepareAsync(); } catch (Throwable e) { tx.setVisibility(8); } return; }
			if (cf.exists() && cf.length() > 0) { cf.setLastModified(System.currentTimeMillis()); try { mine.setDataSource(cf.getPath()); mine.prepareAsync(); } catch (Throwable e) { tx.setVisibility(8); } return; }
			new Thread(new Runnable() { public void run() {
					final boolean ok = fetchTo(url, cf, VID_MAX);
					hd.post(new Runnable() { public void run() { if (mp != mine) return; try { mine.setDataSource(ok ? cf.getPath() : url); mine.prepareAsync(); } catch (Throwable e) { tx.setVisibility(8); } } });
				} }).start();
		}
		public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st, int w, int h) { fit(); }
		public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st) { ready = false; try { if (mp != null) mp.release(); } catch (Throwable e) {} mp = null; return true; }
		public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st) {}
		void play(boolean on) { want = on; try { if (mp != null && ready) { if (on && !mp.isPlaying()) mp.start(); else if (!on && mp.isPlaying()) mp.pause(); } } catch (Throwable e) {} }
	}
	void paintChips() {
		for (int i = 0; i < 4; i++) { boolean on = flt == i; ch[i].setBackground(on ? bg(P[5], 12, 0, 0) : bg(P[7], 12, 0, 0)); ch[i].setTextColor(on ? P[6] : P[3]); }
	}
	void theme() {
		root.setBackgroundColor(P[0]); hTv.setText(head); hTv.setTextColor(P[2]); helpB.setTextColor(P[5]); helpB.setBackground(bg(P[7], 18, 0, 0));
		sEt.setHint(LG.tr(hint)); sEt.setHintTextColor(P[3]); sEt.setTextColor(P[2]); sEt.setBackground(bg(P[1], 16, P[4], 1));
		act.getWindow().setStatusBarColor(P[0]); act.getWindow().setNavigationBarColor(P[0]);
		int f = 0; if (palIdx != 6 && palIdx < 11) { if (android.os.Build.VERSION.SDK_INT >= 23) f |= 0x2000; if (android.os.Build.VERSION.SDK_INT >= 26) f |= 0x10; }
		act.getWindow().getDecorView().setSystemUiVisibility(f);
		paintChips(); render();
	}
	View card(final com.google.firebase.database.DataSnapshot x) {
		final boolean pr = "true".equals(s(x, "premium")), locked = pr && !prem; String im = s(x, "image").trim();
		final String ik = ikey(x); final boolean inst = sp.contains(ik), upd = inst && !sp.getString(ik, "").equals(ver(x)); final boolean full = false;
		android.widget.LinearLayout c = lin(true); c.setBackground(bg(P[1], 22, P[4], 1)); if (android.os.Build.VERSION.SDK_INT >= 21) c.setClipToOutline(true);
		android.widget.FrameLayout fl = new android.widget.FrameLayout(act); ImageView iv = new ImageView(act); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setBackgroundColor(P[7]);
		fl.addView(iv, new android.widget.FrameLayout.LayoutParams(-1, dp(168))); if (isVid(im)) { Vid vd = new Vid(im); vids.add(vd); fl.addView(vd.tx, new android.widget.FrameLayout.LayoutParams(-1, dp(168))); } else if (im.length() > 0) loadImg(iv, im);
		View sh = new View(act); sh.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, 0xCC000000}));
		fl.addView(sh, new android.widget.FrameLayout.LayoutParams(-1, dp(90), 80));
		TextView ti = tv(s(x, "title").toUpperCase(), 19, 0xFFFFFFFF, true); ti.setPadding(dp(16), 0, dp(16), dp(12)); ti.setMaxLines(2); fl.addView(ti, new android.widget.FrameLayout.LayoutParams(-1, -2, 80));
		TextView pl = tv(pr ? "PREMIUM" : "FREE", 10, pr ? 0xFF1A1A1A : 0xFFFFFFFF, true); pl.setPadding(dp(11), dp(5), dp(11), dp(5)); pl.setBackground(bg(pr ? 0xFFF59E0B : 0xFF1FA85A, 10, 0, 0));
		android.widget.FrameLayout.LayoutParams pp = new android.widget.FrameLayout.LayoutParams(-2, -2, 53); pp.setMargins(0, dp(12), dp(12), 0); fl.addView(pl, pp);
		final String fk = fkey(x); final TextView hb = tv(fav(x) ? "\u2665" : "\u2661", 16, fav(x) ? 0xFFFF5A6E : 0xFFFFFFFF, true); hb.setGravity(17); hb.setBackground(bg(0x66000000, 14, 0, 0)); hb.setPadding(dp(10), dp(4), dp(10), dp(4));
		hb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { boolean on = !sp.getBoolean(fk, false); sp.edit().putBoolean(fk, on).apply(); hb.setText(on ? "\u2665" : "\u2661"); hb.setTextColor(on ? 0xFFFF5A6E : 0xFFFFFFFF); if (flt == 3 && !on) render(); } });
		android.widget.LinearLayout tl = lin(false); tl.setGravity(16); tl.addView(hb, lp(-2, -2, 0, 0, 6, 0));
		if (upd) tl.addView(badge("UPDATE", 0xFF1A1A1A, 0xFFF59E0B), lp(-2, -2, 0, 0, 6, 0)); else if (inst) tl.addView(badge("\u2713 INSTALLED", 0xFFFFFFFF, 0xCC000000), lp(-2, -2, 0, 0, 6, 0)); else if (isNew(x)) tl.addView(badge("NEW", 0xFFFFFFFF, 0xFF3B82F6), lp(-2, -2, 0, 0, 6, 0));
		android.widget.FrameLayout.LayoutParams tp = new android.widget.FrameLayout.LayoutParams(-2, -2, 51); tp.setMargins(dp(12), dp(12), 0, 0); fl.addView(tl, tp);
		c.addView(fl, lp(-1, -2, 0, 0, 0, 0));
		android.widget.LinearLayout body = lin(true); body.setPadding(dp(16), dp(12), dp(16), dp(16));
		String ds = s(x, "desc"); if (ds.length() > 0) { TextView d = tv(ds, 13, P[3], false); d.setMaxLines(3); d.setEllipsize(android.text.TextUtils.TruncateAt.END); body.addView(d, lp(-1, -2, 0, 0, 0, 12)); }
		long dlc = (long) n(x, "dlCount"); if (dlc > 0 && "true".equals(s(cfgS, "showDl"))) body.addView(tv("\u2193 " + cnt(dlc) + " downloads", 11, P[3], false), lp(-1, -2, 0, 0, 0, 10));
		String bt = s(x, "btn").trim(); TextView b = tv(locked ? "PREMIUM ONLY" : (full ? "LIMIT REACHED" : (upd ? "UPDATE" : (inst ? "REINSTALL" : (bt.length() > 0 ? bt.toUpperCase() : "DOWNLOAD")))), 13, (locked || full) ? P[3] : P[6], true); b.setGravity(17); b.setPadding(dp(16), dp(13), dp(16), dp(13));
		b.setBackground((locked || full) ? bg(P[7], 14, P[4], 1) : bg(P[5], 14, 0, 0)); b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { get(x); } }); body.addView(b, lp(-1, -2, 0, 0, 0, 0));
		c.addView(body, lp(-1, -2, 0, 0, 0, 0)); return c;
	}
	void render() {
		if (listBox == null) return; vids.clear(); listBox.removeAllViews();
		java.util.ArrayList<com.google.firebase.database.DataSnapshot> l = new java.util.ArrayList<com.google.firebase.database.DataSnapshot>();
		if (items != null) for (com.google.firebase.database.DataSnapshot x : items.getChildren()) {
			if ("false".equals(s(x, "active"))) continue; boolean pr = "true".equals(s(x, "premium"));
			if (flt == 1 && pr) continue; if (flt == 2 && !pr) continue; if (flt == 3 && !fav(x)) continue; if (q.length() > 0 && !s(x, "title").toLowerCase().contains(q)) continue; l.add(x);
		}
		java.util.Collections.sort(l, new java.util.Comparator<com.google.firebase.database.DataSnapshot>() { public int compare(com.google.firebase.database.DataSnapshot a, com.google.firebase.database.DataSnapshot b) { return Double.compare(n(a, "order"), n(b, "order")); } });
		if (l.size() == 0) { listBox.addView(tv(items == null ? "Loading..." : "Nothing found", 14, P[3], false), lp(-2, -2, 4, 16, 0, 0)); return; }
		for (com.google.firebase.database.DataSnapshot x : l) listBox.addView(card(x), lp(-1, -2, 0, 0, 0, 14));
		listBox.post(upd);
	}
	void get(final com.google.firebase.database.DataSnapshot x) {
		if (busy) { toast("Another download is running"); return; }
		final String link = s(x, "link").trim(); if (link.length() == 0) { toast("No download link set for this item"); return; }
		if ("true".equals(s(x, "premium")) && !prem) { toast("Premium required. Buy premium from the home screen to unlock"); return; }
		if (mode() == 0) { toast("Storage permission not given. Open the home screen and grant it first"); return; }
		final String ik = ikey(x);
		if (sp.contains(ik) && sp.getString(ik, "").equals(ver(x))) { confirmDlg("\u2713", "Already installed", "This item is already installed on your game. Install it again?", "REINSTALL", new Runnable() { public void run() { go(link, x); } }); return; }
		go(link, x);
	}
	void go(final String link, final com.google.firebase.database.DataSnapshot x) {
		final String id = x.getKey(), ik = ikey(x), vr = ver(x); final boolean first = !sp.contains(ik), live = items != null && items.hasChild(id);
		busy = true; lastP = -1; lastS = ""; showProg();
		new Thread(new Runnable() { public void run() {
				java.io.File zip = null, ex = null; String err = null;
				try {
					String nm = "dv_" + System.currentTimeMillis();
					if (mode() == 1) {
						java.io.File base = act.getExternalCacheDir() != null ? act.getExternalCacheDir() : act.getCacheDir();
						zip = new java.io.File(base, nm + ".zip"); ex = new java.io.File(base, nm + "_x");
						download(link, zip, 0, 45); unzip(zip, ex, 45, 60); copySaf(ex);
					} else {
						zip = new java.io.File("/storage/emulated/0/Download/" + nm + ".zip");
						download(link, zip, 0, 75); shzInstall(zip);
					}
				} catch (Throwable e) { err = e.getMessage() == null ? e.toString() : e.getMessage(); }
				if (err == null) { sp.edit().putString(ik, vr).apply(); if (live) { bump(db.child("cat").child(KEY).child(id).child("dlCount")); markDev(id); } }
				prog(98, "Cleaning up...");
				try { if (zip != null) zip.delete(); if (ex != null) rm(ex); } catch (Throwable e) {}
				final String fe = err;
				hd.post(new Runnable() { public void run() { busy = false; closeProg(); toast(fe == null ? "Installed successfully" : "Failed: " + fe); if (fe == null) { render(); askOpen(); } } });
			} }).start();
	}
	void download(String link, java.io.File out, int from, int to) throws Exception {
		if (out.getParentFile() != null) out.getParentFile().mkdirs();
		String u = link; java.net.HttpURLConnection cn = null;
		for (int i = 0; i < 6; i++) {
			cn = (java.net.HttpURLConnection) new java.net.URL(u).openConnection(); cn.setConnectTimeout(15000); cn.setReadTimeout(30000); cn.setInstanceFollowRedirects(false);
			int rc = cn.getResponseCode();
			if (rc >= 300 && rc < 400) { String loc = cn.getHeaderField("Location"); cn.disconnect(); cn = null; if (loc == null) throw new java.io.IOException("Bad redirect"); u = new java.net.URL(new java.net.URL(u), loc).toString(); continue; }
			if (rc != 200) throw new java.io.IOException("Server error " + rc);
			break;
		}
		if (cn == null) throw new java.io.IOException("Too many redirects");
		int len = cn.getContentLength(); prog(from, "Downloading..."); java.io.InputStream in = cn.getInputStream(); java.io.OutputStream o = new java.io.FileOutputStream(out);
		try { byte[] b = new byte[16384]; int r; long sum = 0; while ((r = in.read(b)) != -1) { o.write(b, 0, r); sum += r; if (len > 0) prog(from + (int) (sum * (to - from) / len), "Downloading..."); } }
		finally { o.close(); in.close(); cn.disconnect(); }
	}
	void unzip(java.io.File zip, java.io.File dir, int from, int to) throws Exception {
		dir.mkdirs(); String rt = dir.getCanonicalPath() + java.io.File.separator; java.util.zip.ZipFile zf = new java.util.zip.ZipFile(zip);
		try { int cnt = Math.max(1, zf.size()), i = 0; java.util.Enumeration<? extends java.util.zip.ZipEntry> en = zf.entries();
			while (en.hasMoreElements()) { java.util.zip.ZipEntry e = en.nextElement(); java.io.File f = new java.io.File(dir, e.getName());
				if (!f.getCanonicalPath().startsWith(rt)) throw new java.io.IOException("Bad zip entry");
				if (e.isDirectory()) f.mkdirs(); else { f.getParentFile().mkdirs(); java.io.InputStream in = zf.getInputStream(e); java.io.OutputStream o = new java.io.FileOutputStream(f);
					try { byte[] b = new byte[16384]; int r; while ((r = in.read(b)) != -1) o.write(b, 0, r); } finally { o.close(); in.close(); } }
				prog(from + (++i) * (to - from) / cnt, "Extracting files..."); }
		} finally { zf.close(); }
	}
	void copySaf(java.io.File ex) throws Exception {
		android.net.Uri tree = android.net.Uri.parse(sp.getString("safUri", "")); long[] done = {0};
		copyTree(ex, tree, android.provider.DocumentsContract.getTreeDocumentId(tree), Math.max(1L, size(ex)), done);
	}
	java.util.HashMap<String, String[]> kids(android.net.Uri tree, String pid) {
		java.util.HashMap<String, String[]> m = new java.util.HashMap<String, String[]>(); android.database.Cursor c = null;
		try { c = act.getContentResolver().query(android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, pid), new String[]{"document_id", "_display_name", "mime_type"}, null, null, null);
			while (c != null && c.moveToNext()) m.put(c.getString(1), new String[]{c.getString(0), c.getString(2)}); } catch (Throwable e) {} finally { if (c != null) c.close(); }
		return m;
	}
	void copyTree(java.io.File src, android.net.Uri tree, String pid, long total, long[] done) throws Exception {
		android.content.ContentResolver cr = act.getContentResolver(); final String DIR = "vnd.android.document/directory";
		java.util.HashMap<String, String[]> have = kids(tree, pid); java.io.File[] fs = src.listFiles(); if (fs == null) return;
		android.net.Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, pid);
		for (java.io.File f : fs) {
			String[] hit = have.get(f.getName());
			if (f.isDirectory()) {
				String id;
				if (hit != null && DIR.equals(hit[1])) id = hit[0];
				else { if (hit != null) android.provider.DocumentsContract.deleteDocument(cr, android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, hit[0]));
					android.net.Uri nu = android.provider.DocumentsContract.createDocument(cr, parent, DIR, f.getName()); if (nu == null) throw new java.io.IOException("Cannot create folder " + f.getName()); id = android.provider.DocumentsContract.getDocumentId(nu); }
				copyTree(f, tree, id, total, done);
			} else {
				if (hit != null) android.provider.DocumentsContract.deleteDocument(cr, android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, hit[0]));
				android.net.Uri nu = android.provider.DocumentsContract.createDocument(cr, parent, "application/octet-stream", f.getName()); if (nu == null) throw new java.io.IOException("Cannot create file " + f.getName());
				java.io.InputStream in = new java.io.FileInputStream(f); java.io.OutputStream o = cr.openOutputStream(nu, "wt"); if (o == null) { in.close(); throw new java.io.IOException("Cannot write " + f.getName()); }
				try { byte[] b = new byte[16384]; int r; while ((r = in.read(b)) != -1) { o.write(b, 0, r); done[0] += r; prog(60 + (int) (done[0] * 38 / total), "Copying to game folder..."); } } finally { o.close(); in.close(); }
			}
		}
	}
	void shzInstall(java.io.File zip) throws Exception {
		String gp = sp.getString("gamePath", ""); if (gp.length() == 0) throw new java.io.IOException("Game path missing, open the home screen once");
		if (!gp.endsWith("/")) gp += "/";
		prog(80, "Extracting and copying...");
		ShizukuMaster cd = new ShizukuMaster();
		cd.masterpse(zip.getAbsolutePath(), gp);
		if (!cd.checkCommandExecution()) throw new java.io.IOException("Install failed");
		prog(95, "Cleaning up..."); cd.deleteShizuku(zip.getAbsolutePath());
	}
	long size(java.io.File f) { if (f.isFile()) return f.length(); long t = 0; java.io.File[] k = f.listFiles(); if (k != null) for (java.io.File x : k) t += size(x); return t; }
	void rm(java.io.File f) { java.io.File[] k = f.listFiles(); if (k != null) for (java.io.File x : k) rm(x); f.delete(); }
	void prog(final int p, final String st) {
		if (p == lastP && st.equals(lastS)) return; lastP = p; lastS = st;
		hd.post(new Runnable() { public void run() { if (pBar != null) pBar.setProgress(p); if (tPc != null) tPc.setText(p + "%"); if (tSt != null) tSt.setText(st); } });
	}
	void closeProg() { try { if (pdlg != null && pdlg.isShowing()) pdlg.dismiss(); } catch (Throwable e) {} pdlg = null; }
	void showProg() {
		pdlg = new android.app.Dialog(act); pdlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE); pdlg.setCancelable(false); pdlg.setCanceledOnTouchOutside(false);
		android.widget.LinearLayout r = lin(true); r.setPadding(dp(24), dp(24), dp(24), dp(24)); r.setBackground(bg(P[1], 28, P[4], 1));
		r.addView(tv("PLEASE WAIT", 22, P[2], true)); r.addView(tv("Downloading and installing. This can take a minute.", 14, P[3], false), lp(-1, -2, 0, 8, 0, 0));
		android.widget.LinearLayout row = lin(false); r.addView(row, lp(-1, -2, 0, 24, 0, 0));
		tSt = tv("Starting...", 13, P[3], false); row.addView(tSt, new android.widget.LinearLayout.LayoutParams(0, -2, 1f)); tPc = tv("0%", 13, P[2], true); row.addView(tPc, new android.widget.LinearLayout.LayoutParams(-2, -2));
		pBar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal); pBar.setMax(100); pBar.setProgress(0);
		android.graphics.drawable.ClipDrawable clip = new android.graphics.drawable.ClipDrawable(bg(P[5], 4, 0, 0), android.view.Gravity.LEFT, android.graphics.drawable.ClipDrawable.HORIZONTAL);
		android.graphics.drawable.LayerDrawable ly = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{bg(P[7], 4, 0, 0), clip}); ly.setId(0, android.R.id.background); ly.setId(1, android.R.id.progress); pBar.setProgressDrawable(ly);
		r.addView(pBar, lp(-1, dp(8), 0, 10, 0, 0));
		TextView ft = tv("Please wait, don't close the app", 12, P[3], false); ft.setGravity(17); r.addView(ft, lp(-1, -2, 0, 24, 0, 0));
		pdlg.setContentView(r); pdlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0)); pdlg.show(); pdlg.getWindow().setLayout((int) (act.getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
	}
	void start() {
		act.getWindow().setSoftInputMode(16);
		root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() { public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets i) { v.setPadding(i.getSystemWindowInsetLeft(), i.getSystemWindowInsetTop(), i.getSystemWindowInsetRight(), i.getSystemWindowInsetBottom()); return i; } });
		android.widget.LinearLayout r = lin(true);
		android.widget.LinearLayout hr = lin(false); hr.setGravity(16); hTv = tv(head, 22, P[2], true); hTv.setPadding(dp(20), dp(16), dp(8), dp(10)); hr.addView(hTv, new android.widget.LinearLayout.LayoutParams(0, -2, 1f));
		helpB = tv("?", 16, P[5], true); helpB.setGravity(17); helpB.setVisibility(8); helpB.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { helpDlg(); } }); hr.addView(helpB, lp(dp(36), dp(36), 0, 0, 16, 0)); r.addView(hr, lp(-1, -2, 0, 0, 0, 0));
		sEt = new ET(); sEt.setSingleLine(true); sEt.setTextSize(14); sEt.setPadding(dp(16), dp(12), dp(16), dp(12)); sEt.setInputType(1 | 16384);
		sEt.addTextChangedListener(new android.text.TextWatcher() { public void beforeTextChanged(CharSequence a, int b, int c, int d) {} public void onTextChanged(CharSequence a, int b, int c, int d) { q = a.toString().trim().toLowerCase(); hd.removeCallbacks(rr); hd.postDelayed(rr, 250); } public void afterTextChanged(android.text.Editable e) {} });
		r.addView(sEt, lp(-1, -2, 16, 0, 16, 10));
		android.widget.LinearLayout cr = lin(false); String[] cn = {"ALL", "FREE", "PREMIUM", "\u2665 SAVED"};
		for (int i = 0; i < 4; i++) { final int ix = i; ch[i] = tv(cn[i], 12, P[3], true); ch[i].setPadding(dp(13), dp(8), dp(13), dp(8)); ch[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { flt = ix; paintChips(); render(); } }); cr.addView(ch[i], lp(-2, -2, 0, 0, 8, 0)); }
		r.addView(cr, lp(-1, -2, 16, 0, 16, 10));
		android.widget.ScrollView sv = new android.widget.ScrollView(act); sv.setVerticalScrollBarEnabled(false); listBox = lin(true); listBox.setPadding(dp(16), dp(4), dp(16), dp(20)); sv.addView(listBox); sv.getViewTreeObserver().addOnScrollChangedListener(new android.view.ViewTreeObserver.OnScrollChangedListener() { public void onScrollChanged() { updVids(); } });
		r.addView(sv, new android.widget.LinearLayout.LayoutParams(-1, 0, 1f));
		root.addView(r, new android.widget.FrameLayout.LayoutParams(-1, -1)); act.setContentView(root); root.requestApplyInsets(); root.getViewTreeObserver().addOnWindowFocusChangeListener(new android.view.ViewTreeObserver.OnWindowFocusChangeListener() { public void onWindowFocusChanged(boolean f) { if (f) updVids(); else for (Vid v : vids) v.play(false); } }); theme();
		trimCache();
		LG.onNew = new Runnable() { public void run() { theme(); } };
		db.child("config").addValueEventListener(new com.google.firebase.database.ValueEventListener() {
			public void onDataChange(com.google.firebase.database.DataSnapshot d) { gcfg = d; }
			public void onCancelled(com.google.firebase.database.DatabaseError e) {} });
		db.child("config").child("lang").addValueEventListener(new com.google.firebase.database.ValueEventListener() {
			public void onDataChange(com.google.firebase.database.DataSnapshot d) { LG.set(d.getValue() == null ? "en" : String.valueOf(d.getValue())); }
			public void onCancelled(com.google.firebase.database.DatabaseError e) {} });
		db.child("catcfg").child(KEY).addValueEventListener(new com.google.firebase.database.ValueEventListener() {
			public void onDataChange(com.google.firebase.database.DataSnapshot d) { cfgS = d; helpB.setVisibility(s(d, "tutVideo").length() > 0 || s(d, "tutSteps").length() > 0 ? 0 : 8); int pi = (int) n(d, "pal"); palIdx = pi >= 0 && pi < PAL.length ? pi : 0; P = PAL[palIdx]; head = s(d, "head").length() > 0 ? s(d, "head") : DEF_HEAD; hint = s(d, "hint").length() > 0 ? s(d, "hint") : DEF_HINT; theme(); }
			public void onCancelled(com.google.firebase.database.DatabaseError e) {} });
		db.child("cat").child(KEY).addValueEventListener(new com.google.firebase.database.ValueEventListener() {
			public void onDataChange(com.google.firebase.database.DataSnapshot d) { items = d; render(); }
			public void onCancelled(com.google.firebase.database.DatabaseError e) { toast("DB: " + e.getMessage()); } });
	}
}
new CT().start();
